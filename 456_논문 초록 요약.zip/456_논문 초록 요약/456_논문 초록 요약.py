import torch
import pandas as pd
import time
import re
from datasets import Dataset
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training, PeftModel
from trl import SFTTrainer, SFTConfig
from tqdm import tqdm

MODEL_ID       = "meta-llama/Meta-Llama-3-8B-Instruct"
INPUT_FILE     = "논문메타데이터_예시요약_500.xlsx"
OUTPUT_DIR     = "./llama3_8b_summary_qlora"  
RESULT_FILE    = "llama3_8B_ensemble_Test.xlsx"

TITLE_COL      = "title_eng"
ABSTRACT_COL   = "abstract_eng"
SUMMARY_COL    = "Exemplary_Summary"

N_TRAIN_SAMPLES = 500   # 500개 학습 
N_TEST_SAMPLES  = 150   # 무작위 추출한 테스트 데이터 수
MAX_SEQ_LENGTH  = 2048

# 앙상블 채점관 함수
def evaluate_summary(text):
    score = 100 # 기본 점수 
    
    # 1. 외계어(러시아어, 일본어, 한자)가 섞여 있는지 확인
    if re.search(r'[а-яА-ЯёЁぁ-んァ-ン一-龥]', text):
        score -= 100 
        
    # 3. '-함' 또는 '-함.'으로 끝나지 않는지
    if not (text.strip().endswith('함') or text.strip().endswith('함.')):
        score -= 30
        
    # 4. 문장이 너무 짧거나 너무 긴가?
    if len(text) < 40 or len(text) > 250:
        score -= 20
        
    return score

# QLoRA 파인튜닝 학습
print("QLoRA 학습 인프라 준비 중...")

bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_use_double_quant=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_compute_dtype=torch.bfloat16
)

tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, trust_remote_code=True)
if tokenizer.pad_token is None:
    tokenizer.pad_token = tokenizer.eos_token
tokenizer.padding_side = "right"

model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_config,
    device_map="auto",
    torch_dtype=torch.bfloat16,
    trust_remote_code=True
)

# 훈련 데이터셋 전처리 및 로드
df_all = pd.read_excel(INPUT_FILE, header=1)
df_train = df_all[[TITLE_COL, ABSTRACT_COL, SUMMARY_COL]].dropna().copy()

df_train[TITLE_COL]    = df_train[TITLE_COL].astype(str).str.strip()
df_train[ABSTRACT_COL] = df_train[ABSTRACT_COL].astype(str).str.strip()
df_train[SUMMARY_COL]  = df_train[SUMMARY_COL].astype(str).str.strip()

df_train = df_train[
    (df_train[TITLE_COL] != "") &
    (df_train[ABSTRACT_COL] != "") &
    (df_train[SUMMARY_COL] != "")
].copy()

df_train = df_train.head(N_TRAIN_SAMPLES).copy()

if len(df_train) == 0:
    raise ValueError("학습 데이터가 없습니다. 파일이나 컬럼명을 확인해 주세요.")

def make_training_text(title, abstract, summary):
    messages = [
        {"role": "system", "content": "You are an academic paper summarization assistant. Your summaries must be strictly faithful to the source text. Never add information not present in the abstract."},
        {"role": "user", "content": f"Read the following paper title and abstract, then write a concise Korean summary.\n\nRules:\n- Write exactly 1 to 2 sentences. Never write more.\n- End every sentence with nominalized Korean endings such as '-함', '-음', or '-됨' (e.g., 분석함, 향상시킴, 제안함).\n- Focus ONLY on: research purpose, method, and main result.\n- Do NOT add any interpretation, opinion, or information not stated in the abstract.\n- Do NOT include bullet points, headers, or line breaks.\n- Do NOT translate technical terms, model names, algorithm names, or proper nouns.\n- Keep important English technical terms in their original form.\n- Never use words such as \"translation\", \"translated\", or \"Korean summary\" in the output.\n- [Language]: Write EXCLUSIVELY in Korean and English. NEVER use Japanese characters (Hiragana/Katakana) or Chinese characters (Hanja).\n\nTitle:\n{title}\n\nAbstract:\n{abstract}"},
        {"role": "assistant", "content": summary}
    ]
    return tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=False)

df_train["text"] = [make_training_text(r[TITLE_COL], r[ABSTRACT_COL], r[SUMMARY_COL]) for _, r in df_train.iterrows()]
dataset = Dataset.from_pandas(df_train[["text"]], preserve_index=False)

# QLoRA 어댑터 가중치 레이어 설정
model.config.use_cache = False
model = prepare_model_for_kbit_training(model)
lora_config = LoraConfig(
    r=16, lora_alpha=32,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
    lora_dropout=0.05, bias="none", task_type="CAUSAL_LM"
)
model = get_peft_model(model, lora_config)

# 학습 시작 실행
training_args = SFTConfig(
    output_dir=OUTPUT_DIR, num_train_epochs=3, per_device_train_batch_size=1,
    gradient_accumulation_steps=4, learning_rate=2e-4, logging_steps=10,
    save_steps=50, save_total_limit=2, bf16=True, optim="paged_adamw_8bit",
    report_to="none", dataset_text_field="text", max_length=MAX_SEQ_LENGTH, packing=False
)
trainer = SFTTrainer(model=model, args=training_args, train_dataset=dataset, processing_class=tokenizer)

print("Llama-3-8B QLoRA 파인튜닝 학습을 시작합니다...")
trainer.train()

# 어댑터 최종 세이브
trainer.model.save_pretrained(OUTPUT_DIR)
tokenizer.save_pretrained(OUTPUT_DIR)
print(f"학습이 완료되어 어댑터를 저장했습니다: {OUTPUT_DIR}")

del model
del trainer
torch.cuda.empty_cache()
time.sleep(2)

# 추론을 위한 모델 재로드 및 어댑터 결합
print("\n베이스 모델 및 새로운 QLoRA 어댑터 결합 중...")
model = AutoModelForCausalLM.from_pretrained(
    MODEL_ID,
    quantization_config=bnb_config,
    device_map="auto",
    torch_dtype=torch.bfloat16,
    trust_remote_code=True
)
model = PeftModel.from_pretrained(model, OUTPUT_DIR)
model.eval()
print("앙상블 추론 모델 준비 완료")

# 5. 무작위 데이터 추론 및 자가 앙상블 진행
test_df = df_all.dropna(subset=[TITLE_COL, ABSTRACT_COL]).sample(n=N_TEST_SAMPLES, random_state=42).copy()
print(f"총 {len(test_df)}건의 데이터 무작위 자가 앙상블 추론 테스트 시작...")

summary_results = []
latencies = []

for index, row in tqdm(test_df.iterrows(), total=len(test_df)):
    title = str(row[TITLE_COL]).strip()
    abstract = str(row[ABSTRACT_COL]).strip()
    
    messages = [
        {"role": "system", "content": "You are an academic paper summarization assistant. Your summaries must be strictly faithful to the source text. Never add information not present in the abstract."},
        {"role": "user", "content": f"Read the following paper title and abstract, then write a concise Korean summary.\n\nRules:\n- Write exactly 1 to 2 sentences. Never write more.\n- End every sentence with nominalized Korean endings such as '-함', '-음', or '-됨' (e.g., 분석함, 향상시킴, 제안함).\n- Focus ONLY on: research purpose, method, and main result.\n- Do NOT add any interpretation, opinion, or information not stated in the abstract.\n- Do NOT include bullet points, headers, or line breaks.\n- Do NOT translate technical terms, model names, algorithm names, or proper nouns.\n- Keep important English technical terms in their original form.\n- Never use words such as \"translation\", \"translated\", or \"Korean summary\" in the output.\n- [Language]: Write EXCLUSIVELY in Korean and English. NEVER use Japanese characters (Hiragana/Katakana) or Chinese characters (Hanja).\n\nTitle:\n{title}\n\nAbstract:\n{abstract}"}
    ]

    inputs = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    input_ids = tokenizer(inputs, return_tensors="pt").input_ids.to(model.device)

    start_time = time.time()
    with torch.no_grad():
        outputs = model.generate(
            input_ids=input_ids,
            max_new_tokens=150,
            do_sample=False,          # 빔 서치를 위해 무작위 샘플링
            num_beams=3,              # 3개의 유망한 문장 경로 추적
            num_return_sequences=3,   # 빔 서치 결과 중 상위 3개 후보군
            repetition_penalty=1.25,  # 패널티 조정 
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=tokenizer.eos_token_id
        )
    latency = time.time() - start_time
    latencies.append(latency)

    # 최고 점수 선출하기 위한 초기화
    best_summary = ""
    highest_score = -999

    # 반환된 3개의 최상위 빔 후보군을 순회하며 검수
    for i in range(3):
        generated_ids = outputs[i][input_ids.shape[-1]:]
        candidate_text = tokenizer.decode(generated_ids, skip_special_tokens=True).strip()
        
        score = evaluate_summary(candidate_text)
        
        # 역대 최고 순위 갱신 시 역전 대입
        if score > highest_score:
            highest_score = score
            best_summary = candidate_text

    summary_results.append(best_summary)

# 결과 저장 및 최종 리포트 대시보드 출력
test_df["AI_Summary_KR"] = summary_results
test_df["Latency_Sec"] = latencies
test_df.to_excel(RESULT_FILE, index=False)

valid_latencies = [x for x in latencies if x is not None]
allocated, reserved = 0.0, 0.0
if torch.cuda.is_available():
    allocated = torch.cuda.memory_allocated() / 1024**3
    reserved = torch.cuda.memory_reserved() / 1024**3

# 결과 콘솔 출력
print("\n" + "=" * 60)
print(f"앙상블 파이프라인 리포트 ({MODEL_ID.split('/')[-1]})")
print(f"- 총 처리 개수: {len(test_df)}개")
print(f"- 정상 처리 개수: {len(valid_latencies)}개")

if len(valid_latencies) > 0:
    print(f"- 평균 추론 시간: {sum(valid_latencies) / len(valid_latencies):.2f}초")
    print(f"- 최대 추론 시간: {max(valid_latencies):.2f}초")
    print(f"- 최소 추론 시간: {min(valid_latencies):.2f}초")

print(f"- 결과 파일명: {RESULT_FILE}")

if torch.cuda.is_available():
    print(f"- 최종 할당 VRAM: {allocated:.2f} GB (추론 세션 기준)")
    print(f"- 최종 예약 VRAM: {reserved:.2f} GB")
print("=" * 60)