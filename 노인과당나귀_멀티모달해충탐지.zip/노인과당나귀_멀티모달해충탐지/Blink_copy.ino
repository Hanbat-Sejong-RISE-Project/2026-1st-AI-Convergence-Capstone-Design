    #include <Arduino.h>
    #include <esp_camera.h>
    #include <WiFi.h>
    #include <WebServer.h>

    #include "tensorflow/lite/micro/micro_interpreter.h"
    #include "tensorflow/lite/micro/micro_mutable_op_resolver.h"
    #include "tensorflow/lite/schema/schema_generated.h"

    #include "model.h"
    #include "FINAL_RF.h"
    #include "demo_data.h"
    #include "index_html.h"

    float current_temp  = 24.5;
    float current_humi  = 65.0;
    float current_soil  = 42.0;
    float current_light = 850.0;

    const char* ssid     = "Galaxy S23 9EE6";
    const char* password = "11223344";

    #define PWDN_GPIO_NUM     32
    #define RESET_GPIO_NUM    -1
    #define XCLK_GPIO_NUM      0
    #define SIOD_GPIO_NUM     26
    #define SIOC_GPIO_NUM     27
    #define Y9_GPIO_NUM       35
    #define Y8_GPIO_NUM       34
    #define Y7_GPIO_NUM       39
    #define Y6_GPIO_NUM       36
    #define Y5_GPIO_NUM       21
    #define Y4_GPIO_NUM       19
    #define Y3_GPIO_NUM       18
    #define Y2_GPIO_NUM        5
    #define VSYNC_GPIO_NUM    25
    #define HREF_GPIO_NUM     23
    #define PCLK_GPIO_NUM     22

    #define SIM_INTERVAL_MS   1000
    #define Z_THRESHOLD       2.5f
    #define CONSECUTIVE_DAYS  2

    #define N_INPUTS  (96 * 96 * 3)
    #define N_OUTPUTS 2
    #define TENSOR_ARENA_SIZE (512 * 1024)

    const tflite::Model* tflite_model = nullptr;
    tflite::MicroInterpreter* interpreter = nullptr;
    TfLiteTensor* input_tensor  = nullptr;
    TfLiteTensor* output_tensor = nullptr;
    uint8_t* tensor_arena = nullptr;

    Eloquent::ML::Port::JujubeRF rf_model;
    WebServer server(80);

    int  current_day    = 0;
    int  warning_streak = 0;
    bool alarm_fired    = false;

    // ★ 추가된 타이머 변수
    unsigned long last_sim_time = 0;

    // 웹뷰어용 사진 + 결과 저장
    uint8_t* last_photo     = NULL;
    size_t   last_photo_len = 0;
    float    last_disease   = 0.0f;
    float    last_normal    = 0.0f;
    float    last_p_rf      = 0.0f;
    float    last_posterior = 0.0f;
    bool     last_is_disease = false;
    char     last_date[12]  = "";

    bool init_camera_rgb565();
    bool reinit_camera_jpeg();
    void fire_alarm();
    void capture_jpeg_photo();
    void setup_webserver();

    // ============================================
    // SETUP
    // ============================================
    void setup() {
        Serial.begin(115200);
        while (!Serial);
        delay(1000);

        Serial.println("\n[SYSTEM] Initializing...");

        if (!psramFound()) {
            Serial.println("❌ PSRAM not found!");
            while(1);
        }
        Serial.printf("✓ PSRAM Free: %d KB\n", ESP.getFreePsram() / 1024);

        tensor_arena = (uint8_t*) heap_caps_aligned_alloc(16, TENSOR_ARENA_SIZE, MALLOC_CAP_SPIRAM);
        if (!tensor_arena) { Serial.println("❌ Tensor Arena alloc failed!"); while(1); }

        tflite_model = tflite::GetModel(g_model);
        if (tflite_model->version() != TFLITE_SCHEMA_VERSION) {
            Serial.printf("❌ Schema version mismatch!\n"); while(1);
        }

        static tflite::MicroMutableOpResolver<15> resolver;
        resolver.AddConv2D();
        resolver.AddDepthwiseConv2D();
        resolver.AddAveragePool2D();
        resolver.AddFullyConnected();
        resolver.AddSoftmax();
        resolver.AddReshape();
        resolver.AddAdd();
        resolver.AddMean();
        resolver.AddPad();
        resolver.AddMaxPool2D();

        interpreter = new tflite::MicroInterpreter(tflite_model, resolver, tensor_arena, TENSOR_ARENA_SIZE);

        if (interpreter->AllocateTensors() != kTfLiteOk) {
            Serial.println("❌ AllocateTensors failed!"); while(1);
        }
        input_tensor  = interpreter->input(0);
        output_tensor = interpreter->output(0);
        Serial.println("✓ MobileNet V2 (INT8) Loaded");

        

        WiFi.mode(WIFI_STA);
        WiFi.begin(ssid, password);
        Serial.print("WiFi 연결중");
        int wifi_try = 0;
        while (WiFi.status() != WL_CONNECTED && wifi_try < 30) {
            delay(500);
            Serial.print(".");
            wifi_try++;
        }
        if (WiFi.status() == WL_CONNECTED) {
            Serial.printf("\n✓ WiFi 연결됨!\n");
            Serial.printf("📱 브라우저에서 접속: http://%s\n", WiFi.localIP().toString().c_str());
        } else {
            Serial.println("\n⚠️ WiFi 연결 실패 (시연은 계속 진행)");
        }
        if (!init_camera_rgb565()) { Serial.println("❌ Camera init failed!"); while(1); }
        Serial.println("✓ Camera Ready (RGB565)");

        setup_webserver();
        server.begin();

        Serial.println("\n>>> Starting Simulation...\n");
    }

    // ============================================
    // LOOP  ★ delay() 제거, millis() 타이머로 교체
    // ============================================
    void loop() {
        server.handleClient();  // 항상 웹 요청 처리

        if (millis() - last_sim_time < SIM_INTERVAL_MS) return;
        last_sim_time = millis();

        // 거짓 센서 데이터 갱신
        current_temp  = random(240, 270) / 10.0;
        current_humi  = random(60, 80);
        current_soil  = random(50, 80);
        current_light = random(800, 900);

        if (current_day >= DEMO_N_DAYS) {
            Serial.println("\n[FINISH] Simulation ended.");
            while(1) { server.handleClient(); delay(10); }
        }

        float rf_features[DEMO_N_FEATURES];
        for (int i = 0; i < DEMO_N_FEATURES; i++) {
            rf_features[i] = pgm_read_float(&DEMO_FEATURES[current_day][i]);
        }

        char date_str[12];
        strcpy_P(date_str, (PGM_P)pgm_read_ptr(&DEMO_DATES[current_day]));

        float p_rf = rf_model.predictDeadProb(rf_features);
        int prediction = (p_rf > 0.5f) ? 1 : 0;
        Serial.printf("Day %3d (%s) | RF P(dead)=%.3f", current_day + 1, date_str, p_rf);

        if (!alarm_fired && prediction == 1) {
            warning_streak++;
            Serial.printf(" | streak=%d", warning_streak);

            if (warning_streak >= CONSECUTIVE_DAYS) {
                last_p_rf = p_rf;
                Serial.println("\n\n[!!!] Disease Detected! Activating Camera...");
                strcpy(last_date, date_str);
                fire_alarm();
                alarm_fired = true;
            } else {
                Serial.println();
            }
        } else {
            warning_streak = 0;
            Serial.println();
        }

        current_day++;
    }

    // ============================================
    // FIRE ALARM
    // ============================================
    void fire_alarm() {
        camera_fb_t* fb = esp_camera_fb_get();
        if (!fb) { Serial.println("❌ Capture failed"); return; }

        uint16_t* rgb_ptr = (uint16_t*) fb->buf;
        float m[] = {0.485f, 0.456f, 0.406f};
        float s[] = {0.229f, 0.224f, 0.225f};
        int p_idx = 0;

        float input_scale     = input_tensor->params.scale;
        int   input_zero_point = input_tensor->params.zero_point;

        for (int i = 0; i < (96 * 96); i++) {
            uint16_t pixel = rgb_ptr[i];
            float r = (float)((pixel >> 11) & 0x1F) / 31.0f;
            float g = (float)((pixel >> 5)  & 0x3F) / 63.0f;
            float b = (float)( pixel         & 0x1F) / 31.0f;
            float norm_r = (r - m[0]) / s[0];
            float norm_g = (g - m[1]) / s[1];
            float norm_b = (b - m[2]) / s[2];

            if (input_tensor->type == kTfLiteInt8) {
                input_tensor->data.int8[p_idx++] = (int8_t)(norm_r / input_scale + input_zero_point);
                input_tensor->data.int8[p_idx++] = (int8_t)(norm_g / input_scale + input_zero_point);
                input_tensor->data.int8[p_idx++] = (int8_t)(norm_b / input_scale + input_zero_point);
            }
        }
        esp_camera_fb_return(fb);

        unsigned long start_ms = millis();
        if (interpreter->Invoke() != kTfLiteOk) {
            Serial.println("❌ Inference failed"); return;
        }
        Serial.printf("Inference Time: %lu ms\n", millis() - start_ms);

        float disease_prob = 0.0f, normal_prob = 0.0f;
        if (output_tensor->type == kTfLiteInt8) {
            float out_scale     = output_tensor->params.scale;
            int   out_zero_point = output_tensor->params.zero_point;

            float disease_logit = (output_tensor->data.int8[0] - out_zero_point) * out_scale;
            float normal_logit  = (output_tensor->data.int8[1] - out_zero_point) * out_scale;

            float max_logit   = max(disease_logit, normal_logit);
            float exp_disease = exp(disease_logit - max_logit);
            float exp_normal  = exp(normal_logit  - max_logit);
            float sum         = exp_disease + exp_normal;

            disease_prob = exp_disease / sum;
            normal_prob  = exp_normal  / sum;

            last_posterior = (last_p_rf * disease_prob) /
                            (last_p_rf * disease_prob + (1.0f - last_p_rf) * normal_prob);

            Serial.printf("Bayesian -> Prior(RF)=%.3f, Likelihood(CNN)=%.3f, Posterior=%.3f\n",
                        last_p_rf, disease_prob, last_posterior);
        }

        Serial.printf("Result -> Disease: %.3f | Normal: %.3f\n", disease_prob, normal_prob);
        last_disease    = disease_prob;
        last_normal     = normal_prob;
        last_is_disease = (disease_prob > normal_prob);

        if (last_is_disease) Serial.println("🚨 [FINAL] DISEASE CONFIRMED!");
        else                 Serial.println("✅ [FINAL] VISUALLY HEALTHY.");

        Serial.println("📸 Switching to JPEG mode for photo...");
        esp_camera_deinit();
        delay(200);

        if (reinit_camera_jpeg()) {
            capture_jpeg_photo();
            esp_camera_deinit();
            delay(200);
            init_camera_rgb565();
        }

        if (WiFi.status() == WL_CONNECTED) {
            Serial.printf("📱 결과 보기: http://%s\n", WiFi.localIP().toString().c_str());
        }
    }

    void capture_jpeg_photo() {
        camera_fb_t* fb = esp_camera_fb_get();
        if (!fb) { Serial.println("❌ JPEG capture failed"); return; }

        if (last_photo) free(last_photo);
        last_photo = (uint8_t*) ps_malloc(fb->len);
        if (last_photo) {
            memcpy(last_photo, fb->buf, fb->len);
            last_photo_len = fb->len;
            Serial.printf("✓ JPEG saved: %d bytes\n", fb->len);
        }
        esp_camera_fb_return(fb);
    }

    // ============================================
    // 웹서버 설정  ★ 청크 방식으로 교체 (메모리 절약)
    // ============================================
    void setup_webserver() {
        server.on("/", []() {
            bool fd = last_posterior > 0.5f;

            // 치환할 값들을 미리 String으로 준비
            String v_temp     = String(current_temp, 1);
            String v_humi     = String(current_humi, 0);
            String v_soil     = String(current_soil, 0);
            String v_light    = String(current_light, 0);
            String v_date     = String(last_date);
            String v_prf      = String(last_p_rf * 100, 1);
            String v_prf_raw  = String(last_p_rf, 3);
            String v_dis      = String(last_disease * 100, 1);
            String v_dis_raw  = String(last_disease, 3);
            String v_nor      = String(last_normal * 100, 1);
            String v_post     = String(last_posterior * 100, 1);
            String v_post_raw = String(last_posterior, 3);
            String v_stcls    = fd ? "bad"              : "ok";
            String v_st       = fd ? "질병 발견"         : "정상";
            String v_vdcls    = fd ? "bad"              : "ok";
            String v_vdt      = fd ? "질병 의심 (조치 필요)" : "정상 (안전)";
            String v_time     = String(millis() / 1000) + "초 전";

            server.setContentLength(CONTENT_LENGTH_UNKNOWN);
            server.send(200, "text/html", "");

            const int CHUNK_SIZE = 512;
            String chunk = "";
            chunk.reserve(CHUNK_SIZE + 64);

            int total = strlen_P(HTML_PAGE);
            for (int i = 0; i <= total; i++) {
                if (i < total) chunk += (char)pgm_read_byte(HTML_PAGE + i);

                if (chunk.length() >= CHUNK_SIZE -20 || i == total) {
                    // 플레이스홀더 치환
                    chunk.replace("%TEMP%",         v_temp);
                    chunk.replace("%HUMI%",         v_humi);
                    chunk.replace("%SOIL%",         v_soil);
                    chunk.replace("%LIGHT%",        v_light);
                    chunk.replace("%LAST_DATE%",    v_date);
                    chunk.replace("%P_RF%",         v_prf);
                    chunk.replace("%P_RF_RAW%",     v_prf_raw);
                    chunk.replace("%DISEASE%",      v_dis);
                    chunk.replace("%DISEASE_RAW%",  v_dis_raw);
                    chunk.replace("%NORMAL%",       v_nor);
                    chunk.replace("%POSTERIOR%",    v_post);
                    chunk.replace("%POSTERIOR_RAW%",v_post_raw);
                    chunk.replace("%STATUS_CLASS%", v_stcls);
                    chunk.replace("%STATUS%",       v_st);
                    chunk.replace("%VERDICT_CLASS%",v_vdcls);
                    chunk.replace("%VERDICT_TEXT%", v_vdt);
                    chunk.replace("%TIME1%",        v_time);
                    chunk.replace("%TIME2%",        v_time);
                    chunk.replace("%TIME3%",        v_time);
                    chunk.replace("%TIME4%",        v_time);
                    chunk.replace("%TIME5%",        v_time);

                    server.sendContent(chunk);
                    chunk = "";
                }
            }
        });

        server.on("/photo", []() {
            if (last_photo && last_photo_len > 0) {
                server.send_P(200, "image/jpeg", (const char*)last_photo, last_photo_len);
            } else {
                server.send(404, "text/plain", "No photo");
            }
        });
    }

    // ============================================
    // 카메라 초기화 함수들
    // ============================================
    bool init_camera_rgb565() {
        camera_config_t config;
        config.ledc_channel  = LEDC_CHANNEL_0;
        config.ledc_timer    = LEDC_TIMER_0;
        config.pin_d0        = Y2_GPIO_NUM; config.pin_d1 = Y3_GPIO_NUM;
        config.pin_d2        = Y4_GPIO_NUM; config.pin_d3 = Y5_GPIO_NUM;
        config.pin_d4        = Y6_GPIO_NUM; config.pin_d5 = Y7_GPIO_NUM;
        config.pin_d6        = Y8_GPIO_NUM; config.pin_d7 = Y9_GPIO_NUM;
        config.pin_xclk      = XCLK_GPIO_NUM; config.pin_pclk  = PCLK_GPIO_NUM;
        config.pin_vsync     = VSYNC_GPIO_NUM; config.pin_href  = HREF_GPIO_NUM;
        config.pin_sccb_sda  = SIOD_GPIO_NUM;  config.pin_sccb_scl = SIOC_GPIO_NUM;
        config.pin_pwdn      = PWDN_GPIO_NUM;  config.pin_reset = RESET_GPIO_NUM;
        config.xclk_freq_hz  = 20000000;
        config.frame_size    = FRAMESIZE_96X96;
        config.pixel_format  = PIXFORMAT_RGB565;
        config.grab_mode     = CAMERA_GRAB_LATEST;
        config.fb_location   = CAMERA_FB_IN_PSRAM;
        config.fb_count      = 1;

        if (esp_camera_init(&config) != ESP_OK) return false;
        sensor_t* s = esp_camera_sensor_get();
        s->set_framesize(s, FRAMESIZE_96X96);
        return true;
    }

    bool reinit_camera_jpeg() {
        camera_config_t config;
        config.ledc_channel  = LEDC_CHANNEL_0;
        config.ledc_timer    = LEDC_TIMER_0;
        config.pin_d0        = Y2_GPIO_NUM; config.pin_d1 = Y3_GPIO_NUM;
        config.pin_d2        = Y4_GPIO_NUM; config.pin_d3 = Y5_GPIO_NUM;
        config.pin_d4        = Y6_GPIO_NUM; config.pin_d5 = Y7_GPIO_NUM;
        config.pin_d6        = Y8_GPIO_NUM; config.pin_d7 = Y9_GPIO_NUM;
        config.pin_xclk      = XCLK_GPIO_NUM; config.pin_pclk  = PCLK_GPIO_NUM;
        config.pin_vsync     = VSYNC_GPIO_NUM; config.pin_href  = HREF_GPIO_NUM;
        config.pin_sccb_sda  = SIOD_GPIO_NUM;  config.pin_sccb_scl = SIOC_GPIO_NUM;
        config.pin_pwdn      = PWDN_GPIO_NUM;  config.pin_reset = RESET_GPIO_NUM;
        config.xclk_freq_hz  = 20000000;
        config.frame_size    = FRAMESIZE_VGA;
        config.pixel_format  = PIXFORMAT_JPEG;
        config.jpeg_quality  = 12;
        config.grab_mode     = CAMERA_GRAB_LATEST;
        config.fb_location   = CAMERA_FB_IN_PSRAM;
        config.fb_count      = 1;

        if (esp_camera_init(&config) != ESP_OK) return false;
        return true;
    }
