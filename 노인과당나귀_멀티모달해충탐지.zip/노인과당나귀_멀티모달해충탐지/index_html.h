// index_html.h
#ifndef INDEX_HTML_H
#define INDEX_HTML_H

#include <Arduino.h>

// 웹페이지 HTML 코드를 PROGMEM 메모리에 저장
const char HTML_PAGE[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AgriVision</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:#0f172a;color:#e2e8f0;line-height:1.5}
.hd{background:#1e293b;border-bottom:1px solid #334155;padding:12px 24px;display:flex;justify-content:space-between;align-items:center}
.logo{font-size:18px;font-weight:700;color:#fff}
.live{display:flex;align-items:center;gap:6px;font-size:12px;color:#94a3b8}
.dot{width:8px;height:8px;background:#22c55e;border-radius:50%;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}
.wrap{max-width:1200px;margin:0 auto;padding:24px}
.info{margin-bottom:24px}
.info h2{font-size:20px;color:#fff;margin-bottom:4px}
.info p{font-size:13px;color:#64748b}
.grid4{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px}
.mc{background:#1e293b;border:1px solid #334155;border-radius:8px;padding:16px}
.mc .lb{font-size:11px;color:#64748b;margin-bottom:4px}
.mc .vl{font-size:24px;font-weight:700;color:#fff}
.mc.t .vl{color:#f97316}
.mc.h .vl{color:#3b82f6}
.mc.s .vl{color:#22c55e}
.mc.l .vl{color:#eab308}
.main{display:grid;grid-template-columns:1fr 2fr;gap:24px}
.card{background:#1e293b;border:1px solid #334155;border-radius:12px;overflow:hidden}
.card-hd{padding:16px;border-bottom:1px solid #334155;display:flex;justify-content:space-between;align-items:center}
.card-hd h3{font-size:14px;font-weight:600;color:#fff}
.card-hd span{font-size:11px;color:#64748b}
.card-bd{padding:16px}
.img-box{position:relative;aspect-ratio:4/3;background:#0f172a;border-radius:8px;display:flex;align-items:center;justify-content:center}
.img-box img{width:100%;height:100%;object-fit:cover;border-radius:8px}
.img-box .badge{position:absolute;top:12px;right:12px;padding:4px 12px;border-radius:20px;font-size:12px;font-weight:600}
.badge.ok{background:#22c55e;color:#fff}
.badge.bad{background:#ef4444;color:#fff}
.img-box .time{position:absolute;bottom:8px;left:8px;font-size:11px;background:rgba(0,0,0,.7);padding:4px 8px;border-radius:4px}
.img-box .lv{position:absolute;bottom:8px;right:8px;font-size:11px;background:rgba(0,0,0,.7);padding:4px 8px;border-radius:4px;display:flex;align-items:center;gap:4px}
.img-box .lv .d{width:6px;height:6px;background:#22c55e;border-radius:50%;animation:pulse 2s infinite}
.verdict{margin-top:16px;padding:20px;border-radius:8px;text-align:center}
.verdict.ok{background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.3)}
.verdict.bad{background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3)}
.verdict h4{font-size:18px;font-weight:700;margin-bottom:4px}
.verdict.ok h4{color:#22c55e}
.verdict.bad h4{color:#ef4444}
.verdict p{font-size:28px;font-weight:700;color:#fff}
.right{display:flex;flex-direction:column;gap:16px}
.step{font-size:11px;color:#3b82f6;font-weight:600;margin-bottom:8px}
.an-hd{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:12px}
.an-hd h4{font-size:14px;color:#fff}
.an-hd span{font-size:11px;color:#64748b}
.bar-wrap{height:8px;background:#334155;border-radius:4px;overflow:hidden;margin:8px 0}
.bar{height:100%;border-radius:4px;transition:width .3s}
.bar.gr{background:linear-gradient(90deg,#22c55e,#eab308,#ef4444)}
.bar.red{background:#ef4444}
.bar.green{background:#22c55e}
.pct{font-size:20px;font-weight:700;color:#fff}
.sensors{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px}
.sen{background:#0f172a;padding:10px;border-radius:6px;text-align:center}
.sen .slb{font-size:10px;color:#64748b}
.sen .sv{font-size:13px;font-weight:600;color:#fff}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.two .box{padding:16px;border-radius:8px}
.two .box.red{background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2)}
.two .box.green{background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2)}
.two .box .blb{font-size:12px;color:#94a3b8;margin-bottom:4px}
.two .box .bv{font-size:24px;font-weight:700}
.two .box.red .bv{color:#ef4444}
.two .box.green .bv{color:#22c55e}
.formula{background:#0f172a;padding:10px;border-radius:6px;font-family:monospace;font-size:11px;color:#64748b;margin-top:12px}
.three{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:12px}
.three .item{background:#0f172a;padding:10px;border-radius:6px;text-align:center}
.three .item .ilb{font-size:10px;color:#64748b}
.three .item .iv{font-size:14px;font-weight:600}
.three .item.rf .iv{color:#3b82f6}
.three .item.cnn .iv{color:#a855f7}
.three .item.final .iv{color:#ef4444}
.logs{margin-top:24px}
.logs h3{font-size:14px;color:#fff;margin-bottom:12px}
.log{display:flex;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid #1e293b;font-size:13px}
.log .lt{color:#64748b;font-family:monospace;width:70px}
.log .ld{width:6px;height:6px;background:#22c55e;border-radius:50%}
.log .le{color:#e2e8f0}
.ft{margin-top:24px;padding-top:16px;border-top:1px solid #334155;display:flex;justify-content:space-between;font-size:11px;color:#64748b}
@media(max-width:768px){.grid4{grid-template-columns:repeat(2,1fr)}.main{grid-template-columns:1fr}.sensors,.three{grid-template-columns:repeat(2,1fr)}}
</style>
</head>
<body>
<div class="hd">
  <div class="logo">AgriVision</div>
  <div class="live"><span class="dot"></span>실시간 모니터링</div>
</div>
<div class="wrap">
  <div class="info">
    <h2>사과나무 47R</h2>
    <p>A구역 3열 | 마지막 분석: <span id="dt">%LAST_DATE%</span></p>
  </div>
  <div class="grid4">
    <div class="mc t"><div class="lb">온도</div><div class="vl">%TEMP%°C</div></div>
    <div class="mc h"><div class="lb">습도</div><div class="vl">%HUMI%%</div></div>
    <div class="mc s"><div class="lb">토양수분</div><div class="vl">%SOIL%%</div></div>
    <div class="mc l"><div class="lb">줄기수분</div><div class="vl">%LIGHT%</div></div>
  </div>
  <div class="main">
    <div class="left">
      <div class="card">
        <div class="card-hd"><h3>실시간 영상</h3><span>CAM-47R</span></div>
        <div class="card-bd">
          <div class="img-box">
            <img src="/photo" id="photo">
            <div class="badge %STATUS_CLASS%" id="badge">%STATUS%</div>
            <div class="time" id="time">%LAST_DATE%</div>
            <div class="lv"><span class="d"></span>LIVE</div>
          </div>
          <div class="verdict %VERDICT_CLASS%" id="verdict">
            <h4 id="vt">%VERDICT_TEXT%</h4>
            <p id="vp">%POSTERIOR%%</p>
          </div>
        </div>
      </div>
    </div>
    <div class="right">
      <div class="card">
        <div class="card-bd">
          <div class="step">01 STEP</div>
          <div class="an-hd"><h4>센서 데이터 분석</h4><span>RandomForest</span></div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:#64748b;font-size:13px">질병 확률</span>
            <span class="pct" id="rf">%P_RF%%</span>
          </div>
          <div class="bar-wrap"><div class="bar gr" id="rfbar" style="width:%P_RF%%"></div></div>
          <div class="sensors">
            <div class="sen"><div class="slb">온도</div><div class="sv">%TEMP%°</div></div>
            <div class="sen"><div class="slb">습도</div><div class="sv">%HUMI%%</div></div>
            <div class="sen"><div class="slb">토양</div><div class="sv">%SOIL%%</div></div>
            <div class="sen"><div class="slb">줄기수분</div><div class="sv">%LIGHT%</div></div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-bd">
          <div class="step">02 STEP</div>
          <div class="an-hd"><h4>영상 분석</h4><span>MobileNetV2</span></div>
          <div class="two">
            <div class="box red">
              <div class="blb">Disease</div>
              <div class="bv" id="dis">%DISEASE%%</div>
              <div class="bar-wrap"><div class="bar red" id="disbar" style="width:%DISEASE%%"></div></div>
            </div>
            <div class="box green">
              <div class="blb">Normal</div>
              <div class="bv" id="nor">%NORMAL%%</div>
              <div class="bar-wrap"><div class="bar green" id="norbar" style="width:%NORMAL%%"></div></div>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-bd">
          <div class="step">03 STEP</div>
          <div class="an-hd"><h4>베이지안 결합 분석</h4><span>최종 확률</span></div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <span style="color:#64748b;font-size:13px">P(질병|센서,영상)</span>
            <span class="pct" id="post">%POSTERIOR%%</span>
          </div>
          <div class="bar-wrap"><div class="bar gr" id="postbar" style="width:%POSTERIOR%%"></div></div>
          <div class="formula">posterior = (p_rf × p_cnn) / ((p_rf × p_cnn) + ((1-p_rf) × (1-p_cnn)))</div>
          <div class="three">
            <div class="item rf"><div class="ilb">RF 출력</div><div class="iv" id="rfv">%P_RF_RAW%</div></div>
            <div class="item cnn"><div class="ilb">CNN 출력</div><div class="iv" id="cnnv">%DISEASE_RAW%</div></div>
            <div class="item final"><div class="ilb">최종</div><div class="iv" id="postv">%POSTERIOR_RAW%</div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="logs card">
    <div class="card-bd">
      <h3>최근 분석 기록</h3>
      <div class="log"><span class="lt">%TIME1%</span><span class="ld"></span><span class="le">베이지안 분석 완료</span></div>
      <div class="log"><span class="lt">%TIME2%</span><span class="ld"></span><span class="le">CNN 영상 분석 완료</span></div>
      <div class="log"><span class="lt">%TIME3%</span><span class="ld"></span><span class="le">RandomForest 센서 분석 완료</span></div>
      <div class="log"><span class="lt">%TIME4%</span><span class="ld"></span><span class="le">이미지 캡처 완료</span></div>
      <div class="log"><span class="lt">%TIME5%</span><span class="ld"></span><span class="le">센서 데이터 수신</span></div>
    </div>
  </div>
  <div class="ft">
    <span>AgriVision v2.1.0 | ESP32-CAM</span>
    <span><span class="dot" style="display:inline-block;width:6px;height:6px;margin-right:4px"></span>시스템 정상</span>
  </div>
</div>
</body>
</html>
)rawliteral";

#endif