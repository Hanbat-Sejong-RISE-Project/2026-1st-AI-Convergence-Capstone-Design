import base64
import csv
import json
import math
import os
import threading
import time
from collections import deque
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Deque, Dict, List, Optional
from urllib.parse import parse_qs, urlparse

import cv2
from ament_index_python.packages import get_package_share_directory
from cv_bridge import CvBridge
import numpy as np
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float64, String

from .common import DATA_ROOT, WORKSPACE_ROOT, load_json, mean, safe_float


class ImageClassifier:
    def __init__(self, model_path: Path, metadata_path: Path, device_preference: str) -> None:
        self.model_path = model_path
        self.metadata = load_json(metadata_path, {})
        self.classes = self.metadata.get("classes") or [
            "01_pear_normal",
            "02_pear_scab",
            "03_pear_fire_blight",
        ]
        self.display_names = self.metadata.get("display_names", {})
        self.image_size = int(self.metadata.get("image_size", 224))
        norm = self.metadata.get("normalization", {})
        self.mean = np.array(norm.get("mean", [0.485, 0.456, 0.406]), dtype=np.float32)
        self.std = np.array(norm.get("std", [0.229, 0.224, 0.225]), dtype=np.float32)
        self.error: Optional[str] = None
        self.device = "unavailable"
        self.torch = None
        self.model = None

        try:
            import torch  # type: ignore

            self.torch = torch
            if device_preference == "cuda" and torch.cuda.is_available():
                self.device = "cuda:0"
            elif device_preference == "auto" and torch.cuda.is_available():
                self.device = "cuda:0"
            else:
                self.device = "cpu"
            self.model = torch.jit.load(str(model_path), map_location=self.device)
            self.model.eval()
        except Exception as exc:
            self.error = str(exc)

    @property
    def available(self) -> bool:
        return self.model is not None and self.torch is not None

    def predict(self, bgr_image: np.ndarray) -> Dict[str, Any]:
        if not self.available:
            return {
                "available": False,
                "error": self.error or "classifier unavailable",
                "model": self.model_path.name,
                "device": self.device,
                "rows": [],
                "inference_ms": None,
                "updated_at": time.time(),
            }

        rgb = cv2.cvtColor(bgr_image, cv2.COLOR_BGR2RGB)
        resized = cv2.resize(rgb, (self.image_size, self.image_size), interpolation=cv2.INTER_AREA)
        arr = resized.astype(np.float32) / 255.0
        arr = (arr - self.mean) / self.std
        arr = np.transpose(arr, (2, 0, 1))[None, ...]
        tensor = self.torch.from_numpy(arr).to(self.device)

        with self.torch.no_grad():
            start = time.perf_counter()
            logits = self.model(tensor)
            inference_ms = (time.perf_counter() - start) * 1000.0
            probs = self.torch.softmax(logits[0], dim=0).detach().cpu().numpy().tolist()
            logit_values = logits[0].detach().cpu().numpy().tolist()

        rows = []
        for idx, class_name in enumerate(self.classes):
            rows.append(
                {
                    "class_name": class_name,
                    "display_name": self.display_names.get(class_name, class_name),
                    "logit": float(logit_values[idx]),
                    "probability": float(probs[idx]),
                }
            )
        top = max(rows, key=lambda r: r["probability"]) if rows else None
        return {
            "available": True,
            "model": self.model_path.name,
            "device": self.device,
            "rows": rows,
            "top": top,
            "inference_ms": inference_ms,
            "updated_at": time.time(),
        }


class DashboardNode(Node):
    def __init__(self) -> None:
        super().__init__("capstone_dashboard")
        self.declare_parameter("host", "127.0.0.1")
        self.declare_parameter("port", 8080)
        self.declare_parameter("history_limit", 240)
        self.declare_parameter("stale_after_sec", 1200.0)
        self.declare_parameter("image_stale_after_sec", 1200.0)
        self.declare_parameter(
            "image_classifier_model",
            str(DATA_ROOT / "sky/outputs/mobilenet_pear_multiclass/mobilenet_multiclass.torchscript.pt"),
        )
        self.declare_parameter(
            "image_classifier_metadata",
            str(DATA_ROOT / "sky/outputs/mobilenet_pear_multiclass/metadata.json"),
        )
        self.declare_parameter("image_classifier_device", "cpu")
        self.declare_parameter(
            "topic_log_path",
            str(WORKSPACE_ROOT / "runtime_logs/topic_timeseries.csv"),
        )
        self.declare_parameter("topic_log_max_entries", 2000)

        self.host = str(self.get_parameter("host").value)
        self.port = int(self.get_parameter("port").value)
        self.history_limit = int(self.get_parameter("history_limit").value)
        self.stale_after_sec = float(self.get_parameter("stale_after_sec").value)
        self.image_stale_after_sec = float(self.get_parameter("image_stale_after_sec").value)
        self.topic_log_path = Path(str(self.get_parameter("topic_log_path").value))
        self.topic_log_max_entries = max(1, int(self.get_parameter("topic_log_max_entries").value))

        self.bridge = CvBridge()
        self.lock = threading.RLock()
        self.sensor_subscriptions: Dict[str, Any] = {}
        self.sensors: Dict[str, Dict[str, Any]] = {}
        self.predictions: Dict[str, Dict[str, Any]] = {}
        self.prediction_history: Dict[str, Deque[Dict[str, Any]]] = {}
        self.topic_log: Deque[Dict[str, Any]] = deque(maxlen=self.topic_log_max_entries)
        self.received_entries = 0
        self.latest_image: Optional[Dict[str, Any]] = None

        self.classifier = ImageClassifier(
            Path(str(self.get_parameter("image_classifier_model").value)),
            Path(str(self.get_parameter("image_classifier_metadata").value)),
            str(self.get_parameter("image_classifier_device").value),
        )
        if self.classifier.available:
            self.get_logger().info(
                f"loaded image classifier {self.classifier.model_path} on {self.classifier.device}"
            )
        else:
            self.get_logger().warning(f"image classifier unavailable: {self.classifier.error}")

        self.create_subscription(Image, "/plant/image", self._on_image, 10)
        self.create_subscription(String, "/model/prediction", self._on_prediction, 50)
        self.create_timer(1.0, self._discover_sensor_topics)
        self._prepare_log_file()
        self.httpd = self._start_http_server()
        self.get_logger().info(f"dashboard listening on http://{self.host}:{self.port}")

    def destroy_node(self) -> bool:
        if hasattr(self, "httpd"):
            self.httpd.shutdown()
        return super().destroy_node()

    def _prepare_log_file(self) -> None:
        self.topic_log_path.parent.mkdir(parents=True, exist_ok=True)
        if not self.topic_log_path.exists():
            with self.topic_log_path.open("w", encoding="utf-8", newline="") as f:
                writer = csv.DictWriter(
                    f,
                    fieldnames=["receive_time", "topic", "sensor_code", "value", "unit"],
                )
                writer.writeheader()

    def _start_http_server(self) -> ThreadingHTTPServer:
        node = self
        web_dir = Path(get_package_share_directory("capstone_dashboard")) / "web"

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, fmt: str, *args: Any) -> None:
                return

            def _send(self, status: int, content_type: str, body: bytes) -> None:
                self.send_response(status)
                self.send_header("Content-Type", content_type)
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def do_GET(self) -> None:
                parsed = urlparse(self.path)
                if parsed.path == "/api/state":
                    self._send(200, "application/json; charset=utf-8", json.dumps(node.state()).encode("utf-8"))
                    return
                if parsed.path == "/api/topic-log":
                    qs = parse_qs(parsed.query)
                    limit = int(qs.get("limit", ["500"])[0])
                    self._send(
                        200,
                        "application/json; charset=utf-8",
                        json.dumps(node.topic_log_state(limit), ensure_ascii=False).encode("utf-8"),
                    )
                    return
                target = web_dir / ("index.html" if parsed.path in {"", "/"} else parsed.path.lstrip("/"))
                if target.exists() and target.is_file():
                    ctype = "text/html; charset=utf-8" if target.suffix == ".html" else "text/plain"
                    self._send(200, ctype, target.read_bytes())
                    return
                self._send(404, "text/plain; charset=utf-8", b"not found")

        server = ThreadingHTTPServer((self.host, self.port), Handler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server

    def _discover_sensor_topics(self) -> None:
        for topic, types in self.get_topic_names_and_types():
            if not topic.startswith("/sensors/sensor_"):
                continue
            if "std_msgs/msg/Float64" not in types:
                continue
            if topic in self.sensor_subscriptions:
                continue
            self.sensor_subscriptions[topic] = self.create_subscription(
                Float64,
                topic,
                lambda msg, t=topic: self._on_sensor(t, msg),
                50,
            )
            self.get_logger().info(f"subscribed {topic}")

    def _on_sensor(self, topic: str, msg: Float64) -> None:
        now = time.time()
        sensor_code = topic.rsplit("_", 1)[-1]
        entry = {
            "receive_time": now,
            "topic": topic,
            "sensor_code": sensor_code,
            "value": msg.data,
            "unit": "raw",
        }
        with self.lock:
            sensor = self.sensors.setdefault(
                sensor_code,
                {
                    "sensor_code": sensor_code,
                    "topic": topic,
                    "unit": "raw",
                    "history": deque(maxlen=self.history_limit),
                },
            )
            sensor["latest"] = msg.data
            sensor["updated_at"] = now
            sensor["history"].append({"t": now, "value": msg.data})
            self.topic_log.append(entry)
            self.received_entries += 1
        self._append_topic_log(entry)

    def _append_topic_log(self, entry: Dict[str, Any]) -> None:
        with self.topic_log_path.open("a", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=["receive_time", "topic", "sensor_code", "value", "unit"],
            )
            writer.writerow(entry)

    def _on_prediction(self, msg: String) -> None:
        try:
            payload = json.loads(msg.data)
        except json.JSONDecodeError:
            return
        sensor_code = str(payload.get("sensor_code", "unknown"))
        now = time.time()
        payload.setdefault("updated_at", now)
        payload["probability"] = safe_float(payload.get("probability"), 0.0)
        payload["score"] = safe_float(payload.get("score"), 0.0)
        payload["threshold"] = safe_float(payload.get("threshold"), 0.0)
        payload["inference_ms"] = safe_float(payload.get("inference_ms"), 0.0)
        point = {
            "t": payload.get("updated_at", now),
            "probability": payload["probability"],
            "score": payload["score"],
            "threshold": payload["threshold"],
            "inference_ms": payload["inference_ms"],
        }
        with self.lock:
            self.predictions[sensor_code] = payload
            hist = self.prediction_history.setdefault(sensor_code, deque(maxlen=self.history_limit))
            hist.append(point)
            sensor = self.sensors.get(sensor_code)
            if sensor is not None:
                sensor["tree_id"] = payload.get("tree_id", "")
                sensor["environment_group"] = payload.get("environment_group", "")

    def _on_image(self, msg: Image) -> None:
        now = time.time()
        try:
            bgr = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except Exception as exc:
            self.get_logger().warning(f"image conversion failed: {exc}")
            return

        classification = self.classifier.predict(bgr)
        ok, encoded = cv2.imencode(".jpg", bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 82])
        image_data = base64.b64encode(encoded.tobytes()).decode("ascii") if ok else ""
        frame_id = msg.header.frame_id
        parts = frame_id.split(":", 2)
        true_label = parts[1] if len(parts) >= 2 else ""
        file_name = parts[2] if len(parts) >= 3 else ""
        with self.lock:
            self.latest_image = {
                "updated_at": now,
                "frame_id": frame_id,
                "true_label": true_label,
                "file_name": file_name,
                "width": int(bgr.shape[1]),
                "height": int(bgr.shape[0]),
                "jpeg_base64": image_data,
                "classification": classification,
            }

    def topic_log_state(self, limit: int) -> Dict[str, Any]:
        with self.lock:
            rows = list(self.topic_log)[-max(1, limit):]
            latest_by_topic = {}
            for row in rows:
                latest_by_topic[row["topic"]] = row
            return {
                "path": str(self.topic_log_path),
                "received_entries": self.received_entries,
                "retained_entries": len(self.topic_log),
                "rows": rows,
                "latest_by_topic": list(latest_by_topic.values()),
            }

    def state(self) -> Dict[str, Any]:
        now = time.time()
        with self.lock:
            sensors = []
            for sensor in self.sensors.values():
                updated_at = sensor.get("updated_at", 0.0)
                sensors.append(
                    {
                        "sensor_code": sensor["sensor_code"],
                        "topic": sensor["topic"],
                        "unit": sensor.get("unit", "raw"),
                        "latest": sensor.get("latest"),
                        "updated_at": updated_at,
                        "age_sec": now - updated_at if updated_at else None,
                        "stale": bool(updated_at and now - updated_at > self.stale_after_sec),
                        "tree_id": sensor.get("tree_id", ""),
                        "environment_group": sensor.get("environment_group", ""),
                        "history": list(sensor["history"]),
                    }
                )
            predictions = []
            for sensor_code, pred in self.predictions.items():
                item = dict(pred)
                item["history"] = list(self.prediction_history.get(sensor_code, []))
                predictions.append(item)
            image = dict(self.latest_image) if self.latest_image else None

        pred_times = [safe_float(p.get("inference_ms"), 0.0) for p in predictions if p.get("inference_ms") is not None]
        image_time = None
        if image and image.get("classification"):
            image_time = image["classification"].get("inference_ms")
        return {
            "now": now,
            "sensor_count": len(sensors),
            "prediction_count": len(predictions),
            "stale_sensor_count": sum(1 for s in sensors if s["stale"]),
            "sensors": sensors,
            "predictions": predictions,
            "image": image,
            "timing": {
                "mobilenet_inference_ms": image_time,
                "timeseries_latest_inference_ms": pred_times[-1] if pred_times else None,
                "timeseries_avg_inference_ms": mean(pred_times) if pred_times else None,
            },
        }


def main(args=None) -> None:
    rclpy.init(args=args)
    node = DashboardNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
