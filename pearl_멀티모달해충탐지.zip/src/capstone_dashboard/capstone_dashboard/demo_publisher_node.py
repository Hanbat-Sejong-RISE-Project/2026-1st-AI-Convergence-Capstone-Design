import json
import math
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import cv2
from cv_bridge import CvBridge
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from std_msgs.msg import Float64, String

from .common import DATA_ROOT, find_images, read_csv_rows, safe_float, safe_int, sensor_topic


class DemoPublisherNode(Node):
    def __init__(self) -> None:
        super().__init__("capstone_demo_publisher")
        self.declare_parameter("publish_interval_sec", 900.0)
        self.declare_parameter(
            "sensor_data_path",
            str(DATA_ROOT / "ccd_kph/preprocessed_data/pyod_clean_wide_30min.csv"),
        )
        self.declare_parameter(
            "environment_metadata_path",
            str(DATA_ROOT / "ccd_kph/metadata/sensor_environment_groups.csv"),
        )
        self.declare_parameter(
            "prediction_data_path",
            str(DATA_ROOT / "ccd_kph/final_result/data/validation_predictions.csv"),
        )
        self.declare_parameter(
            "image_dir",
            str(DATA_ROOT / "sky/sample_images/test"),
        )
        self.declare_parameter("sensor_limit", 12)
        self.declare_parameter("plant_image_interval", 10)
        self.declare_parameter("start_delay_sec", 5.0)
        self.declare_parameter("warmup_days", 4.0)
        self.declare_parameter("warmup_publish_interval_sec", 1.0)

        self.publish_interval_sec = max(0.1, float(self.get_parameter("publish_interval_sec").value))
        self.start_delay_sec = max(0.0, float(self.get_parameter("start_delay_sec").value))
        self.warmup_days = max(0.0, float(self.get_parameter("warmup_days").value))
        self.warmup_publish_interval_sec = max(
            0.1, float(self.get_parameter("warmup_publish_interval_sec").value)
        )
        self.plant_image_interval = max(1, int(self.get_parameter("plant_image_interval").value))
        self.bridge = CvBridge()

        self.sensor_rows = read_csv_rows(Path(str(self.get_parameter("sensor_data_path").value)))
        self.prediction_rows = read_csv_rows(Path(str(self.get_parameter("prediction_data_path").value)))
        self.metadata = self._load_metadata(Path(str(self.get_parameter("environment_metadata_path").value)))
        self.images = find_images(Path(str(self.get_parameter("image_dir").value)))

        self.selected_sensors = self._select_sensors()
        self.sensor_publishers: Dict[str, rclpy.publisher.Publisher] = {
            code: self.create_publisher(Float64, sensor_topic(code), 10)
            for code in self.selected_sensors
        }
        self.feature_pub = self.create_publisher(String, "/model/features", 10)
        self.image_pub = self.create_publisher(Image, "/plant/image", 10)

        self.row_index = 0
        self.image_index = 0
        self.warmup_row_count = self._compute_warmup_row_count()
        self.started = False
        self.start_at = time.monotonic() + self.start_delay_sec
        self.next_publish_at = self.start_at
        self.start_timer = self.create_timer(0.5, self._maybe_start)
        self.get_logger().info(
            f"demo publisher ready: {len(self.selected_sensors)} sensors, "
            f"{len(self.sensor_rows)} sensor rows, {len(self.prediction_rows)} prediction rows, "
            f"{len(self.images)} images, warmup {self.warmup_row_count} rows "
            f"({self.warmup_days}d) at {self.warmup_publish_interval_sec}s, "
            f"then interval {self.publish_interval_sec}s, start delay {self.start_delay_sec}s"
        )

    def _maybe_start(self) -> None:
        if self.started or time.monotonic() < self.start_at:
            return
        self.started = True
        self.destroy_timer(self.start_timer)
        self.scheduler_timer = self.create_timer(0.2, self._scheduler_tick)
        self._scheduler_tick()

    def _scheduler_tick(self) -> None:
        now = time.monotonic()
        if now < self.next_publish_at:
            return
        published = self._publish_step()
        if not published:
            self.next_publish_at = now + 1.0
            return
        self.next_publish_at = now + self._next_interval_sec()

    def _next_interval_sec(self) -> float:
        if self.row_index < self.warmup_row_count:
            return self.warmup_publish_interval_sec
        return self.publish_interval_sec

    def _compute_warmup_row_count(self) -> int:
        if not self.sensor_rows or self.warmup_days <= 0:
            return 0
        first_timestamp = self.sensor_rows[0].get("timestamp")
        try:
            start = datetime.fromisoformat(str(first_timestamp))
            cutoff = start + timedelta(days=self.warmup_days)
            count = 0
            for row in self.sensor_rows:
                ts = datetime.fromisoformat(str(row.get("timestamp")))
                if ts >= cutoff:
                    break
                count += 1
            return count
        except Exception:
            # Fallback for the current 30-minute dataset: 48 rows/day.
            return min(len(self.sensor_rows), int(round(self.warmup_days * 48)))

    def _load_metadata(self, path: Path) -> Dict[str, Dict[str, str]]:
        rows = read_csv_rows(path)
        return {row.get("sensor_code", ""): row for row in rows if row.get("sensor_code")}

    def _select_sensors(self) -> List[str]:
        limit = max(1, int(self.get_parameter("sensor_limit").value))
        if self.prediction_rows:
            sensors = []
            for row in self.prediction_rows:
                code = row.get("sensor_code", "")
                if code and code not in sensors:
                    sensors.append(code)
                if len(sensors) >= limit:
                    return sensors
        if self.sensor_rows:
            return [c for c in self.sensor_rows[0].keys() if c != "timestamp"][:limit]
        return []

    def _prediction_for(self, sensor_code: str, index: int) -> Dict[str, str]:
        if not self.prediction_rows:
            return {}
        matches = [r for r in self.prediction_rows if r.get("sensor_code") == sensor_code]
        if not matches:
            return {}
        return matches[index % len(matches)]

    def _parse_sensor_value(self, row: Dict[str, str], sensor_code: str) -> Optional[float]:
        raw = (row.get(sensor_code) or "").strip()
        if not raw:
            return None
        try:
            value = float(raw)
        except ValueError:
            return None
        if math.isnan(value) or math.isinf(value):
            return None
        return value

    def _publish_step(self) -> bool:
        if not self.sensor_rows or not self.selected_sensors:
            self.get_logger().warning("no sensor rows or selected sensors available")
            return False

        row = self.sensor_rows[self.row_index % len(self.sensor_rows)]
        timestamp = row.get("timestamp", "")
        phase = "warmup" if self.row_index < self.warmup_row_count else "realtime"
        for sensor_code in self.selected_sensors:
            value = self._parse_sensor_value(row, sensor_code)
            if value is None:
                continue
            self.sensor_publishers[sensor_code].publish(Float64(data=value))

            meta = self.metadata.get(sensor_code, {})
            pred = self._prediction_for(sensor_code, self.row_index)
            threshold = safe_float(pred.get("threshold"), default=1.0790664890079678)
            score = safe_float(pred.get("score"), default=value / 1024.0)
            payload = {
                "timestamp": pred.get("timestamp") or timestamp,
                "sensor_code": sensor_code,
                "sensor_topic": sensor_topic(sensor_code),
                "tree_id": meta.get("tree_id") or pred.get("tree_id") or sensor_code[:3],
                "tree_name": meta.get("tree_name", ""),
                "environment_group": meta.get("environment_group") or meta.get("installation_place") or "unknown",
                "latest_sensor": sensor_code,
                "value": value,
                "unit": "raw",
                "score": score,
                "threshold": threshold,
                "label": safe_int(pred.get("label"), default=0),
                "publish_phase": phase,
            }
            self.feature_pub.publish(String(data=json.dumps(payload, ensure_ascii=False)))

        if self.row_index % self.plant_image_interval == 0:
            self._publish_image()
        self.row_index += 1
        if self.row_index == self.warmup_row_count:
            self.get_logger().info(
                f"4-day warmup complete after {self.warmup_row_count} rows; "
                f"switching to {self.publish_interval_sec}s publish interval"
            )
        return True

    def _publish_image(self) -> None:
        if not self.images:
            return
        path = self.images[self.image_index % len(self.images)]
        self.image_index += 1
        img = cv2.imread(str(path), cv2.IMREAD_COLOR)
        if img is None:
            return
        msg = self.bridge.cv2_to_imgmsg(img, encoding="bgr8")
        label = path.parent.name
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = f"pear_image:{label}:{path.name}"
        self.image_pub.publish(msg)


def main(args=None) -> None:
    rclpy.init(args=args)
    node = DemoPublisherNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
