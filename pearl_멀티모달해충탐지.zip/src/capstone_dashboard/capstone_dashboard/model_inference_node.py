import json
import math
import time
from typing import Any, Dict

import rclpy
from rclpy.node import Node
from std_msgs.msg import String

from .common import safe_float


class ModelInferenceNode(Node):
    def __init__(self) -> None:
        super().__init__("capstone_model_inference")
        self.declare_parameter("default_threshold", 1.0790664890079678)
        self.default_threshold = float(self.get_parameter("default_threshold").value)
        self.pub = self.create_publisher(String, "/model/prediction", 10)
        self.sub = self.create_subscription(String, "/model/features", self._on_features, 50)
        self.get_logger().info("time-series inference node ready")

    def _on_features(self, msg: String) -> None:
        try:
            features: Dict[str, Any] = json.loads(msg.data)
        except json.JSONDecodeError:
            return

        start = time.perf_counter()
        score = safe_float(features.get("score"), 0.0)
        threshold = safe_float(features.get("threshold"), self.default_threshold)
        margin = score - threshold
        probability = 1.0 / (1.0 + math.exp(-8.0 * margin))
        prediction = 1 if score >= threshold else 0
        inference_ms = (time.perf_counter() - start) * 1000.0

        payload = dict(features)
        payload.update(
            {
                "score": score,
                "threshold": threshold,
                "probability": probability,
                "prediction": prediction,
                "inference_ms": inference_ms,
                "model_name": "LOF score replay",
                "updated_at": time.time(),
            }
        )
        self.pub.publish(String(data=json.dumps(payload, ensure_ascii=False)))


def main(args=None) -> None:
    rclpy.init(args=args)
    node = ModelInferenceNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()
