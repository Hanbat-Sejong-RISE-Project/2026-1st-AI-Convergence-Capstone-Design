import csv
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


WORKSPACE_ROOT = Path("/home/khb2439/capstone")
DATA_ROOT = WORKSPACE_ROOT / "data"


def read_csv_rows(path: Path, limit: Optional[int] = None) -> List[Dict[str, str]]:
    if not path.exists():
        return []
    rows: List[Dict[str, str]] = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append(dict(row))
            if limit is not None and len(rows) >= limit:
                break
    return rows


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return default
        result = float(value)
        if math.isnan(result) or math.isinf(result):
            return default
        return result
    except Exception:
        return default


def safe_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(float(value))
    except Exception:
        return default


def sensor_topic(sensor_code: str) -> str:
    token = "".join(ch if ch.isalnum() else "_" for ch in sensor_code)
    return f"/sensors/sensor_{token}"


def find_images(root: Path) -> List[Path]:
    if not root.exists():
        return []
    exts = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
    return sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in exts)


def mean(values: Iterable[float]) -> float:
    vals = list(values)
    return sum(vals) / len(vals) if vals else 0.0
