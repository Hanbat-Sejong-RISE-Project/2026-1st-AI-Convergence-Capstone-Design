from glob import glob
from setuptools import find_packages, setup

package_name = "capstone_dashboard"

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", [f"resource/{package_name}"]),
        (f"share/{package_name}", ["package.xml"]),
        (f"share/{package_name}/launch", glob("launch/*.launch.py")),
        (f"share/{package_name}/web", glob("web/*")),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="khb2439",
    maintainer_email="khb2439@example.com",
    description="ROS 2 web dashboard for capstone sensor and plant image demo.",
    license="MIT",
    entry_points={
        "console_scripts": [
            "dashboard_node = capstone_dashboard.dashboard_node:main",
            "demo_publisher_node = capstone_dashboard.demo_publisher_node:main",
            "model_inference_node = capstone_dashboard.model_inference_node:main",
        ],
    },
)
