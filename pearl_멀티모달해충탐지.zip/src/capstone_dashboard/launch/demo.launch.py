import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    workspace = "/home/khb2439/capstone"
    python_deps = os.path.join(workspace, ".python_deps")
    existing_pythonpath = os.environ.get("PYTHONPATH", "")
    pythonpath = python_deps if not existing_pythonpath else f"{python_deps}:{existing_pythonpath}"

    return LaunchDescription(
        [
            SetEnvironmentVariable("PYTHONPATH", pythonpath),
            DeclareLaunchArgument("host", default_value="127.0.0.1"),
            DeclareLaunchArgument("port", default_value="8080"),
            DeclareLaunchArgument("publish_interval_sec", default_value="900.0"),
            DeclareLaunchArgument("stale_after_sec", default_value="1200.0"),
            DeclareLaunchArgument("image_stale_after_sec", default_value="1200.0"),
            DeclareLaunchArgument("image_classifier_device", default_value="cpu"),
            DeclareLaunchArgument("plant_image_interval", default_value="10"),
            DeclareLaunchArgument("playback_start_delay_sec", default_value="5.0"),
            DeclareLaunchArgument("warmup_days", default_value="4.0"),
            DeclareLaunchArgument("warmup_publish_interval_sec", default_value="1.0"),
            Node(
                package="capstone_dashboard",
                executable="model_inference_node",
                name="capstone_model_inference",
                output="screen",
            ),
            Node(
                package="capstone_dashboard",
                executable="demo_publisher_node",
                name="capstone_demo_publisher",
                output="screen",
                parameters=[
                    {
                        "publish_interval_sec": LaunchConfiguration("publish_interval_sec"),
                        "plant_image_interval": LaunchConfiguration("plant_image_interval"),
                        "start_delay_sec": LaunchConfiguration("playback_start_delay_sec"),
                        "warmup_days": LaunchConfiguration("warmup_days"),
                        "warmup_publish_interval_sec": LaunchConfiguration("warmup_publish_interval_sec"),
                    }
                ],
            ),
            Node(
                package="capstone_dashboard",
                executable="dashboard_node",
                name="capstone_dashboard",
                output="screen",
                parameters=[
                    {
                        "host": LaunchConfiguration("host"),
                        "port": LaunchConfiguration("port"),
                        "stale_after_sec": LaunchConfiguration("stale_after_sec"),
                        "image_stale_after_sec": LaunchConfiguration("image_stale_after_sec"),
                        "image_classifier_device": LaunchConfiguration("image_classifier_device"),
                    }
                ],
            ),
        ]
    )
