# Capstone ROS2 Dashboard

ROS2 Humble 기반 AI 병해충 모니터링 웹 대시보드입니다. Pi에서는 dashboard 서버가 `127.0.0.1:8080`에 bind되고, 사용자 PC에서는 SSH 터널로 `http://localhost:8080`에 접속합니다.

## Build

```bash
cd /home/khb2439/capstone
source /opt/ros/humble/setup.bash
colcon build --symlink-install
source install/setup.bash
```

## Run Full Demo

```bash
ros2 launch capstone_dashboard demo.launch.py image_classifier_device:=cpu
```

빠른 확인이 필요하면 센서 publish 간격을 줄입니다.

```bash
ros2 launch capstone_dashboard demo.launch.py image_classifier_device:=cpu publish_interval_sec:=1.0 stale_after_sec:=5.0 image_stale_after_sec:=15.0
```

## Local PC Access

Pi에서 demo를 실행한 뒤 사용자 PC에서 터널을 엽니다.

```bash
ssh -L 8080:127.0.0.1:8080 khb2439@192.168.0.14
```

브라우저에서 엽니다.

```text
http://localhost:8080
```

## Inference Timing

- 식물 이미지 탭은 MobileNet TorchScript forward pass 시간을 `MobileNet 추론시간`으로 표시합니다.
- 모델 출력 탭은 시계열 score/threshold inference 시간을 센서별 카드와 상단 평균/최근 지표로 표시합니다.
- API에서도 확인할 수 있습니다.

```bash
curl http://localhost:8080/api/state
```

주요 필드:

- `image.classification.inference_ms`
- `image.classification.device`
- `predictions[].inference_ms`
- `timing.mobilenet_inference_ms`
- `timing.timeseries_latest_inference_ms`
- `timing.timeseries_avg_inference_ms`

## Runtime Logs

센서 topic 수신 로그는 다음 파일에 저장되고, `Topic 로그` 탭과 `/api/topic-log`에서 조회됩니다.

```text
/home/khb2439/capstone/runtime_logs/topic_timeseries.csv
```
