import csv
from pathlib import Path

import torch
from torch.optim import AdamW
from torch.utils.data import DataLoader
from tqdm.auto import tqdm
from transformers import get_linear_schedule_with_warmup

from evaluate_model import evaluate_model
from utils.data_utils import paper_collate_fn


def _move_batch(batch, device):
    return {k: v.to(device) if torch.is_tensor(v) else v for k, v in batch.items()}


def _checkpoint(model, tokenizer, output_dir, epoch):
    ckpt_dir = Path(output_dir) / "checkpoints" / f"checkpoint_epoch_{epoch}"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), ckpt_dir / "pytorch_model.bin")
    model.backbone.config.save_pretrained(ckpt_dir)
    tokenizer.save_pretrained(ckpt_dir)


def train_model(model, tokenizer, train_dataset, valid_dataset, test_dataset, encoders, device, output_dir, args):
    output_dir = Path(output_dir)
    logs_dir = output_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    train_loader = DataLoader(train_dataset, batch_size=args.batch_size, shuffle=True, collate_fn=paper_collate_fn)

    optimizer = AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    total_steps = max(len(train_loader) * args.epochs, 1)
    warmup_steps = int(total_steps * args.warmup_ratio)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=warmup_steps, num_training_steps=total_steps)
    scaler = torch.cuda.amp.GradScaler(enabled=bool(args.fp16 and device.type == "cuda"))

    eval_epochs = [args.epochs] if args.debug else [e for e in range(2, args.epochs + 1, 2)]
    if args.epochs not in eval_epochs:
        eval_epochs.append(args.epochs)
    eval_epochs = sorted(set(eval_epochs))

    log_path = logs_dir / "train_log.csv"
    with open(log_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=["epoch", "train_loss"])
        writer.writeheader()

        best_score = -1.0
        best_metrics = None
        final_predictions = None
        for epoch in range(1, args.epochs + 1):
            model.train()
            running_loss = 0.0
            for batch in tqdm(train_loader, desc=f"train epoch {epoch}"):
                batch.pop("meta", None)
                batch = _move_batch(batch, device)
                optimizer.zero_grad(set_to_none=True)
                with torch.cuda.amp.autocast(enabled=bool(args.fp16 and device.type == "cuda")):
                    outputs = model(**batch)
                    loss = outputs["loss"]
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()
                scheduler.step()
                running_loss += float(loss.detach().cpu())

            avg_loss = running_loss / max(len(train_loader), 1)
            writer.writerow({"epoch": epoch, "train_loss": avg_loss})
            f.flush()

            if epoch in eval_epochs:
                metrics, predictions = evaluate_model(model, test_dataset, encoders, device, output_dir, epoch, args)
                _checkpoint(model, tokenizer, output_dir, epoch)
                final_predictions = predictions
                if metrics["hierarchical_score"] > best_score:
                    best_score = metrics["hierarchical_score"]
                    best_metrics = metrics
                    best_dir = output_dir / "best_model"
                    best_dir.mkdir(parents=True, exist_ok=True)
                    torch.save(model.state_dict(), best_dir / "pytorch_model.bin")
                    model.backbone.config.save_pretrained(best_dir)
                    tokenizer.save_pretrained(best_dir)

    final_dir = output_dir / "final_model"
    final_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), final_dir / "pytorch_model.bin")
    model.backbone.config.save_pretrained(final_dir)
    tokenizer.save_pretrained(final_dir)
    return best_metrics, final_predictions
