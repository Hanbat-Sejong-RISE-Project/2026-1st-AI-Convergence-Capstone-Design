import json
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader
from tqdm.auto import tqdm

from utils.data_utils import paper_collate_fn
from utils.label_utils import LEVELS, decode_label
from utils.metrics import compute_metrics
from utils.model_utils import count_parameters
from utils.time_utils import timer


def _move_batch(batch, device):
    return {k: v.to(device) if torch.is_tensor(v) else v for k, v in batch.items()}


def evaluate_model(
    model,
    dataset,
    encoders,
    device,
    output_dir,
    epoch,
    args,
    save_prefix="test",
    eval_subdir="eval",
    metrics_prefix="metrics",
):
    output_dir = Path(output_dir)
    eval_dir = output_dir / eval_subdir
    eval_dir.mkdir(parents=True, exist_ok=True)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, collate_fn=paper_collate_fn)
    model.eval()

    pred_ids = {level: [] for level in LEVELS}
    true_ids = {level: [] for level in LEVELS}
    rows = []

    with torch.no_grad(), timer() as t:
        for batch in tqdm(loader, desc=f"eval epoch {epoch}", leave=False):
            meta = batch.pop("meta")
            batch = _move_batch(batch, device)
            outputs = model(**batch)
            logits = {
                "major": outputs["major_logits"],
                "middle": outputs["middle_logits"],
                "minor": outputs["minor_logits"],
                "detail": outputs["detail_logits"],
            }
            batch_preds = {level: torch.argmax(logits[level], dim=-1).detach().cpu().tolist() for level in LEVELS}
            batch_trues = {
                "major": batch["labels_major"].detach().cpu().tolist(),
                "middle": batch["labels_middle"].detach().cpu().tolist(),
                "minor": batch["labels_minor"].detach().cpu().tolist(),
                "detail": batch["labels_detail"].detach().cpu().tolist(),
            }

            for level in LEVELS:
                pred_ids[level].extend(batch_preds[level])
                true_ids[level].extend(batch_trues[level])

            for i, item in enumerate(meta):
                true_labels = {level: decode_label(encoders, level, batch_trues[level][i]) for level in LEVELS}
                pred_labels = {level: decode_label(encoders, level, batch_preds[level][i]) for level in LEVELS}
                correctness = {level: int(batch_trues[level][i] != -100 and batch_trues[level][i] == batch_preds[level][i]) for level in LEVELS}
                full_correct = int(all(correctness.values()))
                sample_score = sum(correctness.values()) * 0.25
                rows.append({
                    "paper_id": item["paper_id"],
                    "title": item["title"],
                    "abstract": item["abstract"],
                    "true_major": true_labels["major"],
                    "true_middle": true_labels["middle"],
                    "true_minor": true_labels["minor"],
                    "true_detail": true_labels["detail"],
                    "pred_major": pred_labels["major"],
                    "pred_middle": pred_labels["middle"],
                    "pred_minor": pred_labels["minor"],
                    "pred_detail": pred_labels["detail"],
                    "pred_full_tag": " > ".join([pred_labels[level] for level in LEVELS if pred_labels[level]]),
                    "major_correct": correctness["major"],
                    "middle_correct": correctness["middle"],
                    "minor_correct": correctness["minor"],
                    "detail_correct": correctness["detail"],
                    "full_path_correct": full_correct,
                    "hierarchical_score": sample_score,
                })

    metrics = compute_metrics(true_ids, pred_ids)
    total_params, trainable_params = count_parameters(model)
    metrics.update({
        "model_id": args.model_id,
        "model_name": args.model_name,
        "hf_model_name": args.loaded_hf_model_name,
        "epoch": int(epoch),
        "inference_time_total_sec": float(t["elapsed"]),
        "inference_time_per_sample_ms": float(t["elapsed"] / max(len(dataset), 1) * 1000.0),
        "parameter_count": int(total_params),
        "parameter_count_billion": float(total_params / 1e9),
        "trainable_parameter_count": int(trainable_params),
    })

    pd.DataFrame(rows).to_csv(eval_dir / f"{save_prefix}_results_epoch_{epoch}.csv", index=False, encoding="utf-8-sig")
    with open(eval_dir / f"{metrics_prefix}_epoch_{epoch}.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)

    print(
        f"model_id={args.model_id} model_name={args.model_name} epoch={epoch} "
        f"parameter_count={metrics['parameter_count']} parameter_count_billion={metrics['parameter_count_billion']:.6f} "
        f"trainable_parameter_count={metrics['trainable_parameter_count']} "
        f"inference_time_total_sec={metrics['inference_time_total_sec']:.4f} "
        f"inference_time_per_sample_ms={metrics['inference_time_per_sample_ms']:.4f} "
        f"major_accuracy={metrics['major_accuracy']:.4f} middle_accuracy={metrics['middle_accuracy']:.4f} "
        f"minor_accuracy={metrics['minor_accuracy']:.4f} detail_accuracy={metrics['detail_accuracy']:.4f} "
        f"full_path_accuracy={metrics['full_path_accuracy']:.4f} hierarchical_score={metrics['hierarchical_score']:.4f}"
    )
    return metrics, pd.DataFrame(rows)
