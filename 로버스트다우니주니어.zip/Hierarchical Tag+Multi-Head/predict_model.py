import argparse
import json
from pathlib import Path

import pandas as pd
import torch

from utils.data_utils import load_paper_data
from utils.hierarchical_model import HierarchicalMultiHeadClassifier
from utils.label_utils import LEVELS, decode_label, encode_labels, load_label_encoders
from utils.model_registry import get_model_info
from utils.model_utils import get_device, load_tokenizer_and_backbone


def parse_args():
    parser = argparse.ArgumentParser(description="Predict hierarchy labels with a saved classifier checkpoint.")
    parser.add_argument("--model_id", required=True)
    parser.add_argument("--checkpoint_dir", required=True)
    parser.add_argument("--label_encoders", required=True)
    parser.add_argument("--paper_file", default=None)
    parser.add_argument("--title", default=None)
    parser.add_argument("--abstract", default=None)
    parser.add_argument("--output", default="./predictions.csv")
    parser.add_argument("--max_length", type=int, default=512)
    return parser.parse_args()


def _level_count(encoders, level):
    return max(len(encoders[level]["label_to_id"]), 1)


def _predict_text(model, tokenizer, text, device, max_length):
    enc = tokenizer(text, truncation=True, padding="max_length", max_length=max_length, return_tensors="pt")
    enc = {k: v.to(device) for k, v in enc.items()}
    with torch.no_grad():
        out = model(input_ids=enc["input_ids"], attention_mask=enc["attention_mask"])
    return {level: int(torch.argmax(out[f"{level}_logits"], dim=-1).cpu().item()) for level in LEVELS}


def main():
    args = parse_args()
    encoders = load_label_encoders(args.label_encoders)
    model_info = get_model_info(args.model_id)
    tokenizer, backbone, _ = load_tokenizer_and_backbone(model_info)
    model = HierarchicalMultiHeadClassifier(
        backbone,
        _level_count(encoders, "major"),
        _level_count(encoders, "middle"),
        _level_count(encoders, "minor"),
        _level_count(encoders, "detail"),
    )
    state = torch.load(Path(args.checkpoint_dir) / "pytorch_model.bin", map_location="cpu")
    model.load_state_dict(state)
    device = get_device()
    model.to(device)
    model.eval()

    if args.paper_file:
        df, _ = load_paper_data(args.paper_file)
    else:
        df = pd.DataFrame([{"paper_id": "0", "title": args.title or "", "abstract": args.abstract or "", "paper_text": f"{args.title or ''} {args.abstract or ''}".strip()}])

    rows = []
    for _, row in df.iterrows():
        pred = _predict_text(model, tokenizer, row["paper_text"], device, args.max_length)
        pred_labels = {level: decode_label(encoders, level, pred[level]) for level in LEVELS}
        rows.append({
            "paper_id": row.get("paper_id", ""),
            "title": row.get("title", ""),
            "abstract": row.get("abstract", ""),
            "pred_major": pred_labels["major"],
            "pred_middle": pred_labels["middle"],
            "pred_minor": pred_labels["minor"],
            "pred_detail": pred_labels["detail"],
            "pred_full_tag": " > ".join([pred_labels[level] for level in LEVELS if pred_labels[level]]),
        })
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(args.output, index=False, encoding="utf-8-sig")


if __name__ == "__main__":
    main()
