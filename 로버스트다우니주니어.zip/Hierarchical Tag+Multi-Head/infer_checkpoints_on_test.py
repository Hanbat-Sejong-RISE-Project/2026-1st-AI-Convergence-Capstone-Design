import argparse
import json
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoModel, AutoTokenizer

from evaluate_model import evaluate_model
from utils.data_utils import PaperDataset, create_splits, load_paper_data
from utils.hierarchical_model import HierarchicalMultiHeadClassifier
from utils.label_utils import LEVELS, encode_labels, load_label_encoders
from utils.model_registry import get_model_info
from utils.model_utils import get_device, set_seed


def parse_args():
    parser = argparse.ArgumentParser(description="Reload saved even-epoch checkpoints and run test-set inference.")
    parser.add_argument("--model_id", default="2")
    parser.add_argument("--paper_file", default="./dataset/raw_data_en_tag.xlsx")
    parser.add_argument("--output_root", default="./output")
    parser.add_argument("--epochs", default="2,4,6,8,10")
    parser.add_argument("--batch_size", type=int, default=None)
    parser.add_argument("--max_length", type=int, default=None)
    parser.add_argument("--seed", type=int, default=None)
    return parser.parse_args()


def _json_load(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _json_dump(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _format4(value):
    return f"{float(value):.4f}"


def _compact_rows(summary_rows):
    return [
        {
            "epoch": int(row["epoch"]),
            "major_accuracy": _format4(row["major_accuracy"]),
            "middle_accuracy": _format4(row["middle_accuracy"]),
            "minor_accuracy": _format4(row["minor_accuracy"]),
            "detail_accuracy": _format4(row["detail_accuracy"]),
            "full_accuracy": _format4(row["full_path_accuracy"]),
            "hier_accuracy": _format4(row["hierarchical_score"]),
            "inference_total_time": _format4(row["inference_time_total_sec"]),
        }
        for row in summary_rows
    ]


def _level_count(encoders, level):
    return max(len(encoders[level]["label_to_id"]), 1)


def _build_args(base_args, saved_args, epoch):
    merged = dict(saved_args)
    merged["batch_size"] = base_args.batch_size or saved_args.get("batch_size", 8)
    merged["max_length"] = base_args.max_length or saved_args.get("max_length", 512)
    merged["seed"] = base_args.seed or saved_args.get("seed", 42)
    merged["model_id"] = str(base_args.model_id)
    merged["model_name"] = saved_args.get("model_name", get_model_info(str(base_args.model_id)).display_name)
    merged["loaded_hf_model_name"] = saved_args.get("loaded_hf_model_name") or saved_args.get("hf_model_name")
    merged["epoch"] = epoch
    return argparse.Namespace(**merged)


def main():
    cli_args = parse_args()
    model_info = get_model_info(str(cli_args.model_id))
    experiment_dir = Path(cli_args.output_root) / "experiments" / model_info.output_dir_name
    checkpoint_root = experiment_dir / "checkpoints"
    saved_args = _json_load(experiment_dir / "args.json")
    encoders = load_label_encoders(experiment_dir / "label_encoders.json")

    run_args = _build_args(cli_args, saved_args, epoch=0)
    set_seed(run_args.seed)
    df, _ = load_paper_data(cli_args.paper_file)
    encoded_df = encode_labels(df, encoders)
    _, _, test_df, _ = create_splits(encoded_df, seed=run_args.seed)

    device = get_device()
    summary_rows = []
    failed = []
    epochs = [int(e.strip()) for e in str(cli_args.epochs).split(",") if e.strip()]

    for epoch in epochs:
        checkpoint_dir = checkpoint_root / f"checkpoint_epoch_{epoch}"
        state_path = checkpoint_dir / "pytorch_model.bin"
        if not state_path.exists():
            failed.append({"epoch": epoch, "error": f"checkpoint not found: {checkpoint_dir}"})
            continue

        try:
            eval_args = _build_args(cli_args, saved_args, epoch=epoch)
            tokenizer = AutoTokenizer.from_pretrained(checkpoint_dir, trust_remote_code=True)
            backbone_name = eval_args.loaded_hf_model_name or model_info.hf_model_name
            backbone = AutoModel.from_pretrained(backbone_name, trust_remote_code=True)
            model = HierarchicalMultiHeadClassifier(
                backbone=backbone,
                num_major=_level_count(encoders, "major"),
                num_middle=_level_count(encoders, "middle"),
                num_minor=_level_count(encoders, "minor"),
                num_detail=_level_count(encoders, "detail"),
                dropout=saved_args.get("dropout", 0.1),
            )
            state = torch.load(state_path, map_location="cpu")
            model.load_state_dict(state)
            model.to(device)

            test_dataset = PaperDataset(test_df, tokenizer, eval_args.max_length)
            metrics, _ = evaluate_model(
                model=model,
                dataset=test_dataset,
                encoders=encoders,
                device=device,
                output_dir=experiment_dir,
                epoch=epoch,
                args=eval_args,
                save_prefix="reloaded_test",
                metrics_prefix="reloaded_metrics",
            )
            summary_rows.append(metrics)
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()
        except Exception as exc:
            failed.append({"epoch": epoch, "error": repr(exc)})

    summary_path = experiment_dir / "eval" / "reloaded_checkpoint_summary.csv"
    pd.DataFrame(summary_rows).to_csv(summary_path, index=False, encoding="utf-8-sig")
    _json_dump({"results": summary_rows, "failures": failed}, experiment_dir / "eval" / "reloaded_checkpoint_summary.json")
    compact = _compact_rows(summary_rows)
    pd.DataFrame(compact).to_csv(
        experiment_dir / "eval" / "reloaded_checkpoint_compact_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    _json_dump(compact, experiment_dir / "eval" / "reloaded_checkpoint_compact_summary.json")
    if failed:
        raise RuntimeError(f"Some checkpoint inferences failed: {failed}")


if __name__ == "__main__":
    main()
