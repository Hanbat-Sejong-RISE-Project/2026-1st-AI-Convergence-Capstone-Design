import argparse
import json
import traceback
from pathlib import Path

import pandas as pd

from train_hierarchical_classifier import train_model
from utils.data_utils import PaperDataset, create_splits, load_category_table, load_paper_data, save_data_splits
from utils.hierarchical_model import HierarchicalMultiHeadClassifier
from utils.label_utils import LEVELS, build_label_encoders, encode_labels, save_label_encoders
from utils.model_registry import expand_model_ids, get_model_info
from utils.model_utils import get_device, load_tokenizer_and_backbone, set_seed


def parse_args():
    parser = argparse.ArgumentParser(description="Supervised hierarchical multi-head classifier model comparison.")
    parser.add_argument("--model_id", default="2", help="1-8 or all")
    parser.add_argument("--paper_file", default="./dataset/raw_data_en_tag.xlsx")
    parser.add_argument("--category_csv", default="./dataset/한국연구재단학문분류표_영문.csv")
    parser.add_argument("--output_root", default="./output")
    parser.add_argument("--epochs", type=int, default=10)
    parser.add_argument("--batch_size", type=int, default=8)
    parser.add_argument("--learning_rate", type=float, default=2e-5)
    parser.add_argument("--max_length", type=int, default=512)
    parser.add_argument("--debug", action="store_true")
    parser.add_argument("--weight_decay", type=float, default=0.01)
    parser.add_argument("--warmup_ratio", type=float, default=0.1)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--fp16", action="store_true")
    parser.add_argument("--title_col", default=None)
    parser.add_argument("--abstract_col", default=None)
    parser.add_argument("--major_col", default=None)
    parser.add_argument("--middle_col", default=None)
    parser.add_argument("--minor_col", default=None)
    parser.add_argument("--detail_col", default=None)
    return parser.parse_args()


def _json_dump(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _prepare_data(args):
    load_category_table(args.category_csv)
    overrides = {
        "title": args.title_col,
        "abstract": args.abstract_col,
        "major": args.major_col,
        "middle": args.middle_col,
        "minor": args.minor_col,
        "detail": args.detail_col,
    }
    df, detected_columns = load_paper_data(args.paper_file, overrides)
    if args.debug:
        df = df.sample(n=min(len(df), 64), random_state=args.seed).reset_index(drop=True)
        args.epochs = 1
    encoders = build_label_encoders(df)
    encoded_df = encode_labels(df, encoders)
    train_df, valid_df, test_df, split_log = create_splits(encoded_df, seed=args.seed)
    split_log["detected_columns"] = detected_columns
    split_log["num_total_after_filter"] = int(len(encoded_df))
    return train_df, valid_df, test_df, encoders, split_log


def _level_count(encoders, level):
    return max(len(encoders[level]["label_to_id"]), 1)


def _run_single_model(model_id, base_args, train_df, valid_df, test_df, encoders, split_log):
    model_info = get_model_info(model_id)
    output_dir = Path(base_args.output_root) / "experiments" / model_info.output_dir_name
    output_dir.mkdir(parents=True, exist_ok=True)

    args = argparse.Namespace(**vars(base_args))
    args.model_id = model_id
    args.model_name = model_info.display_name
    args.hf_model_name = model_info.hf_model_name
    args.parameter_billion_hint = model_info.parameter_billion_hint
    set_seed(args.seed)

    tokenizer, backbone, loaded_name = load_tokenizer_and_backbone(model_info)
    args.loaded_hf_model_name = loaded_name
    model = HierarchicalMultiHeadClassifier(
        backbone=backbone,
        num_major=_level_count(encoders, "major"),
        num_middle=_level_count(encoders, "middle"),
        num_minor=_level_count(encoders, "minor"),
        num_detail=_level_count(encoders, "detail"),
        dropout=args.dropout,
    )
    device = get_device()
    model.to(device)

    _json_dump(vars(args), output_dir / "args.json")
    save_label_encoders(encoders, output_dir / "label_encoders.json")
    save_data_splits(output_dir / "data_splits.json", split_log)

    train_dataset = PaperDataset(train_df, tokenizer, args.max_length)
    valid_dataset = PaperDataset(valid_df, tokenizer, args.max_length)
    test_dataset = PaperDataset(test_df, tokenizer, args.max_length)

    best_metrics, final_predictions = train_model(
        model=model,
        tokenizer=tokenizer,
        train_dataset=train_dataset,
        valid_dataset=valid_dataset,
        test_dataset=test_dataset,
        encoders=encoders,
        device=device,
        output_dir=output_dir,
        args=args,
    )
    if best_metrics is None:
        raise RuntimeError("Training completed without evaluation metrics.")

    _json_dump(best_metrics, output_dir / "eval" / "final_metrics.json")
    pd.DataFrame([best_metrics]).to_csv(output_dir / "eval" / "final_summary.csv", index=False, encoding="utf-8-sig")
    predictions_dir = output_dir / "predictions"
    predictions_dir.mkdir(parents=True, exist_ok=True)
    if final_predictions is not None:
        final_predictions.to_excel(predictions_dir / "final_predictions.xlsx", index=False)
    return best_metrics


def main():
    args = parse_args()
    Path(args.output_root).mkdir(parents=True, exist_ok=True)
    model_ids = expand_model_ids(args.model_id)
    train_df, valid_df, test_df, encoders, split_log = _prepare_data(args)

    comparison_rows = []
    failures = []
    for model_id in model_ids:
        try:
            comparison_rows.append(_run_single_model(model_id, args, train_df, valid_df, test_df, encoders, split_log))
        except Exception as exc:
            error = {"model_id": model_id, "error": str(exc), "traceback": traceback.format_exc()}
            failures.append(error)
            if str(args.model_id).lower() != "all":
                print(json.dumps(error, ensure_ascii=False, indent=2))
                raise
            print(f"[FAILED] model_id={model_id}: {exc}")

    comparison_dir = Path(args.output_root) / "model_comparison"
    comparison_dir.mkdir(parents=True, exist_ok=True)
    columns = [
        "model_id", "model_name", "hf_model_name", "parameter_count", "parameter_count_billion",
        "trainable_parameter_count", "epoch", "inference_time_total_sec", "inference_time_per_sample_ms",
        "major_accuracy", "middle_accuracy", "minor_accuracy", "detail_accuracy", "full_path_accuracy",
        "hierarchical_score", "major_macro_f1", "middle_macro_f1", "minor_macro_f1", "detail_macro_f1",
        "major_weighted_f1", "middle_weighted_f1", "minor_weighted_f1", "detail_weighted_f1",
    ]
    comparison_df = pd.DataFrame(comparison_rows)
    for col in columns:
        if col not in comparison_df.columns:
            comparison_df[col] = None
    comparison_df[columns].to_csv(comparison_dir / "final_model_comparison.csv", index=False, encoding="utf-8-sig")
    _json_dump({"results": comparison_rows, "failures": failures}, comparison_dir / "final_model_comparison.json")
    if failures:
        _json_dump(failures, comparison_dir / "failures.json")


if __name__ == "__main__":
    main()
