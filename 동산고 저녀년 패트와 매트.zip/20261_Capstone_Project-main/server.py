"""
server.py — FastAPI 서버
─────────────────────────────────────────────────────────
학과 서버(또는 업체 서버)에서 실행합니다.

분산 배포:  python server.py           → API만 제공
단일 배포:  config.yaml의 serve_frontend: true → 웹사이트도 함께 제공
"""

import io
import os
import sys
import uuid
import base64
from contextlib import asynccontextmanager
from threading import Lock, Thread
from typing import Dict, List, Optional


def _ensure_conda_libstdcxx_first():
    """cumesh/TRELLIS.2가 conda의 최신 libstdc++를 먼저 보도록 재실행합니다."""
    if os.environ.get("DONGSAN_LIBSTDCXX_READY") == "1":
        return

    conda_prefix = sys.prefix or os.environ.get("CONDA_PREFIX", "")
    conda_lib = os.path.join(conda_prefix, "lib")
    libstdcxx = os.path.join(conda_lib, "libstdc++.so.6")
    if not os.path.exists(libstdcxx):
        return

    current_paths = os.environ.get("LD_LIBRARY_PATH", "").split(":")
    if current_paths and current_paths[0] == conda_lib:
        os.environ["DONGSAN_LIBSTDCXX_READY"] = "1"
        return

    env = os.environ.copy()
    env["LD_LIBRARY_PATH"] = (
        conda_lib
        if not env.get("LD_LIBRARY_PATH")
        else f"{conda_lib}:{env['LD_LIBRARY_PATH']}"
    )
    env["DONGSAN_LIBSTDCXX_READY"] = "1"
    argv = getattr(sys, "orig_argv", [sys.executable, *sys.argv])
    os.execvpe(sys.executable, argv, env)


_ensure_conda_libstdcxx_first()

import uvicorn
from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from PIL import Image

from pipeline import load_config, PipelineManager
from reconstruction import run_reconstruction, RECONSTRUCTION_METHODS

# ═══════════════════════════════════════════════════════
# 설정 로드
# ═══════════════════════════════════════════════════════
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.environ.get("CONFIG_PATH", os.path.join(BASE_DIR, "config.yaml"))
config = load_config(CONFIG_PATH)
manager: Optional[PipelineManager] = None
GENERATED_IMAGES_DIR = os.path.join(config.paths.output_dir, "generated_images")
GENERATION_JOBS: Dict[str, Dict[str, object]] = {}
GENERATION_JOBS_LOCK = Lock()


# ═══════════════════════════════════════════════════════
# FastAPI 앱 (lifespan으로 모델 초기화)
# ═══════════════════════════════════════════════════════
@asynccontextmanager
async def lifespan(app: FastAPI):
    global manager
    print("🚀 서버 시작 — 모델 로딩 중...")
    manager = PipelineManager(config)
    manager.load_all()
    print("✅ 모든 모델 로드 완료. 서버 준비됨.")
    yield
    print("🛑 서버 종료")


app = FastAPI(
    title="2D→3D Pipeline API",
    description="2D 이미지 합병 및 3D 모델링 생성 파이프라인",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS 허용 (로컬 프론트엔드에서의 호출을 허용)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs(GENERATED_IMAGES_DIR, exist_ok=True)
app.mount(
    "/generated",
    StaticFiles(directory=GENERATED_IMAGES_DIR),
    name="generated_images",
)


def _generated_image_url(job_id: str, filename: str) -> str:
    return f"/generated/{job_id}/{filename}"


def _save_generated_image(img: Image.Image, job_id: str, index: int) -> Dict[str, object]:
    job_dir = os.path.join(GENERATED_IMAGES_DIR, job_id)
    os.makedirs(job_dir, exist_ok=True)
    filename = f"image_{index:03d}.png"
    path = os.path.join(job_dir, filename)
    img.save(path, format="PNG")
    return {
        "index": index,
        "filename": filename,
        "url": _generated_image_url(job_id, filename),
    }


def _create_generation_job(job_id: str, total: int) -> None:
    with GENERATION_JOBS_LOCK:
        GENERATION_JOBS[job_id] = {
            "job_id": job_id,
            "status": "queued",
            "total": total,
            "completed": 0,
            "images": [],
            "error": None,
        }


def _update_generation_job(job_id: str, **updates: object) -> None:
    with GENERATION_JOBS_LOCK:
        if job_id in GENERATION_JOBS:
            GENERATION_JOBS[job_id].update(updates)


def _append_generation_image(job_id: str, image_info: Dict[str, object]) -> None:
    with GENERATION_JOBS_LOCK:
        job = GENERATION_JOBS.get(job_id)
        if not job:
            return
        images = list(job.get("images", []))
        images.append(image_info)
        job["images"] = images
        job["completed"] = len(images)


def _generation_job_snapshot(job_id: str) -> Dict[str, object]:
    with GENERATION_JOBS_LOCK:
        job = GENERATION_JOBS.get(job_id)
        return dict(job) if job else {}


def _run_live_generation_job(
    job_id: str,
    style_img: Image.Image,
    struct_img: Image.Image,
    prompt: str,
    negative_prompt: str,
    num_images: int,
    depth_conditioning_scale: Optional[float],
    lineart_conditioning_scale: Optional[float],
    ip_adapter_scale: Optional[float],
    guidance_scale: Optional[float],
    num_inference_steps: Optional[int],
) -> None:
    if manager is None:
        _update_generation_job(job_id, status="failed", error="models are not loaded")
        return

    _update_generation_job(job_id, status="running")

    # ✅ 실제로 사용될 프롬프트 확인 (로그)
    print(f"\n📋 [Job {job_id}] 생성 시작 - 실제 사용 값:")
    print(f"   프롬프트: {repr(prompt[:80] if prompt else 'None')}")
    print(f"   네거티브 프롬프트: {repr(negative_prompt[:80] if negative_prompt else 'None')}")

    def handle_generated_image(img: Image.Image, index: int, seed: int) -> None:
        saved = _save_generated_image(img, job_id, index)
        saved["seed"] = seed
        _append_generation_image(job_id, saved)

    try:
        manager.generate_images(
            style_image=style_img,
            structure_image=struct_img,
            prompt=prompt,
            negative_prompt=negative_prompt,
            num_images=num_images,
            on_image=handle_generated_image,
            depth_conditioning_scale=depth_conditioning_scale,
            lineart_conditioning_scale=lineart_conditioning_scale,
            ip_adapter_scale=ip_adapter_scale,
            guidance_scale=guidance_scale,
            num_inference_steps=num_inference_steps,
        )
        print(f"✅ [Job {job_id}] 생성 완료\n")
        _update_generation_job(job_id, status="success")
    except Exception as exc:
        print(f"❌ [Job {job_id}] 생성 실패: {str(exc)}\n")
        _update_generation_job(job_id, status="failed", error=str(exc))


# ═══════════════════════════════════════════════════════
# 프론트엔드 정적 파일 서빙 (단일 배포 모드)
# ═══════════════════════════════════════════════════════
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

if config.server.serve_frontend and os.path.isdir(FRONTEND_DIR):
    # "/" 경로에서 index.html 제공
    @app.get("/")
    async def serve_index():
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

    # 정적 파일 (CSS, JS, 이미지 등)
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="frontend")


# ═══════════════════════════════════════════════════════
# API 엔드포인트
# ═══════════════════════════════════════════════════════

@app.get("/health")
async def health():
    """서버 상태 확인"""
    return {"status": "ok", "models_loaded": manager is not None}


@app.get("/defaults")
async def get_defaults():
    """기본 생성 설정 값 반환"""
    return {
        "prompt": config.generation.prompt,
        "negative_prompt": config.generation.negative_prompt,
        "depth_conditioning_scale": config.generation.depth_conditioning_scale,
        "lineart_conditioning_scale": config.generation.lineart_conditioning_scale,
        "ip_adapter_scale": config.generation.ip_adapter_scale,
        "guidance_scale": config.generation.guidance_scale,
        "num_inference_steps": config.generation.num_inference_steps,
    }


@app.post("/generate")
async def generate_2d(
    style_image: UploadFile = File(..., description="스타일 참조 이미지 (예: 복숭아)"),
    structure_image: UploadFile = File(..., description="구조 참조 이미지 (예: 에어팟 케이스)"),
    prompt: str = Form("", description="생성 프롬프트"),
    negative_prompt: str = Form("", description="네거티브 프롬프트"),
    num_images: int = Form(4, ge=1, le=20, description="생성할 이미지의 개수"),
    depth_conditioning_scale: Optional[float] = Form(None, ge=0.0, le=2.0, description="Depth 반영 강도"),
    lineart_conditioning_scale: Optional[float] = Form(None, ge=0.0, le=2.0, description="윤곽선 반영 강도"),
    ip_adapter_scale: Optional[float] = Form(None, ge=0.0, le=2.0, description="디자인 이미지 반영 강도"),
    guidance_scale: Optional[float] = Form(None, ge=1.0, le=15.0, description="프롬프트 반영 강도"),
    num_inference_steps: Optional[int] = Form(None, ge=10, le=60, description="생성 단계 수"),
):
    """
    스타일 이미지 + 구조 이미지 → 2D 이미지 합병 생성
    생성된 이미지를 base64로 반환합니다.
    """
    if manager is None:
        raise HTTPException(503, "모델이 아직 로드되지 않았습니다.")

    try:
        # 이미지 읽기
        style_img = Image.open(io.BytesIO(await style_image.read())).convert("RGB")
        struct_img = Image.open(io.BytesIO(await structure_image.read())).convert("RGB")
        job_id = uuid.uuid4().hex[:12]
        saved_images: List[Dict[str, object]] = []

        def handle_generated_image(img: Image.Image, index: int, seed: int) -> None:
            saved = _save_generated_image(img, job_id, index)
            saved["seed"] = seed
            saved_images.append(saved)

        # 생성
        images = manager.generate_images(
            style_image=style_img,
            structure_image=struct_img,
            prompt=prompt,
            negative_prompt=negative_prompt,
            num_images=num_images,
            on_image=handle_generated_image,
            depth_conditioning_scale=depth_conditioning_scale,
            lineart_conditioning_scale=lineart_conditioning_scale,
            ip_adapter_scale=ip_adapter_scale,
            guidance_scale=guidance_scale,
            num_inference_steps=num_inference_steps,
        )

        # base64로 인코딩하여 반환
        result = []
        for i, img in enumerate(images):
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            b64 = base64.b64encode(buf.getvalue()).decode("utf-8")
            saved = saved_images[i] if i < len(saved_images) else _save_generated_image(img, job_id, i)
            result.append({
                "index": i,
                "image_base64": b64,
                "image_url": saved["url"],
                "filename": saved["filename"],
                "seed": saved.get("seed"),
            })

        return JSONResponse({"status": "success", "job_id": job_id, "images": result})

    except Exception as e:
        raise HTTPException(500, f"이미지 생성 실패: {str(e)}")


@app.post("/generate-live")
async def generate_2d_live(
    style_image: UploadFile = File(..., description="스타일 참조 이미지 (예: 복숭아)"),
    structure_image: UploadFile = File(..., description="구조 참조 이미지 (예: 에어팟 케이스)"),
    prompt: str = Form("", description="생성 프롬프트"),
    negative_prompt: str = Form("", description="네거티브 프롬프트"),
    num_images: int = Form(4, ge=1, le=20, description="생성할 이미지의 개수"),
    depth_conditioning_scale: Optional[float] = Form(None, ge=0.0, le=2.0, description="Depth 반영 강도"),
    lineart_conditioning_scale: Optional[float] = Form(None, ge=0.0, le=2.0, description="윤곽선 반영 강도"),
    ip_adapter_scale: Optional[float] = Form(None, ge=0.0, le=2.0, description="디자인 이미지 반영 강도"),
    guidance_scale: Optional[float] = Form(None, ge=1.0, le=15.0, description="프롬프트 반영 강도"),
    num_inference_steps: Optional[int] = Form(None, ge=10, le=60, description="생성 단계 수"),
):
    """
    이미지 생성을 백그라운드에서 시작하고 job_id를 즉시 반환합니다.
    프론트엔드는 /generated-images/{job_id}를 조회해 완성된 이미지를 바로 표시할 수 있습니다.
    """
    if manager is None:
        raise HTTPException(503, "모델이 아직 로드되지 않았습니다.")

    try:
        # ✅ 프론트엔드에서 수신한 값 확인
        print(f"\n🔧 [API /generate-live] 요청 수신")
        print(f"   프롬프트 (수신): {repr(prompt[:80] if prompt else '(빈 문자열 = 서버 기본값 사용)')}")
        print(f"   네거티브 프롬프트 (수신): {repr(negative_prompt[:80] if negative_prompt else '(빈 문자열 = 서버 기본값 사용)')}")
        
        style_img = Image.open(io.BytesIO(await style_image.read())).convert("RGB")
        struct_img = Image.open(io.BytesIO(await structure_image.read())).convert("RGB")
        job_id = uuid.uuid4().hex[:12]
        _create_generation_job(job_id, num_images)

        Thread(
            target=_run_live_generation_job,
            args=(
                job_id,
                style_img,
                struct_img,
                prompt,
                negative_prompt,
                num_images,
                depth_conditioning_scale,
                lineart_conditioning_scale,
                ip_adapter_scale,
                guidance_scale,
                num_inference_steps,
            ),
            daemon=True,
        ).start()

        return JSONResponse({
            "status": "queued",
            "job_id": job_id,
            "images_url": f"/generated-images/{job_id}",
        })

    except Exception as e:
        raise HTTPException(500, f"이미지 생성 시작 실패: {str(e)}")


@app.post("/generate-3d")
async def generate_3d(
    image: UploadFile = File(..., description="3D로 변환할 이미지"),
    filename: str = Form("", description="출력 파일명 (확장자 없이)"),
    seed: int = Form(42, description="시드"),
):
    """
    2D 이미지 → 3D GLB 모델 변환
    생성된 GLB 파일을 다운로드합니다.
    """
    if manager is None:
        raise HTTPException(503, "모델이 아직 로드되지 않았습니다.")

    try:
        img = Image.open(io.BytesIO(await image.read())).convert("RGB")
        fname = filename.strip() or f"model_{uuid.uuid4().hex[:8]}"

        glb_path = manager.generate_3d(image=img, filename=fname, seed=seed)

        return FileResponse(
            glb_path,
            media_type="model/gltf-binary",
            filename=f"{fname}.glb",
        )

    except Exception as e:
        raise HTTPException(500, f"3D 변환 실패: {str(e)}")


# ── 생성된 2D 이미지 목록 조회 ────────────────────────────
@app.get("/generated-images")
async def list_generated_image_jobs():
    """생성된 이미지가 저장된 2D 생성 작업 목록을 반환합니다."""
    if not os.path.isdir(GENERATED_IMAGES_DIR):
        return {"jobs": []}
    jobs = [
        name
        for name in sorted(os.listdir(GENERATED_IMAGES_DIR), reverse=True)
        if os.path.isdir(os.path.join(GENERATED_IMAGES_DIR, name))
    ]
    return {"jobs": jobs}


@app.get("/generated-images/{job_id}")
async def list_generated_images(job_id: str):
    """특정 2D 생성 작업에서 지금까지 저장된 이미지를 반환합니다."""
    job_dir = os.path.join(GENERATED_IMAGES_DIR, job_id)
    job = _generation_job_snapshot(job_id)
    if not os.path.isdir(job_dir) and not job:
        raise HTTPException(404, "image job not found")
    files = []
    if os.path.isdir(job_dir):
        files = [f for f in sorted(os.listdir(job_dir)) if f.lower().endswith(".png")]
    disk_images = [
        {"index": i, "filename": filename, "url": _generated_image_url(job_id, filename)}
        for i, filename in enumerate(files)
    ]
    if not job:
        return {"job_id": job_id, "status": "unknown", "images": disk_images}
    if not job.get("images"):
        job["images"] = disk_images
    return job


MODEL_DOWNLOAD_TYPES = {
    "glb": "model/gltf-binary",
    "stl": "model/stl",
    "3mf": "application/vnd.ms-package.3dmanufacturing-3dmodel+xml",
}


def _safe_model_filename(filename: str) -> str:
    safe = os.path.basename(filename)
    if not safe or safe != filename:
        raise HTTPException(400, "잘못된 파일명입니다.")
    return safe


def _find_generated_glb(base_name: str) -> str:
    output_dir = config.paths.output_dir
    suffix = config.mesh.real_scale_suffix if config.mesh.real_scale_enabled else ""
    candidates = []
    if suffix and not base_name.endswith(suffix):
        candidates.append(f"{base_name}{suffix}.glb")
    candidates.append(f"{base_name}.glb")

    for candidate in candidates:
        path = os.path.join(output_dir, candidate)
        if os.path.isfile(path):
            return path
    raise HTTPException(404, "GLB 원본 파일을 찾을 수 없습니다.")


def _convert_model(source_path: str, target_path: str) -> str:
    if os.path.isfile(target_path):
        return target_path

    import trimesh

    mesh = trimesh.load(source_path, force="mesh")
    if mesh.is_empty:
        raise HTTPException(500, "모델 변환 실패: 비어 있는 메시입니다.")
    mesh.export(target_path)
    return target_path


@app.get("/models")
async def list_models():
    """output_dir에 저장된 GLB 파일 목록을 반환합니다."""
    output_dir = config.paths.output_dir
    if not os.path.isdir(output_dir):
        return {"files": []}
    files = [f for f in os.listdir(output_dir) if f.endswith(".glb")]
    return {"files": files}


@app.get("/models/{filename}")
async def download_model(filename: str):
    """생성된 3D 모델을 GLB/STL/3MF 중 요청한 확장자로 다운로드합니다."""
    try:
        safe_filename = _safe_model_filename(filename)
        base_name, ext = os.path.splitext(safe_filename)
        model_format = ext.lstrip(".").lower()
        if model_format not in MODEL_DOWNLOAD_TYPES:
            raise HTTPException(400, "지원하지 않는 모델 형식입니다.")

        source_glb = _find_generated_glb(base_name)
        if model_format == "glb":
            filepath = source_glb
        else:
            filepath = _convert_model(
                source_path=source_glb,
                target_path=os.path.join(config.paths.output_dir, f"{base_name}.{model_format}"),
            )

        return FileResponse(
            filepath,
            media_type=MODEL_DOWNLOAD_TYPES[model_format],
            filename=f"{base_name}.{model_format}",
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(500, f"모델 다운로드 실패: {exc}") from exc


# ── 3D 재구성 ─────────────────────────────────────────
RECONSTRUCTED_DIR = os.path.join(config.paths.output_dir, "reconstructed")
os.makedirs(RECONSTRUCTED_DIR, exist_ok=True)


@app.get("/reconstruct-methods")
async def list_reconstruct_methods():
    """사용 가능한 3D 재구성 방식과 각 방식의 하이퍼파라미터 정의를 반환합니다."""
    methods = {}
    for key, entry in RECONSTRUCTION_METHODS.items():
        methods[key] = {
            "name": entry["name"],
            "description": entry["description"],
            "params": entry["params"],
        }
    return {"methods": methods}


RECONSTRUCT_SUPPORTED_EXTS = {".glb", ".gltf", ".stl", ".3mf"}


@app.post("/reconstruct-3d")
async def reconstruct_3d(
    model_file: UploadFile = File(..., description="재구성할 3D 모델 (GLB/STL/3MF)"),
    method: str = Form("poisson", description="재구성 방식"),
    depth: Optional[int] = Form(None, description="포아송 깊이"),
    taubin_iterations: Optional[int] = Form(None, description="평활화 반복 횟수"),
    normal_radius: Optional[float] = Form(None, description="법선 추정 반경"),
    normal_max_nn: Optional[int] = Form(None, description="법선 최대 이웃 수"),
    simplify_ratio: Optional[float] = Form(None, description="단순화 비율"),
    alpha: Optional[float] = Form(None, description="알파 값 (오목 껍질 반경)"),
    pitch: Optional[float] = Form(None, description="복셀 해상도 (내부 채우기)"),
):
    """
    3D 모델 재구성: 업로드된 GLB/STL/3MF를 재구성하여 GLB로 반환합니다.
    """
    # 파일 확장자 확인
    original_name = model_file.filename or "model.glb"
    _, ext = os.path.splitext(original_name.lower())
    if ext not in RECONSTRUCT_SUPPORTED_EXTS:
        raise HTTPException(
            400,
            f"지원하지 않는 형식입니다: {ext}. 지원: {', '.join(RECONSTRUCT_SUPPORTED_EXTS)}",
        )

    # 임시 파일로 저장
    job_id = uuid.uuid4().hex[:12]
    upload_path = os.path.join(config.paths.upload_dir, f"recon_{job_id}{ext}")
    output_path = os.path.join(RECONSTRUCTED_DIR, f"recon_{job_id}.glb")

    try:
        contents = await model_file.read()
        with open(upload_path, "wb") as f:
            f.write(contents)

        # 하이퍼파라미터 구성
        kwargs = {}
        if depth is not None:
            kwargs["depth"] = depth
        if taubin_iterations is not None:
            kwargs["taubin_iterations"] = taubin_iterations
        if normal_radius is not None:
            kwargs["normal_radius"] = normal_radius
        if normal_max_nn is not None:
            kwargs["normal_max_nn"] = normal_max_nn
        if simplify_ratio is not None:
            kwargs["simplify_ratio"] = simplify_ratio
        if alpha is not None:
            kwargs["alpha"] = alpha
        if pitch is not None:
            kwargs["pitch"] = pitch

        result = run_reconstruction(
            method=method,
            input_path=upload_path,
            output_path=output_path,
            **kwargs,
        )

        return FileResponse(
            result.output_path,
            media_type="model/gltf-binary",
            filename=f"reconstructed_{job_id}.glb",
            headers={
                "X-Recon-Method": result.method,
                "X-Recon-Watertight": str(result.is_watertight),
                "X-Recon-Vertices": str(result.vertex_count),
                "X-Recon-Faces": str(result.face_count),
                "X-Recon-Job-Id": job_id,
            },
        )

    except ValueError as ve:
        raise HTTPException(400, str(ve))
    except Exception as e:
        raise HTTPException(500, f"3D 재구성 실패: {str(e)}")
    finally:
        # 업로드 임시 파일 정리
        if os.path.exists(upload_path):
            try:
                os.remove(upload_path)
            except OSError:
                pass


@app.get("/reconstructed-models/{filename}")
async def download_reconstructed_model(filename: str):
    """후처리된 3D 모델을 GLB/STL/3MF 중 요청한 확장자로 다운로드합니다."""
    try:
        safe_filename = _safe_model_filename(filename)
        base_name, ext = os.path.splitext(safe_filename)
        model_format = ext.lstrip(".").lower()
        if model_format not in MODEL_DOWNLOAD_TYPES:
            raise HTTPException(400, "지원하지 않는 모델 형식입니다.")

        # 원본 GLB 파일 찾기
        source_glb = os.path.join(RECONSTRUCTED_DIR, f"{base_name}.glb")
        if not os.path.isfile(source_glb):
            raise HTTPException(404, "GLB 원본 파일을 찾을 수 없습니다.")

        if model_format == "glb":
            filepath = source_glb
        else:
            filepath = _convert_model(
                source_path=source_glb,
                target_path=os.path.join(RECONSTRUCTED_DIR, f"{base_name}.{model_format}"),
            )

        return FileResponse(
            filepath,
            media_type=MODEL_DOWNLOAD_TYPES[model_format],
            filename=safe_filename,
        )
    except Exception as e:
        raise HTTPException(500, f"모델 다운로드 오류: {str(e)}")


@app.post("/convert-to-glb")
async def convert_to_glb(
    model_file: UploadFile = File(..., description="GLB로 변환할 3D 모델")
):
    """
    업로드된 3D 모델(STL, 3MF 등)을 GLB 형식으로 변환하여 반환합니다. (뷰어용)
    """
    original_name = model_file.filename or "model"
    base_name, ext = os.path.splitext(original_name)
    ext_lower = ext.lower()
    
    if ext_lower not in RECONSTRUCT_SUPPORTED_EXTS:
        raise HTTPException(400, f"지원하지 않는 형식입니다: {ext_lower}")
        
    job_id = uuid.uuid4().hex[:12]
    upload_path = os.path.join(config.paths.upload_dir, f"tmp_convert_{job_id}{ext_lower}")
    output_path = os.path.join(config.paths.upload_dir, f"converted_{job_id}.glb")
    
    try:
        contents = await model_file.read()
        with open(upload_path, "wb") as f:
            f.write(contents)
            
        import trimesh
        mesh = trimesh.load(upload_path, force="mesh")
        if mesh.is_empty:
            raise ValueError("모델이 비어있거나 읽을 수 없습니다.")
            
        mesh.export(output_path)
        
        return FileResponse(
            output_path,
            media_type="model/gltf-binary",
            filename=f"{base_name}.glb"
        )
    except Exception as e:
        raise HTTPException(500, f"GLB 변환 실패: {str(e)}")
    finally:
        if os.path.exists(upload_path):
            try: os.remove(upload_path)
            except: pass


@app.post("/calculate-pitch")
async def calculate_pitch(
    model_file: UploadFile = File(..., description="업로드할 3D 모델")
):
    """
    업로드된 모델의 크기를 분석하여 적절한 내부 채우기 복셀 해상도(pitch)를 제안합니다.
    """
    original_name = model_file.filename or "model.glb"
    _, ext = os.path.splitext(original_name.lower())
    if ext not in RECONSTRUCT_SUPPORTED_EXTS:
        return {"pitch": 0.1}

    job_id = uuid.uuid4().hex[:12]
    upload_path = os.path.join(config.paths.upload_dir, f"tmp_pitch_{job_id}{ext}")
    
    try:
        contents = await model_file.read()
        with open(upload_path, "wb") as f:
            f.write(contents)
        
        import trimesh
        mesh = trimesh.load(upload_path, force="mesh")
        max_extent = mesh.bounding_box.extents.max()
        
        if max_extent > 0:
            auto_pitch = max_extent / 200.0
            return {"pitch": round(auto_pitch, 4)}
        else:
            return {"pitch": 0.1}
            
    except Exception as e:
        print(f"Pitch 계산 오류: {e}")
        return {"pitch": 0.1}
    finally:
        if os.path.exists(upload_path):
            os.remove(upload_path)

# ═══════════════════════════════════════════════════════
# 직접 실행 시 uvicorn으로 서버 시작
# ═══════════════════════════════════════════════════════
if __name__ == "__main__":
    uvicorn.run(
        "server:app",
        host=config.server.host,
        port=config.server.port,
        reload=False,
    )
