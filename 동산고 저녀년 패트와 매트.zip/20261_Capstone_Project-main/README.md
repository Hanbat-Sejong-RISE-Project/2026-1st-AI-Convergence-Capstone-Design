# 2D → 3D Pipeline Project

2D 이미지 합병(스타일 + 구조) 및 3D 모델 생성 파이프라인입니다.  
스타일 이미지와 구조 이미지를 입력으로 받아 2D 합성 이미지를 생성하고, 이를 3D GLB 모델로 변환합니다.

## 주요 기능

- **2D 이미지 합성**: IP-Adapter + ControlNet(Depth & Lineart)을 활용한 스타일-구조 합성
- **3D 모델 생성**: TRELLIS.2를 활용한 이미지 → 3D 변환
- **3D 후처리**: Poisson, Alpha Shape, Voxel Fill 등 다양한 재구성 방식
- **웹 프론트엔드**: 브라우저에서 이미지 업로드, 생성, 3D 뷰어까지 지원

---

## 프로젝트 구조

```
2d_3d_pipeline_project/
├── server.py                 # FastAPI 서버 (API + 프론트엔드 서빙)
├── pipeline.py               # 2D 합성 & 3D 변환 파이프라인 로직
├── reconstruction.py         # 3D 메시 후처리 (Poisson, Alpha Shape 등)
├── config.yaml               # 모델 경로 및 하이퍼파라미터 설정
├── requirements.txt          # Python 패키지 의존성
├── frontend/                 # 웹 프론트엔드 (HTML/CSS/JS)
│   ├── index.html
│   ├── style.css
│   ├── app.js
│   └── viewer.js
├── frontend_react_notcomplete/  # React 버전 (미완성)
├── output_3d/                # 생성된 3D 모델 저장 (gitignore)
└── uploads/                  # 업로드된 이미지 임시 저장 (gitignore)
```

---

## 환경 설정

### 1. Python 패키지 설치

```bash
pip install -r requirements.txt
```

### 2. 필요한 모델 목록

`config.yaml`에서 경로를 환경에 맞게 수정하세요.

#### HuggingFace 모델 (자동 다운로드)

| 모델 | HuggingFace ID | 용도 |
|---|---|---|
| **Stable Diffusion XL** | `stabilityai/stable-diffusion-xl-base-1.0` | 베이스 이미지 생성 |
| **ControlNet Depth** | `diffusers/controlnet-depth-sdxl-1.0` | 깊이 기반 구조 제어 |
| **ControlNet Lineart** | `TheMistoAI/MistoLine` | 윤곽선 기반 구조 제어 |
| **Lineart Detector** | `lllyasviel/Annotators` | 윤곽선 추출 |
| **Depth Estimator** | `Intel/dpt-hybrid-midas` | 깊이 맵 추정 |
| **TRELLIS.2** | `microsoft/TRELLIS.2-4B` | 이미지 → 3D 변환 |

> **참고**: 위 모델들은 서버 최초 실행 시 HuggingFace에서 자동으로 다운로드됩니다.  
> 오프라인 환경에서는 미리 다운로드하여 로컬 경로를 `config.yaml`에 지정하세요.

#### 로컬 모델 (수동 다운로드 필요)

| 모델 | 기본 경로 | 다운로드 |
|---|---|---|
| **IP-Adapter Image Encoder** | `models/image_encoder/` | [h94/IP-Adapter](https://huggingface.co/h94/IP-Adapter) 에서 `models/image_encoder` 다운로드 |
| **IP-Adapter Plus SDXL** | `sdxl_models/ip-adapter-plus_sdxl_vit-h.bin` | [h94/IP-Adapter](https://huggingface.co/h94/IP-Adapter) 에서 `sdxl_models/ip-adapter-plus_sdxl_vit-h.bin` 다운로드 |

### 3. 외부 라이브러리 (pip 설치 불가 — 수동 클론)

아래 라이브러리들은 로컬에 클론하고, `config.yaml`의 경로를 수정해야 합니다.

```bash
# IP-Adapter
git clone https://github.com/tencent-ailab/IP-Adapter.git

# TRELLIS.2 (이미지 → 3D)
git clone https://github.com/microsoft/TRELLIS.git TRELLIS.2

# o-voxel (TRELLIS.2 내부 의존성)
# TRELLIS.2 리포지토리 내 설치 가이드를 참고하세요.
```

### 4. config.yaml 경로 수정

`config.yaml`을 열고 아래 경로들을 본인 환경에 맞게 수정하세요:

```yaml
models:
  # 로컬에 클론한 IP-Adapter 경로
  image_encoder: "/your/path/to/IP-Adapter/models/image_encoder"
  ip_adapter_ckpt: "/your/path/to/IP-Adapter/sdxl_models/ip-adapter-plus_sdxl_vit-h.bin"
  ip_adapter_lib_path: "/your/path/to/IP-Adapter"

  # 로컬에 클론한 TRELLIS.2 경로
  trellis_lib_path: "/your/path/to/TRELLIS.2"
  o_voxel_lib_path: "/your/path/to/TRELLIS.2/o-voxel"

paths:
  output_dir: "/your/path/to/output_3d"
  upload_dir: "/your/path/to/uploads"
```

---

## 실행 방법

### 서버 실행

```bash
python server.py
```

서버가 `http://0.0.0.0:8000` 에서 시작됩니다.

- **웹 UI**: http://localhost:8000 (config.yaml의 `serve_frontend: true` 필요)
- **API 문서**: http://localhost:8000/docs (Swagger UI)
- **헬스체크**: http://localhost:8000/health

### 주요 API 엔드포인트

| Method | Endpoint | 설명 |
|---|---|---|
| `POST` | `/generate` | 2D 이미지 합성 (동기) |
| `POST` | `/generate-live` | 2D 이미지 합성 (비동기, 실시간 진행 확인) |
| `POST` | `/generate-3d` | 2D → 3D GLB 변환 |
| `POST` | `/reconstruct-3d` | 3D 메시 후처리 |
| `GET` | `/models` | 생성된 3D 모델 목록 |
| `GET` | `/defaults` | 기본 생성 파라미터 조회 |

---

## 시스템 요구사항

- **Python**: 3.10+
- **GPU**: CUDA 지원 GPU (VRAM 24GB+ 권장)
- **OS**: Linux (Ubuntu 20.04+ 권장)
