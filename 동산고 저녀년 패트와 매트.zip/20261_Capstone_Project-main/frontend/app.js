// ═══════════════════════════════════════════════
// App State
// ═══════════════════════════════════════════════
let generatedImages = [];
let selectedImageIndex = -1;
let generationPollTimer = null;
let activeGenerationJobId = null;

// 탭 간 데이터 전달용
let sharedState = {
    imageForTrellis: null,   // File 또는 {blob, name}
    glbForViewer: null,      // Blob URL string
    glbFileName: null,
    generated3dBaseName: null,
    generated3dGlbUrl: null,
    styleImageFile: null, //여기 추가
    structureImageFile: null, //여기 추가
};

function getDefaultServerUrl() {
    if (window.location.protocol === 'http:' || window.location.protocol === 'https:') {
        return window.location.origin;
    }
    return 'http://localhost:8000';
}

function getServerUrl() {
    const input = document.getElementById('server-url');
    const value = input ? input.value.trim().replace(/\/+$/, '') : '';
    return value || getDefaultServerUrl();
}

function initializeServerUrl() {
    const input = document.getElementById('server-url');
    if (!input) return;
    const value = input.value.trim();
    if (!value || value === 'http://localhost:8000') {
        input.value = getDefaultServerUrl();
    }
}

// ═══════════════════════════════════════════════
// Tab Navigation
// ═══════════════════════════════════════════════
function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
    document.getElementById(tabId).classList.add('active');
    updateWrapperScroll();
}
window.switchTab = switchTab;

// ═══════════════════════════════════════════════
// Health Check
// ═══════════════════════════════════════════════
async function checkHealth() {
    initializeServerUrl();
    const dot = document.getElementById('status-dot');
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    try {
        const res = await fetch(`${getServerUrl()}/health`, { signal: controller.signal });
        const data = await res.json();
        dot.className = 'status-dot ' + (data.status === 'ok' ? 'connected' : 'error');
    } catch {
        dot.className = 'status-dot error';
    } finally {
        clearTimeout(timeoutId);
    }
}
window.checkHealth = checkHealth;

// ═══════════════════════════════════════════════
// Load Default Prompts from Server
// ═══════════════════════════════════════════════
async function loadDefaultPrompts() {
    try {
        const res = await fetch(`${getServerUrl()}/defaults`, {
            signal: AbortSignal.timeout(5000)
        });
        if (!res.ok) throw new Error('Failed to load defaults');
        const data = await res.json();
        
        // 서버 기본값을 전역 상태에 저장 (서버 설정의 원본)
        window.serverDefaults = data;
        console.log('✅ [프론트엔드] 서버 기본값 로드 완료:');
        console.log('   프롬프트:', data.prompt.substring(0, 60) + '...');
        console.log('   네거티브 프롬프트:', data.negative_prompt.substring(0, 60) + '...');
    } catch (e) {
        console.log('⚠️ 기본값 로드 실패:', e.message);
    }
}
window.loadDefaultPrompts = loadDefaultPrompts;

window.addEventListener('DOMContentLoaded', () => {
    initializeServerUrl();
    loadDefaultPrompts();
});
window.addEventListener('load', () => setTimeout(checkHealth, 500));

// ── Wrapper scroll control: enable internal scroll only when advanced settings open
function updateWrapperScroll() {
    const wrapper = document.querySelector('.app-wrapper');
    if (!wrapper) return;
    const anyOpen = document.querySelectorAll('details.advanced-settings[open]').length > 0;
    const activeTab = document.querySelector('.tab-panel.active');
    const isLargePanel = activeTab && ['tab-3d-gen', 'tab-viewer'].includes(activeTab.id);
    const resultsContainer = document.querySelector('.results-container');
    const resultsOverflowing =
        activeTab &&
        activeTab.id === 'tab-2d' &&
        resultsContainer &&
        resultsContainer.scrollHeight > resultsContainer.clientHeight;
    const wrapperOverflowing = wrapper.scrollHeight > wrapper.clientHeight;
    const tooManyImages = generatedImages.length >= 6;

    if (anyOpen || isLargePanel || resultsOverflowing || wrapperOverflowing || tooManyImages) {
        wrapper.style.overflowY = 'auto';
    } else {
        // close: hide overflow and reset scroll to top so header/content becomes visible
        wrapper.style.overflowY = 'hidden';
        wrapper.scrollTop = 0;
    }
}

// Populate default prompts when advanced settings opens
function populateDefaultPrompts(event) {
    if (event.target.open && window.serverDefaults) {
        const promptField = document.getElementById('prompt');
        const negPromptField = document.getElementById('negative-prompt');
        
        // Only fill if field is empty; user edits remain
        if (promptField && promptField.value === '' && window.serverDefaults.prompt) {
            promptField.value = window.serverDefaults.prompt;
        }
        if (negPromptField && negPromptField.value === '' && window.serverDefaults.negative_prompt) {
            negPromptField.value = window.serverDefaults.negative_prompt;
        }
    }
}

// Attach toggle listeners to existing and future advanced-settings details
function bindAdvancedToggles() {
    document.querySelectorAll('details.advanced-settings').forEach(d => {
        d.removeEventListener('toggle', updateWrapperScroll);
        d.removeEventListener('toggle', populateDefaultPrompts);
        d.addEventListener('toggle', updateWrapperScroll);
        d.addEventListener('toggle', populateDefaultPrompts);
    });
}

window.addEventListener('DOMContentLoaded', () => {
    bindAdvancedToggles();
    updateWrapperScroll();
});

// ═══════════════════════════════════════════════
// Image Upload Handler (generic)
// ═══════════════════════════════════════════════
function handleUpload(input, zoneId) {
    const zone = document.getElementById(zoneId);
    if (input.files && input.files[0]) {
        const file = input.files[0];
        if (zoneId === 'zone-style') {
            sharedState.styleImageFile = file;
        } else if (zoneId === 'zone-structure') {
            sharedState.structureImageFile = file;
        }

        const reader = new FileReader();
        reader.onload = (e) => {
            zone.querySelectorAll('.icon, .label, .preview').forEach(el => el.remove());
            const img = document.createElement('img');
            img.src = e.target.result;
            img.className = 'preview';
            zone.appendChild(img);
            zone.classList.add('has-image');
        };
        reader.readAsDataURL(file);
    }
}
window.handleUpload = handleUpload;

// ═══════════════════════════════════════════════
// Tab 1: 2D Image Merge
// ═══════════════════════════════════════════════
async function generateImages() {
    let styleFile = document.getElementById('input-style').files[0];
    let structFile = document.getElementById('input-structure').files[0];

    // 파일 입력이 브라우저 상태에 따라 사라질 수 있으므로 업로드된 데이터를 보관한 상태를 폴백으로 사용합니다.
    if (!styleFile) {
        styleFile = sharedState.styleImageFile;
    }
    if (!structFile) {
        structFile = sharedState.structureImageFile;
    }

    if (!styleFile || !structFile) {
        alert('스타일 이미지와 구조 이미지를 모두 업로드해주세요.');
        return;
    }

    const btn = document.getElementById('btn-generate');
    const progress = document.getElementById('progress-2d');
    const progressText = progress.querySelector('.progress-text');
    const requestedCount = Number(document.getElementById('num-images').value || 0);

    if (!Number.isInteger(requestedCount) || requestedCount < 1) {
        alert('생성할 이미지 개수를 1 이상 정수로 입력해주세요.');
        return;
    }

    stopGenerationPolling();
    generatedImages = [];
    selectedImageIndex = -1;
    renderResults([]);
    btn.disabled = true;
    progress.classList.add('active');
    progressText.textContent = '이미지 생성 작업을 시작하는 중입니다...';

    const formData = new FormData();
    formData.append('style_image', styleFile);
    formData.append('structure_image', structFile);
    formData.append('num_images', String(requestedCount));

    // 필드 값을 FormData에 추가
    // - 사용자가 입력하지 않으면 서버 기본값 사용
    const appendField = (fieldName, elementId, serverDefaultKey) => {
        const element = document.getElementById(elementId);
        let value = element ? element.value.trim() : '';
        
        if (value) {
            // ✅ 사용자가 입력한 값 사용
            console.log(`📝 [필드] ${fieldName}: 사용자 입력값 사용`);
            formData.append(fieldName, value);
        } else if (window.serverDefaults && serverDefaultKey && window.serverDefaults[serverDefaultKey]) {
            // ✅ 필드가 비어있으면 서버 기본값 사용
            value = String(window.serverDefaults[serverDefaultKey]);
            console.log(`🔧 [필드] ${fieldName}: 서버 기본값 사용`);
            formData.append(fieldName, value);
        }
    };

    appendField('prompt', 'prompt', 'prompt');
    appendField('negative_prompt', 'negative-prompt', 'negative_prompt');
    appendField('depth_conditioning_scale', 'depth-conditioning-scale', 'depth_conditioning_scale');
    appendField('lineart_conditioning_scale', 'lineart-conditioning-scale', 'lineart_conditioning_scale');
    appendField('ip_adapter_scale', 'ip-adapter-scale', 'ip_adapter_scale');
    appendField('guidance_scale', 'guidance-scale', 'guidance_scale');
    appendField('num_inference_steps', 'num-inference-steps', 'num_inference_steps');

    try {
        const res = await fetch(`${getServerUrl()}/generate-live`, { method: 'POST', body: formData });
        const data = await res.json();
        if (!res.ok || !data.job_id) {
            throw new Error(data.detail || JSON.stringify(data));
        }

        activeGenerationJobId = data.job_id;
        progressText.textContent = `이미지 생성 중... 0/${requestedCount} 완료`;
        pollGenerationJob(data.job_id, requestedCount);
    } catch (e) {
        alert('생성 실패: ' + e.message);
        btn.disabled = false;
        progress.classList.remove('active');
    }
}
window.generateImages = generateImages;

function stopGenerationPolling() {
    if (generationPollTimer) {
        clearTimeout(generationPollTimer);
        generationPollTimer = null;
    }
    activeGenerationJobId = null;
}

async function pollGenerationJob(jobId, requestedCount) {
    const btn = document.getElementById('btn-generate');
    const progress = document.getElementById('progress-2d');
    const progressText = progress.querySelector('.progress-text');

    try {
        const res = await fetch(`${getServerUrl()}/generated-images/${jobId}?t=${Date.now()}`);
        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.detail || JSON.stringify(data));
        }
        if (activeGenerationJobId !== jobId) return;

        const images = (data.images || []).map(normalizeGeneratedImage);
        generatedImages = images;
        renderResults(images);

        const total = data.total || requestedCount || images.length;
        const completed = data.completed !== undefined && data.completed !== null ? data.completed : images.length;
        progressText.textContent = `이미지 생성 중... ${completed}/${total} 완료`;

        if (data.status === 'success') {
            progressText.textContent = `이미지 생성 완료: ${images.length}/${total}`;
            generationPollTimer = setTimeout(() => progress.classList.remove('active'), 800);
            btn.disabled = false;
            activeGenerationJobId = null;
            return;
        }
        if (data.status === 'failed') {
            throw new Error(data.error || '이미지 생성 중 오류가 발생했습니다.');
        }

        generationPollTimer = setTimeout(() => pollGenerationJob(jobId, requestedCount), 1200);
    } catch (e) {
        if (activeGenerationJobId !== jobId) return;
        alert('생성 실패: ' + e.message);
        btn.disabled = false;
        progress.classList.remove('active');
        stopGenerationPolling();
    }
}

function normalizeGeneratedImage(item) {
    const imageUrl = item.image_url || item.url || '';
    const displayUrl = item.image_base64
        ? `data:image/png;base64,${item.image_base64}`
        : new URL(imageUrl, getServerUrl()).href;
    const cacheKey = item.seed !== undefined && item.seed !== null ? item.seed : (item.index !== undefined && item.index !== null ? item.index : Date.now());

    return {
        ...item,
        image_url: imageUrl,
        display_url: item.image_base64 ? displayUrl : `${displayUrl}?v=${cacheKey}`,
    };
}

function renderResults(images) {
    const container = document.getElementById('results-2d');
    container.innerHTML = '';
    images.forEach((item, i) => {
        const div = document.createElement('div');
        div.className = 'result-card';
        const seedLabel = item.seed !== undefined && item.seed !== null ? `seed ${item.seed}` : '';
        div.innerHTML = `
            <img src="${item.display_url}" alt="생성 이미지 ${i + 1}" />
            <div class="info">
                <div class="result-meta">
                    <span class="result-title">이미지 #${i + 1}</span>
                    <span class="result-seed">${seedLabel}</span>
                </div>
                <button class="send-btn" onclick="event.stopPropagation(); sendToTrellis(${i})">3D 생성 →</button>
            </div>
        `;
        container.appendChild(div);
    });
    updateWrapperScroll();
}

async function sendToTrellis(index) {
    const item = generatedImages[index];
    if (!item) return;

    try {
        const imageSrc = item.display_url || normalizeGeneratedImage(item).display_url;
        let blob;
        if (item.image_base64) {
            const byteStr = atob(item.image_base64);
            const arr = new Uint8Array(byteStr.length);
            for (let i = 0; i < byteStr.length; i++) arr[i] = byteStr.charCodeAt(i);
            blob = new Blob([arr], { type: 'image/png' });
        } else {
            const res = await fetch(imageSrc);
            if (!res.ok) throw new Error('이미지를 불러오지 못했습니다.');
            blob = await res.blob();
        }

        sharedState.imageForTrellis = { blob, name: item.filename || `merged_${index + 1}.png` };

        // 탭2 업로드 영역에 프리뷰 표시
        const zone = document.getElementById('zone-trellis-img');
        zone.querySelectorAll('.icon, .label, .preview').forEach(el => el.remove());
        const img = document.createElement('img');
        img.src = imageSrc;
        img.className = 'preview';
        zone.appendChild(img);
        zone.classList.add('has-image');

        // input 초기화 (sharedState 우선 사용)
        document.getElementById('input-trellis-img').value = '';

        switchTab('tab-3d-gen');
    } catch (e) {
        alert('3D 생성 탭으로 이미지를 전달하지 못했습니다: ' + e.message);
    }
}
window.sendToTrellis = sendToTrellis;

// ═══════════════════════════════════════════════
// Tab 2: 3D Model Generation (TRELLIS)
// ═══════════════════════════════════════════════
function handleTrellisUpload(input) {
    sharedState.imageForTrellis = null; // PC 업로드 시 shared 초기화
    handleUpload(input, 'zone-trellis-img');
}
window.handleTrellisUpload = handleTrellisUpload;

async function generate3D() {
    let imageBlob;
    const fileInput = document.getElementById('input-trellis-img');

    if (fileInput.files && fileInput.files[0]) {
        imageBlob = fileInput.files[0];
    } else if (sharedState.imageForTrellis) {
        imageBlob = sharedState.imageForTrellis.blob;
    } else {
        alert('3D 변환할 이미지를 업로드하거나, 2D 합병 탭에서 전달해주세요.');
        return;
    }

    const btn = document.getElementById('btn-3d');
    const progress = document.getElementById('progress-3d');
    btn.disabled = true;
    progress.classList.add('active');

    try {
        const formData = new FormData();
        formData.append('image', imageBlob, 'input.png');
        formData.append('filename', document.getElementById('filename-3d').value || 'output_model');
        formData.append('seed', '42');

        const res = await fetch(`${getServerUrl()}/generate-3d`, { method: 'POST', body: formData });

        if (res.ok) {
            const glbBlob = await res.blob();
            const url = URL.createObjectURL(glbBlob);
            const baseName = document.getElementById('filename-3d').value || 'output_model';
            const fname = baseName + '.glb';
            sharedState.generated3dBaseName = baseName;
            sharedState.generated3dGlbUrl = url;

            // 미니 뷰어에 로드
            window.loadGLB_mini(url);

            // 결과 영역 표시
            const resultArea = document.getElementById('trellis-result');
            resultArea.style.display = 'block';

            // 다운로드 + 뷰어 전송 버튼
            const btnRow = document.getElementById('trellis-btn-row');
            btnRow.innerHTML = `
                <select class="download-format-select" id="download-format-3d" aria-label="다운로드 형식">
                    <option value="glb">GLB</option>
                    <option value="stl">STL</option>
                    <option value="3mf">3MF</option>
                </select>
                <button class="btn btn-secondary btn-sm" onclick="downloadGeneratedModel()">⬇️ 다운로드</button>
                <button class="btn btn-primary btn-sm" onclick="sendToViewer('${url}', '${fname}')">👁️ 뷰어에서 열기 →</button>
                <button class="btn btn-primary btn-sm" onclick="sendToReconstruct('${url}', '${fname}')">🔧 재구성하기 →</button>
            `;
        } else {
            const err = await res.json();
            alert('3D 변환 실패: ' + (err.detail || JSON.stringify(err)));
        }
    } catch (e) {
        alert('서버 연결 실패: ' + e.message);
    } finally {
        btn.disabled = false;
        progress.classList.remove('active');
    }
}
window.generate3D = generate3D;

function triggerDownload(url, filename) {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
}

async function downloadGeneratedModel() {
    const formatSelect = document.getElementById('download-format-3d');
    const format = formatSelect ? formatSelect.value : 'glb';
    const baseName = sharedState.generated3dBaseName || document.getElementById('filename-3d').value || 'output_model';
    const filename = baseName + '.' + format;

    try {
        if (format === 'glb' && sharedState.generated3dGlbUrl) {
            triggerDownload(sharedState.generated3dGlbUrl, filename);
            return;
        }

        const res = await fetch(getServerUrl() + '/models/' + encodeURIComponent(filename));
        if (!res.ok) {
            const message = await res.text();
            try {
                const parsed = JSON.parse(message);
                throw new Error(parsed.detail || message || '다운로드 실패');
            } catch {
                throw new Error(message || '다운로드 실패');
            }
        }

        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        triggerDownload(url, filename);
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
        alert('모델 다운로드 실패: ' + e.message);
    }
}
window.downloadGeneratedModel = downloadGeneratedModel;

function sendToViewer(url, fname) {
    sharedState.glbForViewer = url;
    sharedState.glbFileName = fname;
    switchTab('tab-viewer');
    setTimeout(() => {
        window.loadGLB_full(url);
        
        // 뷰어 파일 정보 업데이트
        const infoEl = document.getElementById('viewer-file-info');
        if(infoEl) infoEl.textContent = `📂 ${fname}`;
        
        // 업로드 존 업데이트
        const zone = document.getElementById('zone-viewer-file');
        if (zone) {
            zone.querySelectorAll('.icon, .label').forEach(el => el.style.display = 'none');
            let fileInfo = zone.querySelector('.file-info');
            if (!fileInfo) {
                fileInfo = document.createElement('div');
                fileInfo.className = 'file-info';
                zone.appendChild(fileInfo);
            }
            fileInfo.textContent = `📂 ${fname}`;
            zone.classList.add('has-file');
        }
    }, 100);
}
window.sendToViewer = sendToViewer;

// ═══════════════════════════════════════════════
// Tab 4 (now logically 4): 3D Viewer
// ═══════════════════════════════════════════════
async function handleViewerUpload(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const ext = file.name.split('.').pop().toLowerCase();
        
        let url;
        // STL이나 3MF일 경우 서버에서 GLB로 변환
        if (ext === 'stl' || ext === '3mf') {
            const infoEl = document.getElementById('viewer-file-info');
            if(infoEl) infoEl.textContent = `⏳ ${file.name} 변환 중...`;
            
            try {
                const formData = new FormData();
                formData.append('model_file', file);
                const res = await fetch(`${getServerUrl()}/convert-to-glb`, {
                    method: 'POST',
                    body: formData
                });
                
                if (!res.ok) throw new Error('변환 실패');
                
                const blob = await res.blob();
                url = URL.createObjectURL(blob);
            } catch (err) {
                alert(`GLB 변환 실패: ${err.message}`);
                if(infoEl) infoEl.textContent = `❌ 변환 실패`;
                return;
            }
        } else {
            url = URL.createObjectURL(file);
        }

        sharedState.glbForViewer = url;
        sharedState.glbFileName = file.name;
        window.loadGLB_full(url);
        
        // 뷰어 파일 정보 업데이트
        const infoEl = document.getElementById('viewer-file-info');
        if(infoEl) infoEl.textContent = `📂 ${file.name}`;
        
        // 업로드 존 업데이트
        const zone = document.getElementById('zone-viewer-file');
        if (zone) {
            zone.querySelectorAll('.icon, .label').forEach(el => el.style.display = 'none');
            let fileInfo = zone.querySelector('.file-info');
            if (!fileInfo) {
                fileInfo = document.createElement('div');
                fileInfo.className = 'file-info';
                zone.appendChild(fileInfo);
            }
            fileInfo.textContent = `📂 ${file.name}`;
            zone.classList.add('has-file');
        }
    }
}
window.handleViewerUpload = handleViewerUpload;

// ═══════════════════════════════════════════════
// Tab 4: 3D Reconstruction
// ═══════════════════════════════════════════════
let reconState = {
    file: null,
    blobUrl: null,
    filename: null,
    resultBlobUrl: null,
    resultFilename: null,
    method: 'poisson',
    jobId: null
};

function sendToReconstruct(url, fname) {
    fetch(url)
        .then(res => res.blob())
        .then(blob => {
            const file = new File([blob], fname, { type: "model/gltf-binary" });
            reconState.file = file;
            reconState.filename = fname;
            
            // 탭4 업로드 영역 업데이트
            const zone = document.getElementById('zone-recon-model');
            zone.querySelectorAll('.icon, .label').forEach(el => el.style.display = 'none');
            
            let fileInfo = zone.querySelector('.file-info');
            if (!fileInfo) {
                fileInfo = document.createElement('div');
                fileInfo.className = 'file-info';
                zone.appendChild(fileInfo);
            }
            fileInfo.textContent = `📂 ${fname}`;
            zone.classList.add('has-file');
            
            // 파일이 등록되면 pitch 계산 호출
            calculateAndSetPitch(file);
            
            switchTab('tab-reconstruct');
        })
        .catch(err => alert("파일을 전달하는 데 실패했습니다: " + err));
}
window.sendToReconstruct = sendToReconstruct;

function handleReconUpload(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        reconState.file = file;
        reconState.filename = file.name;
        
        const zone = document.getElementById('zone-recon-model');
        zone.querySelectorAll('.icon, .label').forEach(el => el.style.display = 'none');
        
        let fileInfo = zone.querySelector('.file-info');
        if (!fileInfo) {
            fileInfo = document.createElement('div');
            fileInfo.className = 'file-info';
            zone.appendChild(fileInfo);
        }
        fileInfo.textContent = `📂 ${file.name}`;
        zone.classList.add('has-file');
        
        // 파일이 등록되면 pitch 계산 호출
        calculateAndSetPitch(file);
    }
}
window.handleReconUpload = handleReconUpload;

async function calculateAndSetPitch(file) {
    const formData = new FormData();
    formData.append('model_file', file);
    try {
        const res = await fetch(`${getServerUrl()}/calculate-pitch`, {
            method: 'POST',
            body: formData
        });
        if (res.ok) {
            const data = await res.json();
            if (data.pitch) {
                const pitchInput = document.getElementById('recon-pitch');
                if (pitchInput) {
                    pitchInput.value = data.pitch;
                }
            }
        }
    } catch (err) {
        console.error("Pitch 계산 실패:", err);
    }
}

function selectReconMethod(method) {
    reconState.method = method;
    
    // UI 업데이트
    document.querySelectorAll('.recon-method-card').forEach(card => {
        card.classList.remove('active');
    });
    document.querySelector(`.recon-method-card[data-method="${method}"]`).classList.add('active');
    
    // 파라미터 패널 토글
    const poissonParams = document.getElementById('recon-params-poisson');
    if (poissonParams) {
        poissonParams.style.display = method === 'poisson' ? 'block' : 'none';
    }
    const voxelParams = document.getElementById('recon-params-voxel_fill');
    if (voxelParams) {
        voxelParams.style.display = method === 'voxel_fill' ? 'block' : 'none';
    }
    const alphaParams = document.getElementById('recon-params-alpha_shape');
    if (alphaParams) {
        alphaParams.style.display = method === 'alpha_shape' ? 'block' : 'none';
    }
}
window.selectReconMethod = selectReconMethod;

async function reconstruct3D() {
    if (!reconState.file) {
        alert('재구성할 3D 모델(GLB/STL/3MF) 파일을 업로드해주세요.');
        return;
    }
    
    const btn = document.getElementById('btn-reconstruct');
    const progress = document.getElementById('progress-recon');
    btn.disabled = true;
    progress.classList.add('active');
    
    try {
        const formData = new FormData();
        formData.append('model_file', reconState.file);
        formData.append('method', reconState.method);
        
        if (reconState.method === 'poisson') {
            formData.append('depth', document.getElementById('recon-depth').value);
            formData.append('taubin_iterations', document.getElementById('recon-taubin-iter').value);
            formData.append('normal_radius', document.getElementById('recon-normal-radius').value);
            formData.append('normal_max_nn', document.getElementById('recon-normal-nn').value);
        } else if (reconState.method === 'voxel_fill') {
            formData.append('pitch', document.getElementById('recon-pitch').value);
        } else if (reconState.method === 'alpha_shape') {
            formData.append('alpha', document.getElementById('recon-alpha').value);
        }
        // voxel_fill은 simplify_ratio 미사용 (연산 부담 제외)
        if (reconState.method !== 'voxel_fill') {
            formData.append('simplify_ratio', document.getElementById('recon-simplify').value);
        }
        
        const res = await fetch(`${getServerUrl()}/reconstruct-3d`, { method: 'POST', body: formData });
        
        if (res.ok) {
            const glbBlob = await res.blob();
            const url = URL.createObjectURL(glbBlob);
            
            // 응답 헤더에서 메타데이터 읽기
            const methodUsed = res.headers.get('X-Recon-Method') || reconState.method;
            const isWatertight = res.headers.get('X-Recon-Watertight') === 'True';
            const vertices = res.headers.get('X-Recon-Vertices') || '?';
            const faces = res.headers.get('X-Recon-Faces') || '?';
            const jobId = res.headers.get('X-Recon-Job-Id');
            
            const baseName = reconState.filename.substring(0, reconState.filename.lastIndexOf('.')) || 'reconstructed';
            const fname = `${baseName}_${methodUsed}.glb`;
            
            reconState.resultBlobUrl = url;
            reconState.resultFilename = fname;
            reconState.jobId = jobId;
            
            // 미니 뷰어에 로드
            window.loadGLB_recon(url);
            
            // 메타데이터 표시
            const infoDiv = document.getElementById('recon-result-info');
            infoDiv.innerHTML = `
                <div class="info-chip">정점: ${vertices}</div>
                <div class="info-chip">면: ${faces}</div>
                <div class="info-chip ${isWatertight ? 'success' : 'warning'}">
                    ${isWatertight ? '✅ 수밀성(Watertight) 확보' : '⚠️ 수밀성 없음'}
                </div>
            `;
            
            // 결과 버튼 생성
            const btnRow = document.getElementById('recon-btn-row');
            btnRow.innerHTML = `
                <select class="download-format-select" id="download-format-recon" aria-label="다운로드 형식">
                    <option value="glb">GLB</option>
                    <option value="stl">STL</option>
                    <option value="3mf">3MF</option>
                </select>
                <button class="btn btn-secondary btn-sm" onclick="downloadReconstructedModel()">⬇️ 다운로드</button>
                <button class="btn btn-primary btn-sm" onclick="sendToViewer('${url}', '${fname}')">👁️ 뷰어에서 열기 →</button>
            `;
        } else {
            const err = await res.json();
            alert('재구성 실패: ' + (err.detail || JSON.stringify(err)));
        }
    } catch (e) {
        alert('서버 연결 실패: ' + e.message);
    } finally {
        btn.disabled = false;
        progress.classList.remove('active');
    }
}
window.reconstruct3D = reconstruct3D;

async function downloadReconstructedModel() {
    const formatSelect = document.getElementById('download-format-recon');
    const format = formatSelect ? formatSelect.value : 'glb';
    
    if (format === 'glb' && reconState.resultBlobUrl) {
        triggerDownload(reconState.resultBlobUrl, reconState.resultFilename);
        return;
    }
    
    if (!reconState.jobId) {
        alert('서버에서 작업 ID를 찾을 수 없습니다.');
        return;
    }
    
    const filename = `recon_${reconState.jobId}.${format}`;
    try {
        const res = await fetch(`${getServerUrl()}/reconstructed-models/${filename}`);
        if (!res.ok) throw new Error('다운로드 실패');
        
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        triggerDownload(url, reconState.resultFilename.replace('.glb', '.' + format));
        setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) {
        alert('모델 다운로드 실패: ' + e.message);
    }
}
window.downloadReconstructedModel = downloadReconstructedModel;

