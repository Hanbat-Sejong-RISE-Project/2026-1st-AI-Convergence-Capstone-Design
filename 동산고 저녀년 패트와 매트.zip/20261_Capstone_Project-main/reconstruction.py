"""
reconstruction.py — 3D 메쉬 재구성 엔진
─────────────────────────────────────────────────────────
trimesh_test/level2.ipynb (포아송 재구성 + 타우빈 평활화) 및
trimesh_test/bolloc_test.ipynb (볼록 껍질 + 쿼드릭 단순화)
알고리즘을 웹서비스 백엔드에서 사용할 수 있도록 모듈화합니다.

지원 입력: GLB, GLTF, STL, 3MF
지원 출력: GLB
"""

import os
import numpy as np
import trimesh
import open3d as o3d
from dataclasses import dataclass
from typing import Optional


# ═══════════════════════════════════════════════════════
# 재구성 결과 데이터클래스
# ═══════════════════════════════════════════════════════
@dataclass
class ReconstructionResult:
    """재구성 결과를 담는 데이터클래스."""
    output_path: str
    method: str
    is_watertight: bool
    vertex_count: int
    face_count: int


# ═══════════════════════════════════════════════════════
# 공용 유틸리티
# ═══════════════════════════════════════════════════════
def _load_mesh(input_path: str) -> trimesh.Trimesh:
    """
    GLB/GLTF/STL/3MF 파일을 로드하여 단일 Trimesh 객체로 반환합니다.
    Scene 객체인 경우 하나의 메쉬로 병합합니다.
    """
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"입력 파일이 존재하지 않습니다: {input_path}")

    mesh = trimesh.load(input_path, process=True)

    # Scene이면 단일 메쉬로 병합
    if isinstance(mesh, trimesh.Scene) or type(mesh).__name__ == "Scene":
        if hasattr(mesh, "geometry") and len(mesh.geometry) == 0:
            raise ValueError(f"'{input_path}'에서 메쉬를 찾을 수 없습니다.")
        mesh = mesh.to_mesh()
    elif isinstance(mesh, list):
        mesh = trimesh.util.concatenate(mesh)

    return mesh


def _mesh_to_pcd_with_colors(mesh: trimesh.Trimesh) -> o3d.geometry.PointCloud:
    """
    Trimesh 메쉬를 Open3D 포인트 클라우드로 변환합니다. (색상 포함)
    """
    pcd = o3d.geometry.PointCloud()
    pcd.points = o3d.utility.Vector3dVector(mesh.vertices)

    # 정점 색상 추출
    if hasattr(mesh.visual, "vertex_colors") and len(mesh.visual.vertex_colors) > 0:
        pcd.colors = o3d.utility.Vector3dVector(
            np.asarray(mesh.visual.vertex_colors)[:, :3] / 255.0
        )
    else:
        mesh.visual = mesh.visual.to_color()
        pcd.colors = o3d.utility.Vector3dVector(
            np.asarray(mesh.visual.vertex_colors)[:, :3] / 255.0
        )

    return pcd


def _transfer_colors(
    source_pcd: o3d.geometry.PointCloud,
    target_mesh: o3d.geometry.TriangleMesh,
) -> o3d.geometry.TriangleMesh:
    """
    원본 포인트 클라우드의 색상을 타겟 메쉬의 정점에 KDTree로 전파합니다.
    """
    pcd_tree = o3d.geometry.KDTreeFlann(source_pcd)
    colors = []

    for i in range(len(target_mesh.vertices)):
        [_, idx, _] = pcd_tree.search_knn_vector_3d(target_mesh.vertices[i], 1)
        colors.append(source_pcd.colors[idx[0]])

    target_mesh.vertex_colors = o3d.utility.Vector3dVector(np.asarray(colors))
    return target_mesh


def _o3d_to_trimesh(mesh: o3d.geometry.TriangleMesh) -> trimesh.Trimesh:
    """
    Open3D TriangleMesh를 Trimesh 객체로 변환합니다. (색상 포함)
    """
    vertices = np.asarray(mesh.vertices)
    faces = np.asarray(mesh.triangles)

    colors = np.asarray(mesh.vertex_colors)
    colors_rgba = np.hstack([colors, np.ones((colors.shape[0], 1))])
    colors_rgba = (colors_rgba * 255).astype(np.uint8)

    return trimesh.Trimesh(
        vertices=vertices,
        faces=faces,
        vertex_colors=colors_rgba,
        process=True,
    )


# ═══════════════════════════════════════════════════════
# 재구성 방식 1: 포아송 재구성 + 타우빈 평활화
# (출처: trimesh_test/level2.ipynb)
# ═══════════════════════════════════════════════════════
def reconstruct_poisson(
    input_path: str,
    output_path: str,
    depth: int = 9,
    taubin_iterations: int = 20,
    normal_radius: float = 0.1,
    normal_max_nn: int = 30,
    simplify_ratio: float = 0.5,
) -> ReconstructionResult:
    """
    포아송 표면 재구성 + 타우빈 평활화 + 쿼드릭 단순화를 수행합니다.

    Parameters:
        input_path: 입력 3D 모델 파일 경로 (GLB/STL/3MF)
        output_path: 출력 GLB 파일 경로
        depth: 포아송 재구성 깊이 (높을수록 정밀, 느림). 기본 9
        taubin_iterations: 타우빈 평활화 반복 횟수. 기본 20
        normal_radius: 법선 추정 검색 반경. 기본 0.1
        normal_max_nn: 법선 추정 최대 이웃 수. 기본 30
        simplify_ratio: 쿼드릭 단순화 비율 (0.0~1.0). 기본 0.5
    """
    print("🔄 [포아송] 1단계: 3D 메쉬 로드 중...")
    mesh = _load_mesh(input_path)

    print("🔄 [포아송] 2단계: Open3D 포인트 클라우드 변환 및 법선 추정...")
    pcd = _mesh_to_pcd_with_colors(mesh)
    pcd.estimate_normals(
        search_param=o3d.geometry.KDTreeSearchParamHybrid(
            radius=normal_radius, max_nn=normal_max_nn
        )
    )
    pcd.orient_normals_consistent_tangent_plane(100)

    print(f"🕳️ [포아송] 3단계: 포아송 표면 재구성 (depth={depth})...")
    reconstructed_mesh, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(
        pcd, depth=depth
    )

    # 밀도 필터링(Density Filtering) 로직 제거됨
    # (TRELLIS 3D 모델과 같이 이미 형태가 갖춰진 모델의 경우,
    # 밀도 필터링을 수행하면 멀쩡한 표면에 구멍이 뚫리는 문제가 발생하므로 생략합니다.)

    print("🎨 [포아송] 4단계: 색상 전파 (KDTree)...")
    reconstructed_mesh = _transfer_colors(pcd, reconstructed_mesh)

    print(f"✨ [포아송] 5단계: 타우빈 평활화 (iterations={taubin_iterations})...")
    smooth_mesh = reconstructed_mesh.filter_smooth_taubin(
        number_of_iterations=taubin_iterations
    )

    # 쿼드릭 단순화 (simplify_ratio > 0 일 때만)
    if 0.0 < simplify_ratio < 1.0:
        target_triangles = int(len(smooth_mesh.triangles) * simplify_ratio)
        if target_triangles > 0:
            print(f"📉 [포아송] 6단계: 쿼드릭 단순화 (면 수 → {target_triangles})...")
            smooth_mesh = smooth_mesh.simplify_quadric_decimation(
                target_number_of_triangles=target_triangles
            )

    print("🔄 [포아송] 7단계: Trimesh 변환 및 GLB 저장...")
    final_trimesh = _o3d_to_trimesh(smooth_mesh)

    print("✨ [포아송] 8단계: 법선 방향 자동 보정 (fix_normals)...")
    final_trimesh.fix_normals()

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    final_trimesh.export(output_path)

    print(f"🎉 [포아송] 완료: {output_path}")
    return ReconstructionResult(
        output_path=output_path,
        method="poisson",
        is_watertight=final_trimesh.is_watertight,
        vertex_count=len(final_trimesh.vertices),
        face_count=len(final_trimesh.faces),
    )


# ═══════════════════════════════════════════════════════
# 재구성 방식 2: 복셀 내부 채우기 (Voxel Fill)
# (출처: trimesh_test/내부 채우기.ipynb)
# ═══════════════════════════════════════════════════════
def reconstruct_voxel_fill(
    input_path: str,
    output_path: str,
    pitch: float = 0.1,
) -> ReconstructionResult:
    """
    복셀화(Voxelization) → 내부 채우기(Fill) → Marching Cubes 메쉬 변환을 수행합니다.
    구멍이 뚫리거나 내부가 비어 있는 메쉬를 완전히 수밀(Watertight)하게 만듭니다.

    Parameters:
        input_path: 입력 3D 모델 파일 경로 (GLB/STL/3MF)
        output_path: 출력 GLB 파일 경로
        pitch: 복셀 해상도 (작을수록 정밀, 연산 시간·파일 크기 증가). 기본 0.05
    """
    print("🔄 [내부채우기] 1단계: 3D 메쉬 로드 중...")
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"입력 파일이 존재하지 않습니다: {input_path}")
    mesh = trimesh.load(input_path, force="mesh")

    # 색상 정보 미리 추출 (voxel 변환 후 색상 복원에 사용)
    has_colors = (
        hasattr(mesh.visual, "vertex_colors")
        and len(mesh.visual.vertex_colors) > 0
    )
    if not has_colors:
        mesh.visual = mesh.visual.to_color()

    # STL이 아닌 경우 임시 STL로 변환 후 다시 로드
    # (trimesh voxelization은 STL 형식에서 가장 안정적으로 작동)
    _, ext = os.path.splitext(input_path.lower())
    stl_path_for_voxel = input_path  # 기본은 원본 경로
    _tmp_stl_created = False
    if ext != ".stl":
        stl_path_for_voxel = input_path + "_tmp_voxel.stl"
        print(f"🔁 [내부채우기] 1-1단계: STL 변환 중 ({ext} → .stl)...")
        mesh.export(stl_path_for_voxel)
        _tmp_stl_created = True

    try:
        print("📂 [내부채우기] 1-2단계: STL 파일 로드 (force='mesh')...")
        mesh_for_voxel = trimesh.load(stl_path_for_voxel, force="mesh")

        print(f"🧊 [내부채우기] 2단계: 복셀화 (pitch={pitch})...")
        # pitch가 기본값(0.1)이면 모델 크기에 맞게 자동 조정
        # 모델의 가장 긴 축 기준으로 약 200개의 복셀이 생기도록 설정
        actual_pitch = pitch
        max_extent = mesh_for_voxel.bounding_box.extents.max()
        if max_extent > 0:
            auto_pitch = max_extent / 200.0
            # 사용자가 기본값(0.1)을 그대로 쓰는 경우에만 자동 조정 적용
            if abs(pitch - 0.1) < 1e-6:
                actual_pitch = auto_pitch
                print(f"   ↳ 모델 크기({max_extent:.4f}) 기준 자동 pitch 조정: {actual_pitch:.6f}")
        vox = mesh_for_voxel.voxelized(pitch=actual_pitch)
    finally:
        # 임시 STL 파일 정리
        if _tmp_stl_created and os.path.exists(stl_path_for_voxel):
            os.remove(stl_path_for_voxel)

    print("🔩 [내부채우기] 3단계: 내부 채우기 (Fill)...")
    vox_filled = vox.fill()

    print("🗺️ [내부채우기] 4단계: Marching Cubes → 메쉬 변환...")
    solid = vox_filled.marching_cubes

    # 복셀 좌표계를 원래 크기 좌표계로 복원
    solid.apply_transform(vox_filled.transform)

    print("✨ [내부채우기] 4-1단계: 법선 방향 자동 보정 (fix_normals)...")
    solid.fix_normals()

    # 색상 복원: 원본 색상 팔레트의 평균 색상을 전체 정점에 입힘
    avg_color = np.mean(
        np.asarray(mesh.visual.vertex_colors)[:, :3], axis=0
    ).astype(np.uint8)
    vertex_colors = np.tile(
        np.append(avg_color, 255), (len(solid.vertices), 1)
    ).astype(np.uint8)
    solid.visual = trimesh.visual.ColorVisuals(
        mesh=solid, vertex_colors=vertex_colors
    )

    print("💾 [내부채우기] 5단계: GLB 저장...")
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    solid.export(output_path)

    print(f"🎉 [내부채우기] 완료: {output_path}")
    return ReconstructionResult(
        output_path=output_path,
        method="voxel_fill",
        is_watertight=solid.is_watertight,
        vertex_count=len(solid.vertices),
        face_count=len(solid.faces),
    )


# ═══════════════════════════════════════════════════════
# 재구성 방식 3: 오목 껍질 + 쿼드릭 단순화
# ═══════════════════════════════════════════════════════
def reconstruct_alpha_shape(
    input_path: str,
    output_path: str,
    alpha: float = 0.1,
    simplify_ratio: float = 0.5,
) -> ReconstructionResult:
    """
    오목 껍질(Alpha Shape) 기반 표면 재구성 + 쿼드릭 단순화를 수행합니다.

    Parameters:
        input_path: 입력 3D 모델 파일 경로 (GLB/STL/3MF)
        output_path: 출력 GLB 파일 경로
        alpha: 알파 셰이프 반경 (작을수록 세밀, 클수록 볼록 껍질에 근접)
        simplify_ratio: 쿼드릭 단순화 비율 (0.0~1.0). 기본 0.5
    """
    print("🔄 [오목껍질] 1단계: 3D 메쉬 로드 중...")
    mesh = _load_mesh(input_path)

    print("🔄 [오목껍질] 2단계: Open3D 포인트 클라우드 변환...")
    pcd = _mesh_to_pcd_with_colors(mesh)

    print(f"📐 [오목껍질] 3단계: 알파 셰이프 기반 재구성 (alpha={alpha})...")
    alpha_mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_alpha_shape(pcd, alpha)

    print("🎨 [오목껍질] 4단계: 색상 전파 (KDTree)...")
    alpha_mesh = _transfer_colors(pcd, alpha_mesh)

    # 쿼드릭 단순화
    if 0.0 < simplify_ratio < 1.0:
        target_triangles = int(len(alpha_mesh.triangles) * simplify_ratio)
        if target_triangles > 0:
            print(f"📉 [오목껍질] 5단계: 쿼드릭 단순화 (면 수 → {target_triangles})...")
            alpha_mesh = alpha_mesh.simplify_quadric_decimation(
                target_number_of_triangles=target_triangles
            )

    print("🔄 [오목껍질] 6단계: Trimesh 변환 및 GLB 저장...")
    final_trimesh = _o3d_to_trimesh(alpha_mesh)

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)
    final_trimesh.export(output_path)

    print(f"🎉 [오목껍질] 완료: {output_path}")
    return ReconstructionResult(
        output_path=output_path,
        method="alpha_shape",
        is_watertight=final_trimesh.is_watertight,
        vertex_count=len(final_trimesh.vertices),
        face_count=len(final_trimesh.faces),
    )


# ═══════════════════════════════════════════════════════
# 재구성 디스패처 (확장 가능한 구조)
# ═══════════════════════════════════════════════════════
# 향후 새로운 재구성 방식을 추가할 때 이 딕셔너리에 등록하면 됩니다.
RECONSTRUCTION_METHODS = {
    "poisson": {
        "name": "포아송 재구성 (Poisson + Taubin)",
        "description": "포아송 표면 재구성으로 구멍을 메우고, 타우빈 평활화로 표면을 다듬습니다.",
        "fn": reconstruct_poisson,
        "params": {
            "depth": {"type": "int", "default": 9, "min": 3, "max": 12, "step": 1,
                      "label": "포아송 깊이 (Depth)", "description": "높을수록 정밀하지만 느립니다"},
            "taubin_iterations": {"type": "int", "default": 20, "min": 1, "max": 100, "step": 1,
                                  "label": "평활화 반복 횟수", "description": "타우빈 평활화 반복 횟수"},
            "normal_radius": {"type": "float", "default": 0.1, "min": 0.01, "max": 1.0, "step": 0.01,
                              "label": "법선 추정 반경", "description": "법선 추정 시 검색 반경"},
            "normal_max_nn": {"type": "int", "default": 30, "min": 5, "max": 100, "step": 5,
                              "label": "법선 최대 이웃 수", "description": "법선 추정 시 최대 이웃 포인트 수"},
            "simplify_ratio": {"type": "float", "default": 0.5, "min": 0.1, "max": 1.0, "step": 0.05,
                               "label": "단순화 비율", "description": "면 수 축소 비율 (1.0 = 단순화 없음)"},
        },
    },
    "voxel_fill": {
        "name": "내부 채우기 (Voxel Fill)",
        "description": "복셀화 후 내부를 완전히 채워 수밀(Watertight) 메쉬를 생성합니다.",
        "fn": reconstruct_voxel_fill,
        "params": {
            "pitch": {"type": "float", "default": 0.1, "min": 0.005, "max": 0.5, "step": 0.005,
                      "label": "복셀 해상도 (Pitch)", "description": "작을수록 정밀하지만 연산이 오래 걸립니다"},
        },
    },
    "alpha_shape": {
        "name": "오목 껍질 (Alpha Shape)",
        "description": "오목 껍질(알파 셰이프)을 이용하여 디테일한 외곽선을 보존하며 메쉬를 닫습니다.",
        "fn": reconstruct_alpha_shape,
        "params": {
            "alpha": {"type": "float", "default": 0.1, "min": 0.01, "max": 10.0, "step": 0.01,
                      "label": "알파 값 (Alpha)", "description": "반경 크기 (작을수록 세밀, 클수록 볼록 껍질)"},
            "simplify_ratio": {"type": "float", "default": 0.5, "min": 0.1, "max": 1.0, "step": 0.05,
                               "label": "단순화 비율", "description": "면 수 축소 비율 (1.0 = 단순화 없음)"},
        },
    },
}


def run_reconstruction(
    method: str,
    input_path: str,
    output_path: str,
    **kwargs,
) -> ReconstructionResult:
    """
    지정한 방식으로 3D 재구성을 수행합니다.

    Parameters:
        method: 재구성 방식 ("poisson", "voxel_fill", "alpha_shape")
        input_path: 입력 파일 경로
        output_path: 출력 파일 경로
        **kwargs: 각 방식별 하이퍼파라미터
    """
    if method not in RECONSTRUCTION_METHODS:
        available = ", ".join(RECONSTRUCTION_METHODS.keys())
        raise ValueError(f"지원하지 않는 재구성 방식입니다: '{method}'. 사용 가능: {available}")

    entry = RECONSTRUCTION_METHODS[method]
    fn = entry["fn"]

    # 해당 방식에서 지원하는 파라미터만 필터링하여 전달
    valid_params = entry["params"].keys()
    filtered_kwargs = {k: v for k, v in kwargs.items() if k in valid_params and v is not None}

    print(f"\n{'='*60}")
    print(f"🔧 3D 재구성 시작: {entry['name']}")
    print(f"   입력: {input_path}")
    print(f"   출력: {output_path}")
    print(f"   파라미터: {filtered_kwargs}")
    print(f"{'='*60}\n")

    return fn(input_path=input_path, output_path=output_path, **filtered_kwargs)
