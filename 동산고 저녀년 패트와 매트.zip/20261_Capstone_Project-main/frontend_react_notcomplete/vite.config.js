module.exports = {
  jsx: 'react',
};
