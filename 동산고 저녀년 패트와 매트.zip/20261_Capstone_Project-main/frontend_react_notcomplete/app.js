// ═══════════════════════════════════════════════
// App State
// ═══════════════════════════════════════════════
let generatedImages = [];
let selectedImageIndex = -1;
let generationPollTimer = null;
let activeGenerationJobId = null;

// 탭 간 데이터 전달용
let sharedState = {
    imageForTrellis: null,   // File 또는 {blob, name}
    glbForViewer: null,      // Blob URL string
    glbFileName: null,
};

function getServerUrl() {
    return document.getElementById('server-url').value.replace(/\/+$/, '');
}

// ═══════════════════════════════════════════════
// Tab Navigation
// ═══════════════════════════════════════════════
function switchTab(tabId) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
    document.getElementById(tabId).classList.add('active');
}
window.switchTab = switchTab;

// ═══════════════════════════════════════════════
// Health Check
// ═══════════════════════════════════════════════
async function checkHealth() {
    const dot = document.getElementById('status-dot');
    try {
        const res = await fetch(`${getServerUrl()}/health`, { signal: AbortSignal.timeout(5000) });
        const data = await res.json();
        dot.className = 'status-dot ' + (data.status === 'ok' ? 'connected' : 'error');
    } catch {
        dot.className = 'status-dot error';
    }
}
window.checkHealth = checkHealth;
window.addEventListener('load', () => setTimeout(checkHealth, 500));

// ═══════════════════════════════════════════════
// Image Upload Handler (generic)
// ═══════════════════════════════════════════════
function handleUpload(input, zoneId) {
    const zone = document.getElementById(zoneId);
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = (e) => {
            zone.querySelectorAll('.icon, .label, .preview').forEach(el => el.remove());
            const img = document.createElement('img');
            img.src = e.target.result;
            img.className = 'preview';
            zone.appendChild(img);
            zone.classList.add('has-image');
        };
        reader.readAsDataURL(input.files[0]);
    }
}
window.handleUpload = handleUpload;

// ═══════════════════════════════════════════════
// Tab 1: 2D Image Merge
// ═══════════════════════════════════════════════
async function generateImages() {
    const styleFile = document.getElementById('input-style').files[0];
    const structFile = document.getElementById('input-structure').files[0];
    const prompt = document.getElementById('prompt').value.trim();

    if (!styleFile || !structFile) {
        alert('스타일 이미지와 구조 이미지를 모두 업로드해주세요.');
        return;
    }

    const btn = document.getElementById('btn-generate');
    const progress = document.getElementById('progress-2d');
    const progressText = progress.querySelector('.progress-text');
    const requestedCount = Number(document.getElementById('num-images').value || 0);

    stopGenerationPolling();
    generatedImages = [];
    selectedImageIndex = -1;
    renderResults([]);
    btn.disabled = true;
    progress.classList.add('active');
    progressText.textContent = '이미지 생성 작업을 시작하는 중입니다...';

    const formData = new FormData();
    formData.append('style_image', styleFile);
    formData.append('structure_image', structFile);
    formData.append('num_images', document.getElementById('num-images').value);

    const appendOptionalField = (fieldName, elementId) => {
        const element = document.getElementById(elementId);
        const value = element ? element.value.trim() : '';
        if (value) formData.append(fieldName, value);
    };

    appendOptionalField('prompt', 'prompt');
    appendOptionalField('negative_prompt', 'negative-prompt');
    appendOptionalField('depth_conditioning_scale', 'depth-conditioning-scale');
    appendOptionalField('lineart_conditioning_scale', 'lineart-conditioning-scale');
    appendOptionalField('ip_adapter_scale', 'ip-adapter-scale');
    appendOptionalField('guidance_scale', 'guidance-scale');
    appendOptionalField('num_inference_steps', 'num-inference-steps');

    try {
        const res = await fetch(`${getServerUrl()}/generate-live`, { method: 'POST', body: formData });
        const data = await res.json();
        if (!res.ok || !data.job_id) {
            throw new Error(data.detail || JSON.stringify(data));
        }

        activeGenerationJobId = data.job_id;
        progressText.textContent = `이미지 생성 중... 0/${requestedCount} 완료`;
        pollGenerationJob(data.job_id, requestedCount);
    } catch (e) {
        alert('생성 실패: ' + e.message);
        btn.disabled = false;
        progress.classList.remove('active');
    }
}
window.generateImages = generateImages;

function stopGenerationPolling() {
    if (generationPollTimer) {
        clearTimeout(generationPollTimer);
        generationPollTimer = null;
    }
    activeGenerationJobId = null;
}

async function pollGenerationJob(jobId, requestedCount) {
    const btn = document.getElementById('btn-generate');
    const progress = document.getElementById('progress-2d');
    const progressText = progress.querySelector('.progress-text');

    try {
        const res = await fetch(`${getServerUrl()}/generated-images/${jobId}?t=${Date.now()}`);
        const data = await res.json();
        if (!res.ok) {
            throw new Error(data.detail || JSON.stringify(data));
        }
        if (activeGenerationJobId !== jobId) return;

        const images = (data.images || []).map(normalizeGeneratedImage);
        generatedImages = images;
        renderResults(images);

        const total = data.total || requestedCount || images.length;
        const completed = data.completed !== undefined && data.completed !== null ? data.completed : images.length;
        progressText.textContent = `이미지 생성 중... ${completed}/${total} 완료`;

        if (data.status === 'success') {
            progressText.textContent = `이미지 생성 완료: ${images.length}/${total}`;
            generationPollTimer = setTimeout(() => progress.classList.remove('active'), 800);
            btn.disabled = false;
            activeGenerationJobId = null;
            return;
        }
        if (data.status === 'failed') {
            throw new Error(data.error || '이미지 생성 중 오류가 발생했습니다.');
        }

        generationPollTimer = setTimeout(() => pollGenerationJob(jobId, requestedCount), 1200);
    } catch (e) {
        if (activeGenerationJobId !== jobId) return;
        alert('생성 실패: ' + e.message);
        btn.disabled = false;
        progress.classList.remove('active');
        stopGenerationPolling();
    }
}

function normalizeGeneratedImage(item) {
    const imageUrl = item.image_url || item.url || '';
    const displayUrl = item.image_base64
        ? `data:image/png;base64,${item.image_base64}`
        : new URL(imageUrl, getServerUrl()).href;
    const cacheKey = item.seed !== undefined && item.seed !== null ? item.seed : (item.index !== undefined && item.index !== null ? item.index : Date.now());

    return {
        ...item,
        image_url: imageUrl,
        display_url: item.image_base64 ? displayUrl : `${displayUrl}?v=${cacheKey}`,
    };
}

function renderResults(images) {
    const container = document.getElementById('results-2d');
    container.innerHTML = '';
    images.forEach((item, i) => {
        const div = document.createElement('div');
        div.className = 'result-card';
        const seedLabel = item.seed !== undefined && item.seed !== null ? `seed ${item.seed}` : '';
        div.innerHTML = `
            <img src="${item.display_url}" alt="생성 이미지 ${i + 1}" />
            <div class="info">
                <div class="result-meta">
                    <span class="result-title">이미지 #${i + 1}</span>
                    <span class="result-seed">${seedLabel}</span>
                </div>
                <button class="send-btn" onclick="event.stopPropagation(); sendToTrellis(${i})">3D 생성 →</button>
            </div>
        `;
        container.appendChild(div);
    });
}

async function sendToTrellis(index) {
    const item = generatedImages[index];
    if (!item) return;

    try {
        const imageSrc = item.display_url || normalizeGeneratedImage(item).display_url;
        let blob;
        if (item.image_base64) {
            const byteStr = atob(item.image_base64);
            const arr = new Uint8Array(byteStr.length);
            for (let i = 0; i < byteStr.length; i++) arr[i] = byteStr.charCodeAt(i);
            blob = new Blob([arr], { type: 'image/png' });
        } else {
            const res = await fetch(imageSrc);
            if (!res.ok) throw new Error('이미지를 불러오지 못했습니다.');
            blob = await res.blob();
        }

        sharedState.imageForTrellis = { blob, name: item.filename || `merged_${index + 1}.png` };

        // 탭2 업로드 영역에 프리뷰 표시
        const zone = document.getElementById('zone-trellis-img');
        zone.querySelectorAll('.icon, .label, .preview').forEach(el => el.remove());
        const img = document.createElement('img');
        img.src = imageSrc;
        img.className = 'preview';
        zone.appendChild(img);
        zone.classList.add('has-image');

        // input 초기화 (sharedState 우선 사용)
        document.getElementById('input-trellis-img').value = '';

        switchTab('tab-3d-gen');
    } catch (e) {
        alert('3D 생성 탭으로 이미지를 전달하지 못했습니다: ' + e.message);
    }
}
window.sendToTrellis = sendToTrellis;

// ═══════════════════════════════════════════════
// Tab 2: 3D Model Generation (TRELLIS)
// ═══════════════════════════════════════════════
function handleTrellisUpload(input) {
    sharedState.imageForTrellis = null; // PC 업로드 시 shared 초기화
    handleUpload(input, 'zone-trellis-img');
}
window.handleTrellisUpload = handleTrellisUpload;

async function generate3D() {
    let imageBlob;
    const fileInput = document.getElementById('input-trellis-img');

    if (fileInput.files && fileInput.files[0]) {
        imageBlob = fileInput.files[0];
    } else if (sharedState.imageForTrellis) {
        imageBlob = sharedState.imageForTrellis.blob;
    } else {
        alert('3D 변환할 이미지를 업로드하거나, 2D 합병 탭에서 전달해주세요.');
        return;
    }

    const btn = document.getElementById('btn-3d');
    const progress = document.getElementById('progress-3d');
    btn.disabled = true;
    progress.classList.add('active');

    try {
        const formData = new FormData();
        formData.append('image', imageBlob, 'input.png');
        formData.append('filename', document.getElementById('filename-3d').value || 'output_model');
        formData.append('seed', document.getElementById('seed-3d').value || '42');

        const res = await fetch(`${getServerUrl()}/generate-3d`, { method: 'POST', body: formData });

        if (res.ok) {
            const glbBlob = await res.blob();
            const url = URL.createObjectURL(glbBlob);
            const fname = (document.getElementById('filename-3d').value || 'output_model') + '.glb';

            // 미니 뷰어에 로드
            window.loadGLB_mini(url);

            // 결과 영역 표시
            const resultArea = document.getElementById('trellis-result');
            resultArea.style.display = 'block';

            // 다운로드 + 뷰어 전송 버튼
            const btnRow = document.getElementById('trellis-btn-row');
            btnRow.innerHTML = `
                <a href="${url}" download="${fname}" class="btn btn-secondary btn-sm">⬇️ GLB 다운로드</a>
                <button class="btn btn-primary btn-sm" onclick="sendToViewer('${url}', '${fname}')">👁️ 뷰어에서 열기 →</button>
            `;
        } else {
            const err = await res.json();
            alert('3D 변환 실패: ' + (err.detail || JSON.stringify(err)));
        }
    } catch (e) {
        alert('서버 연결 실패: ' + e.message);
    } finally {
        btn.disabled = false;
        progress.classList.remove('active');
    }
}
window.generate3D = generate3D;

function sendToViewer(url, fname) {
    sharedState.glbForViewer = url;
    sharedState.glbFileName = fname;
    switchTab('tab-viewer');
    setTimeout(() => {
        window.loadGLB_full(url);
        document.getElementById('viewer-file-info').textContent = `📂 ${fname}`;
    }, 100);
}
window.sendToViewer = sendToViewer;

// ═══════════════════════════════════════════════
// Tab 3: 3D Viewer
// ═══════════════════════════════════════════════
function handleViewerUpload(input) {
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const url = URL.createObjectURL(file);
        sharedState.glbForViewer = url;
        sharedState.glbFileName = file.name;
        window.loadGLB_full(url);
        document.getElementById('viewer-file-info').textContent = `📂 ${file.name}`;
        document.getElementById('zone-viewer-file').classList.add('has-image');
        // 아이콘/라벨 숨기기
        const zone = document.getElementById('zone-viewer-file');
        zone.querySelectorAll('.icon, .label').forEach(el => el.style.display = 'none');
    }
}
window.handleViewerUpload = handleViewerUpload;
