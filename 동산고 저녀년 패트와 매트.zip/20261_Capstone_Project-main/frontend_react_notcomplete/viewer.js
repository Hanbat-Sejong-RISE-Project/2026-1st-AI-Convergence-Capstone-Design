import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

// ═══════════════════════════════════════════════
// Mini Viewer (Tab 2 - 3D 생성 결과 미리보기)
// ═══════════════════════════════════════════════
let miniScene, miniCamera, miniRenderer, miniControls;
let miniAmbient, miniMain, miniFill;

function initMiniViewer() {
    const container = document.getElementById('viewer-mini');
    container.innerHTML = '';
    container.style.color = '';

    miniScene = new THREE.Scene();
    miniScene.background = new THREE.Color(0x12121a);

    miniCamera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    miniCamera.position.set(0, 1, 3);

    miniRenderer = new THREE.WebGLRenderer({ antialias: true });
    miniRenderer.setSize(container.clientWidth, container.clientHeight);
    miniRenderer.setPixelRatio(window.devicePixelRatio);
    miniRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    miniRenderer.toneMappingExposure = 1.5;
    container.appendChild(miniRenderer.domElement);

    miniControls = new OrbitControls(miniCamera, miniRenderer.domElement);
    miniControls.enableDamping = true;
    miniControls.dampingFactor = 0.05;

    miniAmbient = new THREE.AmbientLight(0xffffff, 1.0);
    miniScene.add(miniAmbient);
    miniMain = new THREE.DirectionalLight(0xffffff, 1.5);
    miniMain.position.set(5, 5, 5);
    miniScene.add(miniMain);
    miniFill = new THREE.DirectionalLight(0xaabbff, 0.5);
    miniFill.position.set(-3, 2, -3);
    miniScene.add(miniFill);

    function animate() {
        requestAnimationFrame(animate);
        miniControls.update();
        miniRenderer.render(miniScene, miniCamera);
    }
    animate();
}

window.loadGLB_mini = function (url) {
    initMiniViewer();
    const loader = new GLTFLoader();
    loader.load(url, (gltf) => {
        miniScene.children.filter(c => c.type === 'Group' || c.type === 'Mesh').forEach(c => miniScene.remove(c));
        const model = gltf.scene;
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);
        const scale = 2 / maxDim;
        model.scale.setScalar(scale);
        model.position.sub(center.multiplyScalar(scale));
        miniScene.add(model);
        miniCamera.position.set(0, 1, 3);
        miniControls.reset();
    });
};

// ═══════════════════════════════════════════════
// Full Viewer (Tab 3 - 독립 3D 뷰어)
// ═══════════════════════════════════════════════
let fullScene, fullCamera, fullRenderer, fullControls;
let fullAmbient, fullMain, fullFill;
let fullInitialized = false;

function initFullViewer() {
    const container = document.getElementById('viewer-full');
    container.innerHTML = '';
    container.style.color = '';

    fullScene = new THREE.Scene();
    fullScene.background = new THREE.Color(0x12121a);

    fullCamera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 1000);
    fullCamera.position.set(0, 1, 3);

    fullRenderer = new THREE.WebGLRenderer({ antialias: true });
    fullRenderer.setSize(container.clientWidth, container.clientHeight);
    fullRenderer.setPixelRatio(window.devicePixelRatio);
    fullRenderer.toneMapping = THREE.ACESFilmicToneMapping;
    fullRenderer.toneMappingExposure = 1.5;
    container.appendChild(fullRenderer.domElement);

    fullControls = new OrbitControls(fullCamera, fullRenderer.domElement);
    fullControls.enableDamping = true;
    fullControls.dampingFactor = 0.05;

    fullAmbient = new THREE.AmbientLight(0xffffff, 1.0);
    fullScene.add(fullAmbient);
    fullMain = new THREE.DirectionalLight(0xffffff, 1.5);
    fullMain.position.set(5, 5, 5);
    fullScene.add(fullMain);
    fullFill = new THREE.DirectionalLight(0xaabbff, 0.5);
    fullFill.position.set(-3, 2, -3);
    fullScene.add(fullFill);

    applyFullBrightness();

    function animate() {
        requestAnimationFrame(animate);
        fullControls.update();
        fullRenderer.render(fullScene, fullCamera);
    }
    animate();

    window.addEventListener('resize', () => {
        if (!fullRenderer) return;
        fullCamera.aspect = container.clientWidth / container.clientHeight;
        fullCamera.updateProjectionMatrix();
        fullRenderer.setSize(container.clientWidth, container.clientHeight);
    });

    fullInitialized = true;
}

window.loadGLB_full = function (url) {
    initFullViewer();
    const loader = new GLTFLoader();
    loader.load(url, (gltf) => {
        fullScene.children.filter(c => c.type === 'Group' || c.type === 'Mesh').forEach(c => fullScene.remove(c));
        const model = gltf.scene;
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z);
        const scale = 2 / maxDim;
        model.scale.setScalar(scale);
        model.position.sub(center.multiplyScalar(scale));
        fullScene.add(model);
        fullCamera.position.set(0, 1, 3);
        fullControls.reset();
    });
};

// ── Brightness Control ──────────────────────────
function applyFullBrightness() {
    const slider = document.getElementById('light-intensity');
    if (!slider) return;
    const val = parseFloat(slider.value);
    if (fullAmbient) fullAmbient.intensity = 1.0 * val;
    if (fullMain) fullMain.intensity = 1.5 * val;
    if (fullFill) fullFill.intensity = 0.5 * val;
    if (fullRenderer) fullRenderer.toneMappingExposure = 1.5 * Math.sqrt(val);
}

document.getElementById('light-intensity')?.addEventListener('input', (e) => {
    document.getElementById('light-val').textContent = parseFloat(e.target.value).toFixed(1) + 'x';
    applyFullBrightness();
});

// ── Background Color Control ────────────────────
document.querySelectorAll('.bg-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.bg-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const color = btn.dataset.color;
        if (fullScene) fullScene.background = new THREE.Color(parseInt(color, 16));
    });
});
