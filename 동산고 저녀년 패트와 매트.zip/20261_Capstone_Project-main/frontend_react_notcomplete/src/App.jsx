import React, { useMemo, useState } from 'react';
import Header from './components/Header.jsx';
import ServerBar from './components/ServerBar.jsx';
import TabNav from './components/TabNav.jsx';
import ImageMergeTab from './components/ImageMergeTab.jsx';
import TrellisTab from './components/TrellisTab.jsx';
import ModelViewerTab from './components/ModelViewerTab.jsx';

const tabs = [
  { id: 'tab-2d', label: '🎨 2D 이미지 합병' },
  { id: 'tab-3d-gen', label: '🧊 3D 모델 생성' },
  { id: 'tab-viewer', label: '👁️ 3D 뷰어' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState('tab-2d');
  const [serverUrl, setServerUrl] = useState('http://localhost:8000');
  const [imageForTrellis, setImageForTrellis] = useState(null);
  const [viewerModel, setViewerModel] = useState(null);

  const apiBaseUrl = useMemo(() => serverUrl.replace(/\/+$/, ''), [serverUrl]);

  return (
    <div className="app-wrapper">
      <Header />
      <ServerBar serverUrl={serverUrl} setServerUrl={setServerUrl} apiBaseUrl={apiBaseUrl} />
      <TabNav tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

      <ImageMergeTab
        active={activeTab === 'tab-2d'}
        apiBaseUrl={apiBaseUrl}
        onSendToTrellis={(image) => {
          setImageForTrellis(image);
          setActiveTab('tab-3d-gen');
        }}
      />
      <TrellisTab
        active={activeTab === 'tab-3d-gen'}
        apiBaseUrl={apiBaseUrl}
        imageForTrellis={imageForTrellis}
        onImageUpload={() => setImageForTrellis(null)}
        onSendToViewer={(model) => {
          setViewerModel(model);
          setActiveTab('tab-viewer');
        }}
      />
      <ModelViewerTab
        active={activeTab === 'tab-viewer'}
        viewerModel={viewerModel}
        onViewerUpload={setViewerModel}
      />

      <footer className="footer">2D→3D Pipeline · Capstone Project</footer>
    </div>
  );
}
