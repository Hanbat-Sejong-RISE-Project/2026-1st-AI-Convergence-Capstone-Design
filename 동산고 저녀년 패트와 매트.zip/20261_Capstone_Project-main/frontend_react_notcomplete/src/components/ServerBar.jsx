import React, { useEffect, useState } from 'react';

export default function ServerBar({ serverUrl, setServerUrl, apiBaseUrl }) {
  const [status, setStatus] = useState('');

  async function checkHealth() {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 5000);
      const response = await fetch(`${apiBaseUrl}/health`, { signal: controller.signal });
      clearTimeout(timer);
      const data = await response.json();
      setStatus(data.status === 'ok' ? 'connected' : 'error');
    } catch {
      setStatus('error');
    }
  }

  useEffect(() => {
    const timer = setTimeout(checkHealth, 500);
    return () => clearTimeout(timer);
  }, [apiBaseUrl]);

  return (
    <div className="server-bar">
      <label htmlFor="server-url">🖥️ 서버 주소</label>
      <input
        type="text"
        id="server-url"
        value={serverUrl}
        placeholder="http://서버IP:포트"
        onChange={(event) => setServerUrl(event.target.value)}
      />
      <button className="btn btn-secondary" type="button" onClick={checkHealth}>
        연결 확인
      </button>
      <div className={`status-dot ${status}`} />
    </div>
  );
}
