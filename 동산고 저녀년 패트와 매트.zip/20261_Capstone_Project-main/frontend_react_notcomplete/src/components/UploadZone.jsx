import React, { useRef } from 'react';

export default function UploadZone({
  id,
  accept,
  icon,
  label,
  previewUrl,
  single = false,
  onFile,
}) {
  const inputRef = useRef(null);
  const className = `${single ? 'upload-zone-single' : 'upload-zone'} ${previewUrl ? 'has-image' : ''}`;

  return (
    <button className={className} type="button" onClick={() => inputRef.current?.click()}>
      <input
        ref={inputRef}
        className="hidden-file-input"
        type="file"
        id={id}
        accept={accept}
        onChange={(event) => onFile(event.target.files?.[0] || null)}
      />
      {previewUrl ? (
        <img className="preview" src={previewUrl} alt="" />
      ) : (
        <>
          <div className="icon">{icon}</div>
          <div className="label">{label}</div>
        </>
      )}
    </button>
  );
}
