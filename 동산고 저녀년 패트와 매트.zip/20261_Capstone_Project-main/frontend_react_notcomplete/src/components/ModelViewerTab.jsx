import React, { useEffect, useState } from 'react';
import UploadZone from './UploadZone.jsx';
import ThreeViewer from './ThreeViewer.jsx';

const backgrounds = [
  { className: 'dark', color: '12121a', title: '다크' },
  { className: 'light', color: 'f0f0f0', title: '라이트' },
  { className: 'gray', color: '555555', title: '그레이' },
];

export default function ModelViewerTab({ active, viewerModel, onViewerUpload }) {
  const [fileName, setFileName] = useState('');
  const [brightness, setBrightness] = useState(1);
  const [backgroundColor, setBackgroundColor] = useState('12121a');

  useEffect(() => {
    setFileName(viewerModel?.name || '');
  }, [viewerModel]);

  function handleFile(file) {
    if (!file) return;
    const url = URL.createObjectURL(file);
    onViewerUpload({ url, name: file.name });
  }

  return (
    <div className={`tab-panel ${active ? 'active' : ''}`} id="tab-viewer">
      <div className="card">
        <div className="card-title">
          <span className="emoji">👁️</span> 3D 모델 뷰어
        </div>
        <p className="muted-copy">
          GLB / GLTF 파일을 업로드하거나, 3D 생성 탭에서 전달된 모델을 확인하세요.
        </p>

        <UploadZone
          id="input-viewer-file"
          accept=".glb,.gltf"
          icon="📦"
          label={<>GLB / GLTF 파일을 업로드하세요<br />(또는 3D 생성 탭에서 전달)</>}
          single
          onFile={handleFile}
        />

        <div id="viewer-file-info" style={{ marginTop: 8, fontSize: '0.85rem', color: 'var(--text-secondary)' }}>
          {fileName ? `📂 ${fileName}` : ''}
        </div>

        <ThreeViewer
          id="viewer-full"
          label="3D 모델이 여기에 표시됩니다"
          modelUrl={viewerModel?.url}
          active={active}
          brightness={brightness}
          backgroundColor={backgroundColor}
          full
        />

        <div className="viewer-controls">
          <label htmlFor="light-intensity">💡 밝기</label>
          <input
            type="range"
            id="light-intensity"
            min="0.1"
            max="4.0"
            step="0.1"
            value={brightness}
            onChange={(event) => setBrightness(Number(event.target.value))}
          />
          <span className="val" id="light-val">{brightness.toFixed(1)}x</span>

          <div className="bg-btn-group">
            {backgrounds.map((background) => (
              <button
                key={background.color}
                className={`bg-btn ${background.className} ${backgroundColor === background.color ? 'active' : ''}`}
                type="button"
                title={background.title}
                onClick={() => setBackgroundColor(background.color)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
