import React, { useEffect, useRef, useState } from 'react';
import UploadZone from './UploadZone.jsx';

function filePreview(file) {
  return file ? URL.createObjectURL(file) : '';
}

function normalizeGeneratedImage(item, apiBaseUrl) {
  const imageUrl = item.image_url || item.url || '';
  const displayUrl = item.image_base64
    ? `data:image/png;base64,${item.image_base64}`
    : `${new URL(imageUrl, apiBaseUrl).href}?v=${item.seed ?? item.index ?? Date.now()}`;

  return {
    ...item,
    imageUrl,
    displayUrl,
    name: item.filename || `merged_${(item.index ?? 0) + 1}.png`,
  };
}

async function imageToBlob(item) {
  if (item.image_base64) {
    const byteString = atob(item.image_base64);
    const bytes = new Uint8Array(byteString.length);
    for (let i = 0; i < byteString.length; i += 1) bytes[i] = byteString.charCodeAt(i);
    return new Blob([bytes], { type: 'image/png' });
  }

  const response = await fetch(item.displayUrl);
  if (!response.ok) throw new Error('이미지를 불러오지 못했습니다.');
  return response.blob();
}

export default function ImageMergeTab({ active, apiBaseUrl, onSendToTrellis }) {
  const [styleFile, setStyleFile] = useState(null);
  const [structureFile, setStructureFile] = useState(null);
  const [stylePreview, setStylePreview] = useState('');
  const [structurePreview, setStructurePreview] = useState('');
  const [prompt, setPrompt] = useState('');
  const [negativePrompt, setNegativePrompt] = useState('');
  const [advancedSettings, setAdvancedSettings] = useState({
    depthConditioningScale: '',
    lineartConditioningScale: '',
    ipAdapterScale: '',
    guidanceScale: '',
    numInferenceSteps: '',
  });
  const [numImages, setNumImages] = useState(4);
  const [results, setResults] = useState([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressText, setProgressText] = useState('');
  const pollTimerRef = useRef(null);
  const activeJobRef = useRef(null);

  useEffect(() => () => {
    if (stylePreview) URL.revokeObjectURL(stylePreview);
    if (structurePreview) URL.revokeObjectURL(structurePreview);
    if (pollTimerRef.current) clearTimeout(pollTimerRef.current);
  }, [stylePreview, structurePreview]);

  function updateStyleFile(file) {
    if (stylePreview) URL.revokeObjectURL(stylePreview);
    setStyleFile(file);
    setStylePreview(filePreview(file));
  }

  function updateStructureFile(file) {
    if (structurePreview) URL.revokeObjectURL(structurePreview);
    setStructureFile(file);
    setStructurePreview(filePreview(file));
  }

  async function pollGenerationJob(jobId, requestedCount) {
    try {
      const response = await fetch(`${apiBaseUrl}/generated-images/${jobId}?t=${Date.now()}`);
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || JSON.stringify(data));
      if (activeJobRef.current !== jobId) return;

      const images = (data.images || []).map((item) => normalizeGeneratedImage(item, apiBaseUrl));
      setResults(images);

      const total = data.total || requestedCount || images.length;
      const completed = data.completed ?? images.length;
      setProgressText(`이미지 생성 중... ${completed}/${total} 완료`);

      if (data.status === 'success') {
        setProgressText(`이미지 생성 완료: ${images.length}/${total}`);
        setIsGenerating(false);
        activeJobRef.current = null;
        return;
      }

      if (data.status === 'failed') {
        throw new Error(data.error || '이미지 생성 중 오류가 발생했습니다.');
      }

      pollTimerRef.current = setTimeout(() => pollGenerationJob(jobId, requestedCount), 1200);
    } catch (error) {
      if (activeJobRef.current !== jobId) return;
      alert(`생성 실패: ${error.message}`);
      setIsGenerating(false);
      setProgressText('');
      activeJobRef.current = null;
    }
  }

  async function handleGenerate() {
    const trimmedPrompt = prompt.trim();

    if (!styleFile || !structureFile) {
      alert('스타일 이미지와 구조 이미지를 모두 업로드해주세요.');
      return;
    }

    if (pollTimerRef.current) clearTimeout(pollTimerRef.current);
    setResults([]);
    setIsGenerating(true);
    setProgressText('이미지 생성 작업을 시작하는 중입니다...');

    const formData = new FormData();
    formData.append('style_image', styleFile);
    formData.append('structure_image', structureFile);
    formData.append('num_images', numImages);

    const optionalFields = {
      prompt: trimmedPrompt,
      negative_prompt: negativePrompt.trim(),
      depth_conditioning_scale: advancedSettings.depthConditioningScale.trim(),
      lineart_conditioning_scale: advancedSettings.lineartConditioningScale.trim(),
      ip_adapter_scale: advancedSettings.ipAdapterScale.trim(),
      guidance_scale: advancedSettings.guidanceScale.trim(),
      num_inference_steps: advancedSettings.numInferenceSteps.trim(),
    };
    Object.entries(optionalFields).forEach(([key, value]) => {
      if (value) formData.append(key, value);
    });

    try {
      const response = await fetch(`${apiBaseUrl}/generate-live`, { method: 'POST', body: formData });
      const data = await response.json();
      if (!response.ok || !data.job_id) throw new Error(data.detail || JSON.stringify(data));

      activeJobRef.current = data.job_id;
      setProgressText(`이미지 생성 중... 0/${numImages} 완료`);
      pollGenerationJob(data.job_id, Number(numImages));
    } catch (error) {
      alert(`생성 실패: ${error.message}`);
      setIsGenerating(false);
      setProgressText('');
      activeJobRef.current = null;
    }
  }

  async function handleSendToTrellis(item) {
    try {
      const blob = await imageToBlob(item);
      onSendToTrellis({ blob, name: item.name, previewUrl: item.displayUrl });
    } catch (error) {
      alert(`3D 생성 탭으로 이미지를 전달하지 못했습니다: ${error.message}`);
    }
  }

  return (
    <div className={`tab-panel ${active ? 'active' : ''}`} id="tab-2d">
      <div className="card">
        <div className="card-title">
          <span className="emoji">🎨</span> 2D 이미지 합병 생성
        </div>

        <div className="upload-row">
          <UploadZone
            id="input-style"
            accept="image/*"
            icon="🖼️"
            label={<>스타일 참조 이미지<br />(예: 복숭아)</>}
            previewUrl={stylePreview}
            onFile={updateStyleFile}
          />
          <UploadZone
            id="input-structure"
            accept="image/*"
            icon="📐"
            label={<>구조 참조 이미지<br />(예: 에어팟 케이스)</>}
            previewUrl={structurePreview}
            onFile={updateStructureFile}
          />
        </div>

        <div className="form-group" style={{ marginTop: 16 }}>
          <label htmlFor="num-images">생성할 이미지의 개수</label>
          <input
            type="number"
            id="num-images"
            min="1"
            max="20"
            step="1"
            value={numImages}
            onChange={(event) => setNumImages(event.target.value)}
          />
        </div>

        <details className="advanced-settings">
          <summary>고급 설정</summary>
          <div className="advanced-content">
            <div className="form-group">
              <label htmlFor="prompt">프롬프트</label>
              <textarea
                id="prompt"
                rows="2"
                value={prompt}
                placeholder="서버 기본값 사용"
                onChange={(event) => setPrompt(event.target.value)}
              />
            </div>
            <div className="form-group">
              <label htmlFor="negative-prompt">네거티브 프롬프트</label>
              <input
                type="text"
                id="negative-prompt"
                value={negativePrompt}
                placeholder="서버 기본값 사용"
                onChange={(event) => setNegativePrompt(event.target.value)}
              />
            </div>
            <div className="advanced-grid">
              <div className="form-group">
                <label htmlFor="depth-conditioning-scale">Depth 반영 강도</label>
                <input
                  type="number"
                  id="depth-conditioning-scale"
                  min="0"
                  max="2"
                  step="0.05"
                  value={advancedSettings.depthConditioningScale}
                  placeholder="0.75"
                  onChange={(event) => setAdvancedSettings({ ...advancedSettings, depthConditioningScale: event.target.value })}
                />
              </div>
              <div className="form-group">
                <label htmlFor="lineart-conditioning-scale">윤곽선 반영 강도</label>
                <input
                  type="number"
                  id="lineart-conditioning-scale"
                  min="0"
                  max="2"
                  step="0.05"
                  value={advancedSettings.lineartConditioningScale}
                  placeholder="0.65"
                  onChange={(event) => setAdvancedSettings({ ...advancedSettings, lineartConditioningScale: event.target.value })}
                />
              </div>
              <div className="form-group">
                <label htmlFor="ip-adapter-scale">디자인 이미지 반영 강도</label>
                <input
                  type="number"
                  id="ip-adapter-scale"
                  min="0"
                  max="2"
                  step="0.05"
                  value={advancedSettings.ipAdapterScale}
                  placeholder="0.55"
                  onChange={(event) => setAdvancedSettings({ ...advancedSettings, ipAdapterScale: event.target.value })}
                />
              </div>
              <div className="form-group">
                <label htmlFor="guidance-scale">프롬프트 반영 강도</label>
                <input
                  type="number"
                  id="guidance-scale"
                  min="1"
                  max="15"
                  step="0.5"
                  value={advancedSettings.guidanceScale}
                  placeholder="8.0"
                  onChange={(event) => setAdvancedSettings({ ...advancedSettings, guidanceScale: event.target.value })}
                />
              </div>
              <div className="form-group">
                <label htmlFor="num-inference-steps">생성 단계 수</label>
                <input
                  type="number"
                  id="num-inference-steps"
                  min="10"
                  max="60"
                  step="1"
                  value={advancedSettings.numInferenceSteps}
                  placeholder="30"
                  onChange={(event) => setAdvancedSettings({ ...advancedSettings, numInferenceSteps: event.target.value })}
                />
              </div>
            </div>
          </div>
        </details>

        <button className="btn btn-primary" type="button" disabled={isGenerating} onClick={handleGenerate}>
          ✨ 이미지 생성
        </button>

        <div className={`progress-wrapper ${isGenerating || progressText ? 'active' : ''}`} id="progress-2d">
          <div className="progress-bar"><div className="fill" /></div>
          <div className="progress-text">{progressText}</div>
        </div>

        <div className="results-grid" id="results-2d">
          {results.map((item, index) => (
            <div className="result-card" key={`${item.name}-${index}`}>
              <img src={item.displayUrl} alt={`생성 이미지 ${index + 1}`} />
              <div className="info">
                <div className="result-meta">
                  <span className="result-title">이미지 #{index + 1}</span>
                  <span className="result-seed">{item.seed !== undefined && item.seed !== null ? `seed ${item.seed}` : ''}</span>
                </div>
                <button className="send-btn" type="button" onClick={() => handleSendToTrellis(item)}>
                  3D 생성 →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
