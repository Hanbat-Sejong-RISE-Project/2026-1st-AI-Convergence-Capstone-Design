import React from 'react';
export default function Header() {
  return (
    <header className="header">
      <h1>2D→3D Pipeline</h1>
      <p>2D 이미지 합병 및 3D 모델링 생성 파이프라인</p>
    </header>
  );
}
