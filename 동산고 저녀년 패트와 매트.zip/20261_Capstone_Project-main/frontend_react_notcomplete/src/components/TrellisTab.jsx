import React, { useEffect, useState } from 'react';
import UploadZone from './UploadZone.jsx';
import ThreeViewer from './ThreeViewer.jsx';

export default function TrellisTab({ active, apiBaseUrl, imageForTrellis, onImageUpload, onSendToViewer }) {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadedPreviewUrl, setUploadedPreviewUrl] = useState('');
  const [filename, setFilename] = useState('');
  const [seed, setSeed] = useState('42');
  const [generatedModel, setGeneratedModel] = useState(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const previewUrl = uploadedPreviewUrl || imageForTrellis?.previewUrl || '';

  useEffect(() => () => {
    if (uploadedPreviewUrl) URL.revokeObjectURL(uploadedPreviewUrl);
    if (generatedModel?.url) URL.revokeObjectURL(generatedModel.url);
  }, [uploadedPreviewUrl, generatedModel]);

  function handleFile(file) {
    if (uploadedPreviewUrl) URL.revokeObjectURL(uploadedPreviewUrl);
    setUploadedFile(file);
    setUploadedPreviewUrl(file ? URL.createObjectURL(file) : '');
    onImageUpload();
  }

  async function handleGenerate3D() {
    const imageBlob = uploadedFile || imageForTrellis?.blob;
    if (!imageBlob) {
      alert('3D 변환할 이미지를 업로드하거나, 2D 합병 탭에서 전달해주세요.');
      return;
    }

    setIsGenerating(true);
    const outputName = filename.trim() || 'output_model';
    const formData = new FormData();
    formData.append('image', imageBlob, uploadedFile?.name || imageForTrellis?.name || 'input.png');
    formData.append('filename', outputName);
    formData.append('seed', seed || '42');

    try {
      const response = await fetch(`${apiBaseUrl}/generate-3d`, { method: 'POST', body: formData });
      if (!response.ok) {
        const text = await response.text();
        try {
          const data = JSON.parse(text);
          throw new Error(data.detail || text);
        } catch {
          throw new Error(text || '3D 변환 실패');
        }
      }

      if (generatedModel?.url) URL.revokeObjectURL(generatedModel.url);
      const glbBlob = await response.blob();
      const url = URL.createObjectURL(glbBlob);
      setGeneratedModel({ url, name: `${outputName}.glb` });
    } catch (error) {
      alert(`3D 변환 실패: ${error.message}`);
    } finally {
      setIsGenerating(false);
    }
  }

  return (
    <div className={`tab-panel ${active ? 'active' : ''}`} id="tab-3d-gen">
      <div className="card">
        <div className="card-title">
          <span className="emoji">🧊</span> 3D 모델 생성 (TRELLIS)
        </div>
        <p className="muted-copy">
          PC에서 이미지를 직접 업로드하거나, 2D 합병 탭에서 전달된 이미지를 사용하여 3D 모델을 생성합니다.
        </p>

        <UploadZone
          id="input-trellis-img"
          accept="image/*"
          icon="🖼️"
          label={<>3D로 변환할 이미지를 업로드하세요<br />(또는 2D 합병 탭에서 전달)</>}
          previewUrl={previewUrl}
          single
          onFile={handleFile}
        />

        <div className="inline-grid">
          <div className="form-group">
            <label htmlFor="filename-3d">출력 파일명</label>
            <input
              type="text"
              id="filename-3d"
              value={filename}
              placeholder="예: peach_case_3d"
              onChange={(event) => setFilename(event.target.value)}
            />
          </div>
          <div className="form-group">
            <label htmlFor="seed-3d">시드</label>
            <input
              type="text"
              id="seed-3d"
              value={seed}
              placeholder="42"
              onChange={(event) => setSeed(event.target.value)}
            />
          </div>
        </div>

        <button className="btn btn-primary" type="button" disabled={isGenerating} onClick={handleGenerate3D}>
          🚀 3D 변환 시작
        </button>

        <div className={`progress-wrapper ${isGenerating ? 'active' : ''}`} id="progress-3d">
          <div className="progress-bar"><div className="fill" /></div>
          <div className="progress-text">3D 모델 생성 중... 몇 분 소요될 수 있습니다.</div>
        </div>

        {generatedModel && (
          <div id="trellis-result" style={{ marginTop: 20 }}>
            <h3 className="section-result-title">── 변환 결과 ──</h3>
            <ThreeViewer id="viewer-mini" label="3D 모델 미리보기" modelUrl={generatedModel.url} active={active} />
            <div className="btn-row" id="trellis-btn-row">
              <a href={generatedModel.url} download={generatedModel.name} className="btn btn-secondary btn-sm">
                ⬇️ GLB 다운로드
              </a>
              <button
                className="btn btn-primary btn-sm"
                type="button"
                onClick={() => onSendToViewer(generatedModel)}
              >
                👁️ 뷰어에서 열기 →
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
