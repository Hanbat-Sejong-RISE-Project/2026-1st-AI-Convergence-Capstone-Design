import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

export default function ThreeViewer({ id, label, modelUrl, active = true, full = false, brightness = 1, backgroundColor = '12121a' }) {
  const containerRef = useRef(null);
  const sceneRef = useRef(null);
  const rendererRef = useRef(null);
  const cameraRef = useRef(null);
  const controlsRef = useRef(null);
  const lightsRef = useRef({});
  const modelRef = useRef(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || !active || !modelUrl) return undefined;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(parseInt(backgroundColor, 16));
    sceneRef.current = scene;

    const width = container.clientWidth || 800;
    const height = container.clientHeight || (full ? 500 : 450);
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 1, 3);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(window.devicePixelRatio || 1);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.5 * Math.sqrt(brightness);
    rendererRef.current = renderer;
    container.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controlsRef.current = controls;

    const ambient = new THREE.AmbientLight(0xffffff, 1.0 * brightness);
    const main = new THREE.DirectionalLight(0xffffff, 1.5 * brightness);
    const fill = new THREE.DirectionalLight(0xaabbff, 0.5 * brightness);
    main.position.set(5, 5, 5);
    fill.position.set(-3, 2, -3);
    scene.add(ambient, main, fill);
    lightsRef.current = { ambient, main, fill };

    let frameId;
    function animate() {
      frameId = requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    }
    animate();

    function handleResize() {
      const nextWidth = container.clientWidth || width;
      const nextHeight = container.clientHeight || height;
      camera.aspect = nextWidth / nextHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(nextWidth, nextHeight);
    }
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      controls.dispose();
      renderer.dispose();
      if (renderer.domElement.parentNode === container) container.removeChild(renderer.domElement);
      scene.traverse((object) => {
        if (object.geometry) object.geometry.dispose();
        if (object.material) {
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((material) => material.dispose());
        }
      });
      sceneRef.current = null;
      rendererRef.current = null;
      cameraRef.current = null;
      controlsRef.current = null;
      modelRef.current = null;
    };
  }, [active, modelUrl]);

  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;
    scene.background = new THREE.Color(parseInt(backgroundColor, 16));
  }, [backgroundColor]);

  useEffect(() => {
    const { ambient, main, fill } = lightsRef.current;
    if (ambient) ambient.intensity = 1.0 * brightness;
    if (main) main.intensity = 1.5 * brightness;
    if (fill) fill.intensity = 0.5 * brightness;
    if (rendererRef.current) rendererRef.current.toneMappingExposure = 1.5 * Math.sqrt(brightness);
  }, [brightness]);

  useEffect(() => {
    const scene = sceneRef.current;
    const camera = cameraRef.current;
    const controls = controlsRef.current;
    if (!scene || !camera || !controls || !modelUrl || !active) return undefined;

    let cancelled = false;
    const loader = new GLTFLoader();
    loader.load(
      modelUrl,
      (gltf) => {
        if (cancelled) return;
        if (modelRef.current) scene.remove(modelRef.current);

        const model = gltf.scene;
        const box = new THREE.Box3().setFromObject(model);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        const scale = 2 / maxDim;

        model.scale.setScalar(scale);
        model.position.sub(center.multiplyScalar(scale));
        scene.add(model);
        modelRef.current = model;

        camera.position.set(0, 1, 3);
        controls.target.set(0, 0, 0);
        controls.update();
      },
      undefined,
      (error) => {
        console.error('GLB load failed', error);
      },
    );

    return () => {
      cancelled = true;
    };
  }, [modelUrl, active]);

  return (
    <div ref={containerRef} className="viewer-3d" id={id} style={full ? { height: 500 } : undefined}>
      {!modelUrl ? <span>{label}</span> : null}
    </div>
  );
}
