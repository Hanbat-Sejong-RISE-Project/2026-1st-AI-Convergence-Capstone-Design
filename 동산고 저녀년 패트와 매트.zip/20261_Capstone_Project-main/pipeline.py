"""
pipeline.py — 2D 이미지 합병 및 3D 모델링 생성 파이프라인
─────────────────────────────────────────────────────────
config.yaml에서 모든 경로를 읽어와 유연하게 동작합니다.
"""

import os
import sys
import gc
import random
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import yaml
import torch
import numpy as np
from PIL import Image, ImageOps, ImageEnhance, ImageFilter


# ═══════════════════════════════════════════════════════
# 1. Config 로딩
# ═══════════════════════════════════════════════════════
@dataclass
class ModelsConfig:
    base_model: str = "stabilityai/stable-diffusion-xl-base-1.0"
    controlnet: str = "diffusers/controlnet-depth-sdxl-1.0"
    depth_controlnet: str = "diffusers/controlnet-depth-sdxl-1.0"
    lineart_controlnet: str = "TheMistoAI/MistoLine"
    lineart_detector: str = "lllyasviel/Annotators"
    image_encoder: str = "models/image_encoder"
    ip_adapter_ckpt: str = ""
    ip_adapter_lib_path: str = ""
    depth_estimator: str = "Intel/dpt-hybrid-midas"
    trellis_lib_path: str = ""
    o_voxel_lib_path: str = ""
    trellis_ckpt: str = "microsoft/TRELLIS.2-4B"


@dataclass
class PathsConfig:
    output_dir: str = "./output_3d"
    upload_dir: str = "./uploads"


@dataclass
class GenerationConfig:
    # baseline_v2_upgraded.ipynb 기준값
    num_images: int = 4
    prompt: str = (
        "pure white background, plain white background, seamless white studio backdrop, "
        "isolated product photography, studio lighting, clean product shot"
    )
    negative_prompt: str = (
        "colored background, gradient background, gray background, beige background, "
        "dark background, shadowy background, room, table, floor, wall, outdoor, leaves, "
        "plant, clutter, blurry, low quality, noise, artifact, ugly, "
        "low resolution, pixelated, watermark"
    )
    controlnet_conditioning_scale: float = 0.6  # 하위 호환용. 실제 생성은 depth/lineart 개별 scale 사용
    depth_conditioning_scale: float = 0.75
    lineart_conditioning_scale: float = 0.65
    ip_adapter_scale: float = 0.55
    guidance_scale: float = 8.0
    num_inference_steps: int = 30
    max_style_size: int = 768
    max_condition_size: int = 1024

    # 노트북의 force_near_white_background 반영
    force_white_background: bool = True
    white_background_threshold: int = 220

    # 노트북의 extract_ultimate_lineart 반영
    use_ultimate_lineart: bool = True
    lineart_use_rembg: bool = True
    lineart_mask_dilate_kernel: int = 7
    lineart_clahe_clip_limit: float = 4.0
    lineart_clahe_tile_grid_size: int = 8
    lineart_canny_threshold1: int = 20
    lineart_canny_threshold2: int = 80
    lineart_dl_weight: float = 0.8
    lineart_canny_weight: float = 0.6
    lineart_clean_threshold: int = 35
    lineart_contrast: float = 1.4


@dataclass
class MeshConfig:
    sparse_steps: int = 12
    slat_steps: int = 12
    sparse_cfg: float = 7.5
    slat_cfg: float = 3.0
    simplify: float = 0.95
    texture_size: int = 2048
    image_size: int = 1024
    white_threshold: int = 30
    crop_padding: int = 24
    contrast: float = 1.08
    sharpness: float = 1.15
    unsharp_radius: float = 1.2
    unsharp_percent: int = 90
    unsharp_threshold: int = 3
    simplify_target: int = 2_000_000
    decimation_target: int = 300_000
    remesh: bool = True
    remesh_band: int = 1
    remesh_project: int = 0
    real_scale_enabled: bool = True
    real_scale_target_width_mm: float = 18.0
    real_scale_suffix: str = "_real_scale"


@dataclass
class ServerConfig:
    host: str = "0.0.0.0"
    port: int = 8000
    device: str = "cuda"
    serve_frontend: bool = True


@dataclass
class AppConfig:
    models: ModelsConfig = field(default_factory=ModelsConfig)
    paths: PathsConfig = field(default_factory=PathsConfig)
    generation: GenerationConfig = field(default_factory=GenerationConfig)
    mesh: MeshConfig = field(default_factory=MeshConfig)
    server: ServerConfig = field(default_factory=ServerConfig)


def _dataclass_from_dict(cls, values: Optional[dict]):
    """config.yaml에 불필요한 키가 있어도 깨지지 않도록 dataclass 필드만 반영합니다."""
    if not values:
        return cls()
    allowed = cls.__dataclass_fields__.keys()
    return cls(**{k: v for k, v in values.items() if k in allowed})


def load_config(config_path: str = "config.yaml") -> AppConfig:
    """YAML 파일에서 설정을 로드합니다."""
    with open(config_path, "r", encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    cfg = AppConfig()
    cfg.models = _dataclass_from_dict(ModelsConfig, raw.get("models"))
    cfg.paths = _dataclass_from_dict(PathsConfig, raw.get("paths"))
    cfg.generation = _dataclass_from_dict(GenerationConfig, raw.get("generation"))
    cfg.mesh = _dataclass_from_dict(MeshConfig, raw.get("mesh"))
    cfg.server = _dataclass_from_dict(ServerConfig, raw.get("server"))
    return cfg


# ═══════════════════════════════════════════════════════
# 2. 파이프라인 매니저
# ═══════════════════════════════════════════════════════
class PipelineManager:
    """
    모델 로딩과 추론을 일원화한 파이프라인 매니저.
    서버 시작 시 한 번만 초기화됩니다.
    """

    def __init__(self, config: AppConfig):
        self.cfg = config
        self.device = config.server.device
        if self.device == "cuda" and not torch.cuda.is_available():
            print("  CUDA를 사용할 수 없어 CPU로 전환합니다.")
            self.device = "cpu"

        # 모델 참조 (lazy load)
        self._pipe = None        # SDXL + ControlNet 파이프라인
        self._ip_model = None    # IP-Adapter
        self._depth_estimator = None
        self._lineart_detector = None
        self._trellis_pipeline = None

        # 출력 디렉토리 확보
        os.makedirs(config.paths.output_dir, exist_ok=True)
        os.makedirs(config.paths.upload_dir, exist_ok=True)

    # ── 모델 로딩 ────────────────────────────────────────

    def load_sdxl(self):
        """SDXL + ControlNet + IP-Adapter 모델을 로드합니다."""
        # IP-Adapter 라이브러리 경로를 sys.path에 추가
        ip_lib = self.cfg.models.ip_adapter_lib_path
        if ip_lib and os.path.isdir(ip_lib):
            abs_path = os.path.abspath(ip_lib)
            if abs_path not in sys.path:
                sys.path.insert(0, abs_path)
                print(f"  📁 sys.path에 추가: {abs_path}")

        from diffusers import StableDiffusionXLControlNetPipeline, ControlNetModel

        torch_dtype = torch.float16 if self.device == "cuda" else torch.float32
        depth_controlnet_id = self.cfg.models.depth_controlnet or self.cfg.models.controlnet

        print("⏳ ControlNet 로드 중...")
        depth_controlnet = ControlNetModel.from_pretrained(
            depth_controlnet_id,
            variant="fp16" if self.device == "cuda" else None,
            use_safetensors=True,
            torch_dtype=torch_dtype,
        ).to(self.device)
        lineart_controlnet = ControlNetModel.from_pretrained(
            self.cfg.models.lineart_controlnet,
            variant="fp16" if self.device == "cuda" else None,
            torch_dtype=torch_dtype,
        ).to(self.device)

        print("⏳ SDXL 파이프라인 로드 중...")
        self._pipe = StableDiffusionXLControlNetPipeline.from_pretrained(
            self.cfg.models.base_model,
            controlnet=[depth_controlnet, lineart_controlnet],
            use_safetensors=True,
            torch_dtype=torch_dtype,
            add_watermarker=False,
        ).to(self.device)
        self._pipe.enable_vae_tiling()
        self._pipe.enable_vae_slicing()
        try:
            self._pipe.enable_xformers_memory_efficient_attention()
        except Exception as exc:
            print(f"  xFormers skip: {type(exc).__name__}")

        print("⏳ IP-Adapter Plus 로드 중...")
        self._patch_ip_adapter_for_multicontrolnet()
        from ip_adapter import IPAdapterPlusXL

        self._ip_model = IPAdapterPlusXL(
            self._pipe,
            self.cfg.models.image_encoder,
            self.cfg.models.ip_adapter_ckpt,
            self.device,
            num_tokens=16,
        )
        print("✅ SDXL + IP-Adapter Plus 로드 완료")

    @staticmethod
    def _patch_ip_adapter_for_multicontrolnet():
        """IP-Adapter가 Diffusers MultiControlNetModel도 패치하도록 보강합니다."""
        from ip_adapter.ip_adapter import IPAdapter, CNAttnProcessor

        original_set_ip_adapter = IPAdapter.set_ip_adapter
        if getattr(original_set_ip_adapter, "_multicontrolnet_patched", False):
            return

        def patched_set_ip_adapter(self):
            controlnet = getattr(self.pipe, "controlnet", None)
            is_multi_controlnet = hasattr(controlnet, "nets") and not hasattr(
                controlnet, "set_attn_processor"
            )

            if not is_multi_controlnet:
                return original_set_ip_adapter(self)

            original_multi_controlnet = controlnet
            self.pipe.controlnet = original_multi_controlnet.nets[0]
            try:
                original_set_ip_adapter(self)
            finally:
                self.pipe.controlnet = original_multi_controlnet

            for extra_controlnet in original_multi_controlnet.nets[1:]:
                extra_controlnet.set_attn_processor(
                    CNAttnProcessor(num_tokens=self.num_tokens)
                )

        patched_set_ip_adapter._multicontrolnet_patched = True
        IPAdapter.set_ip_adapter = patched_set_ip_adapter

    def load_depth_estimator(self):
        """Depth Estimation 모델을 로드합니다."""
        from transformers import pipeline as hf_pipeline

        print("⏳ Depth Estimator 로드 중...")
        self._depth_estimator = hf_pipeline(
            "depth-estimation",
            model=self.cfg.models.depth_estimator,
            device=0 if self.device == "cuda" else -1,
        )
        print("✅ Depth Estimator 로드 완료")

    def load_lineart_detector(self):
        """Lineart 추출 모델을 로드합니다."""
        from controlnet_aux import LineartDetector

        print("⏳ Lineart Detector 로드 중...")
        self._lineart_detector = LineartDetector.from_pretrained(
            self.cfg.models.lineart_detector
        )
        print("✅ Lineart Detector 로드 완료")

    def load_trellis(self):
        """TRELLIS 3D 변환 모델을 로드합니다."""
        # TRELLIS 라이브러리 경로를 sys.path에 추가
        for lib_path in (self.cfg.models.trellis_lib_path, self.cfg.models.o_voxel_lib_path):
            if not lib_path or not os.path.isdir(lib_path):
                continue
            abs_path = os.path.abspath(lib_path)
            if abs_path not in sys.path:
                sys.path.insert(0, abs_path)

        os.environ.setdefault("OPENCV_IO_ENABLE_OPENEXR", "1")
        os.environ.setdefault("SPARSE_ATTN_BACKEND", "xformers")
        os.environ.setdefault("ATTN_BACKEND", "xformers")
        os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

        from trellis2.pipelines import Trellis2ImageTo3DPipeline

        print("⏳ TRELLIS.2 로드 중...")
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        self._trellis_pipeline = Trellis2ImageTo3DPipeline.from_pretrained(
            self.cfg.models.trellis_ckpt
        )
        if self.device == "cuda":
            self._trellis_pipeline.cuda()
        print("✅ TRELLIS.2 로드 완료")

    def load_all(self):
        """모든 모델을 한 번에 로드합니다."""
        self.load_sdxl()
        self.load_depth_estimator()
        self.load_lineart_detector()
        self.load_trellis()
        self._print_gpu_usage()

    # ── 유틸리티 ─────────────────────────────────────────

    @staticmethod
    def resize_multiple_of_64(image: Image.Image, max_size: int = 1024) -> Image.Image:
        """긴 변을 max_size로 맞추고 가로/세로를 64의 배수로 리사이즈합니다."""
        image = ImageOps.exif_transpose(image.convert("RGB"))
        w, h = image.size
        scale = max_size / max(w, h)
        new_w = max(64, int(round(w * scale / 64)) * 64)
        new_h = max(64, int(round(h * scale / 64)) * 64)
        return image.resize((new_w, new_h), Image.Resampling.LANCZOS)

    @staticmethod
    def pad_to_square(
        image: Image.Image,
        size: int = 1024,
        fill: tuple[int, int, int] = (255, 255, 255),
    ) -> Image.Image:
        image = ImageOps.exif_transpose(image.convert("RGB"))
        image.thumbnail((size, size), Image.Resampling.LANCZOS)
        canvas = Image.new("RGB", (size, size), fill)
        canvas.paste(image, ((size - image.width) // 2, (size - image.height) // 2))
        return canvas

    @staticmethod
    def _print_gpu_usage():
        if torch.cuda.is_available():
            used = torch.cuda.memory_allocated() / 1024 ** 3
            free = torch.cuda.mem_get_info()[0] / 1024 ** 3
            print(f"  GPU 사용: {used:.1f} GB / 여유: {free:.1f} GB")

    # ── Depth 추출 ───────────────────────────────────────

    def extract_depth(self, image: Image.Image, max_size: int = 1024) -> Image.Image:
        """이미지에서 Depth Map을 추출합니다."""
        if self._depth_estimator is None:
            self.load_depth_estimator()

        resized = self.resize_multiple_of_64(image, max_size=max_size)
        result = self._depth_estimator(resized)
        depth = result["depth"].convert("L").resize(
            resized.size, Image.Resampling.BICUBIC
        )
        depth_np = np.array(depth).astype(np.float32)
        lo, hi = np.percentile(depth_np, [2, 98])
        depth_np = np.clip((depth_np - lo) / max(hi - lo, 1e-6), 0, 1) * 255
        depth_np = depth_np.astype(np.uint8)
        return Image.fromarray(np.repeat(depth_np[:, :, None], 3, axis=2))

    def extract_lineart(self, image: Image.Image, max_size: int = 1024) -> Image.Image:
        """
        이미지에서 Lineart ControlNet 조건 이미지를 추출합니다.

        기본값은 baseline_v2_upgraded.ipynb의 extract_ultimate_lineart 방식입니다.
        - rembg alpha mask로 배경 edge 제거
        - CLAHE로 내부 경계 강화
        - 딥러닝 lineart + Canny edge를 병합
        - 피사체 영역 밖 edge를 제거
        """
        if self._lineart_detector is None:
            self.load_lineart_detector()

        gen_cfg = self.cfg.generation
        resized = self.resize_multiple_of_64(image, max_size=max_size)

        if not gen_cfg.use_ultimate_lineart:
            lineart = self._lineart_detector(
                resized,
                detect_resolution=max_size,
                image_resolution=max_size,
                coarse=False,
            ).convert("RGB")
            lineart = lineart.resize(resized.size, Image.Resampling.LANCZOS)
            gray = ImageOps.grayscale(lineart)
            gray = ImageEnhance.Contrast(gray).enhance(1.25)
            return Image.merge("RGB", (gray, gray, gray))

        import cv2

        # 1) 배경 제거 기반 마스크. rembg가 없거나 실패하면 밝은 배경 기준 mask로 fallback.
        mask = None
        if gen_cfg.lineart_use_rembg:
            try:
                from rembg import remove

                rgba = remove(resized.convert("RGB"), alpha_matting=True)
                mask = np.array(rgba)[:, :, 3]
            except Exception as exc:
                print(f"  rembg lineart mask fallback: {type(exc).__name__}")

        if mask is None:
            arr = np.array(resized.convert("RGB"))
            dist_from_white = np.linalg.norm(arr.astype(np.int16) - 255, axis=2)
            mask = (dist_from_white > self.cfg.mesh.white_threshold).astype(np.uint8) * 255

        k = max(1, int(gen_cfg.lineart_mask_dilate_kernel))
        kernel = np.ones((k, k), np.uint8)
        dilated_mask = cv2.dilate(mask.astype(np.uint8), kernel, iterations=1)

        # 2) CLAHE로 약한 내부 경계 강화
        gray = cv2.cvtColor(np.array(resized), cv2.COLOR_RGB2GRAY)
        tile = max(1, int(gen_cfg.lineart_clahe_tile_grid_size))
        clahe = cv2.createCLAHE(
            clipLimit=float(gen_cfg.lineart_clahe_clip_limit),
            tileGridSize=(tile, tile),
        )
        enhanced_gray = clahe.apply(gray)

        # 3) DL lineart
        enhanced_pil = Image.fromarray(cv2.cvtColor(enhanced_gray, cv2.COLOR_GRAY2RGB))
        lineart_dl = self._lineart_detector(
            enhanced_pil,
            detect_resolution=max_size,
            image_resolution=max_size,
            coarse=False,
        ).convert("L")
        lineart_dl = lineart_dl.resize(resized.size, Image.Resampling.LANCZOS)
        dl_np = np.array(lineart_dl).astype(np.float32)

        # 4) Canny edge 보조
        blurred = cv2.GaussianBlur(enhanced_gray, (3, 3), 0)
        canny = cv2.Canny(
            blurred,
            threshold1=int(gen_cfg.lineart_canny_threshold1),
            threshold2=int(gen_cfg.lineart_canny_threshold2),
        ).astype(np.float32)

        # 5) 병합 + 배경 edge 제거 + 약한 잡음 제거
        blended = cv2.addWeighted(
            dl_np,
            float(gen_cfg.lineart_dl_weight),
            canny,
            float(gen_cfg.lineart_canny_weight),
            0,
        )
        blended[dilated_mask < 30] = 0
        _, cleaned = cv2.threshold(
            blended,
            int(gen_cfg.lineart_clean_threshold),
            255,
            cv2.THRESH_TOZERO,
        )

        final_gray = np.clip(cleaned, 0, 255).astype(np.uint8)
        final_pil = Image.fromarray(final_gray)
        final_pil = ImageEnhance.Contrast(final_pil).enhance(float(gen_cfg.lineart_contrast))
        return Image.merge("RGB", (final_pil, final_pil, final_pil))

    @staticmethod
    def force_near_white_background(img: Image.Image, threshold: int = 220) -> Image.Image:
        """밝은 배경 픽셀을 순백색으로 고정합니다."""
        img = img.convert("RGB")
        arr = np.array(img)
        mask = (
            (arr[:, :, 0] > threshold)
            & (arr[:, :, 1] > threshold)
            & (arr[:, :, 2] > threshold)
        )
        arr[mask] = [255, 255, 255]
        return Image.fromarray(arr)

    # ── 2D 이미지 생성 ───────────────────────────────────

    def generate_images(
        self,
        style_image: Image.Image,
        structure_image: Image.Image,
        prompt: str = "",
        negative_prompt: str = "",
        num_images: Optional[int] = None,  # 💡 시드 대신 '이미지 개수'를 인자로 받습니다.
        seeds: Optional[List[int]] = None,
        num_per_seed: int = 1,
        on_image: Optional[Callable[[Image.Image, int, int], None]] = None,
        depth_conditioning_scale: Optional[float] = None,
        lineart_conditioning_scale: Optional[float] = None,
        ip_adapter_scale: Optional[float] = None,
        guidance_scale: Optional[float] = None,
        num_inference_steps: Optional[int] = None,
    ) -> List[Image.Image]:
        """
        스타일 참조 이미지 + 구조 참조 이미지 → 2D 생성 이미지 목록을 반환합니다.
        UI에서 넘겨준 num_images 개수만큼 매번 새로운 랜덤 시드를 자동 배정합니다.
        """
        if self._ip_model is None:
            self.load_sdxl()

        gen_cfg = self.cfg.generation
        seeds = seeds if seeds is not None else (None if num_images is not None else gen_cfg.seeds)
        prompt = (prompt or "").strip() or gen_cfg.prompt
        negative_prompt = (negative_prompt or "").strip() or gen_cfg.negative_prompt
        depth_scale = (
            float(depth_conditioning_scale)
            if depth_conditioning_scale is not None
            else gen_cfg.depth_conditioning_scale
        )
        lineart_scale = (
            float(lineart_conditioning_scale)
            if lineart_conditioning_scale is not None
            else gen_cfg.lineart_conditioning_scale
        )
        adapter_scale = (
            float(ip_adapter_scale)
            if ip_adapter_scale is not None
            else gen_cfg.ip_adapter_scale
        )
        prompt_scale = (
            float(guidance_scale)
            if guidance_scale is not None
            else gen_cfg.guidance_scale
        )
        inference_steps = (
            int(num_inference_steps)
            if num_inference_steps is not None
            else gen_cfg.num_inference_steps
        )

        # 💡 [핵심 통합 로직] 
        # 만약 개발자 디버깅용 고정 seeds가 안 들어왔다면, UI 입력값에 따라 랜덤 시드 생성
        if seeds is None:
            # UI에서 정수값이 들어오면 그걸 쓰고, 안 들어오면 config의 기본값(4)을 씀
            count = num_images if num_images is not None else getattr(gen_cfg, 'num_images', 4)
            # 입력받은 개수(count)만큼 0 ~ 4,294,967,295 사이의 난수 시드 리스트 생성
            seeds = [random.randint(0, 513) for _ in range(count)]
            print(f"🎲 {count}개의 이미지를 생성하기 위해 랜덤 시드를 자동 배정했습니다: {seeds}")

        style_image = self.resize_multiple_of_64(
            style_image, max_size=gen_cfg.max_style_size
        )

        # Depth + Lineart 조건 이미지 추출
        depth_image = self.extract_depth(
            structure_image, max_size=gen_cfg.max_condition_size
        )
        lineart_image = self.extract_lineart(
            structure_image, max_size=gen_cfg.max_condition_size
        )
        print(f"  Depth 크기: {depth_image.size}")
        print(f"  Lineart 크기: {lineart_image.size}")

        all_images: List[Image.Image] = []
        for idx, seed in enumerate(seeds):
            print(f"  [이미지 {idx+1}/{len(seeds)}] 생성 중... (배정된 시드: {seed})")
            images = self._ip_model.generate(
                pil_image=style_image,
                image=[depth_image, lineart_image],
                prompt=prompt,
                negative_prompt=negative_prompt,
                controlnet_conditioning_scale=[
                    depth_scale,
                    lineart_scale,
                ],
                scale=adapter_scale,
                guidance_scale=prompt_scale,
                num_samples=num_per_seed,
                num_inference_steps=inference_steps,
                seed=seed,
            )
            for img in images:
                img = img.convert("RGB")
                if gen_cfg.force_white_background:
                    img = self.force_near_white_background(
                        img, threshold=int(gen_cfg.white_background_threshold)
                    )
                all_images.append(img)
                if on_image is not None:
                    on_image(img, len(all_images) - 1, seed)
            print(f"  ✅ {idx+1}번째 이미지 생성 완료")

        return all_images

    @staticmethod
    def scale_glb_to_real_size(
        input_path: str,
        output_path: str,
        target_width_mm: float = 18.0,
    ) -> str:
        """Scale a GLB so its wider X/Y bounding-box side becomes target_width_mm."""
        import trimesh

        mesh = trimesh.load(input_path, force="mesh")
        current_extents = mesh.extents
        print(f"변경 전 크기 (X, Y, Z): {current_extents}")

        current_width = max(current_extents[0], current_extents[1])
        if current_width <= 0:
            raise ValueError(f"GLB scale failed because width is invalid: {current_width}")

        scale_factor = float(target_width_mm) / float(current_width)
        print(f"적용할 스케일 비율: {scale_factor:.2f}배 확대")

        scale_matrix = trimesh.transformations.scale_matrix(scale_factor)
        mesh.apply_transform(scale_matrix)

        z_min = mesh.bounds[0][2]
        translation_matrix = trimesh.transformations.translation_matrix([0, 0, -z_min])
        mesh.apply_transform(translation_matrix)

        print(f"변경 후 실제 크기 (X, Y, Z): {mesh.extents} mm")
        mesh.export(output_path)
        print(f"✅ 실제 크기가 적용된 GLB 저장 완료: {output_path}")
        return output_path

    # ── 3D 입력 전처리 ───────────────────────────────────

    def prepare_image_for_3d(self, image: Image.Image) -> Image.Image:
        """흰 배경의 제품 이미지를 TRELLIS.2 입력에 맞게 crop/pad/sharpen합니다."""
        import cv2

        mesh_cfg = self.cfg.mesh
        img = ImageOps.exif_transpose(image.convert("RGB"))
        arr = np.array(img)
        dist_from_white = np.linalg.norm(arr.astype(np.int16) - 255, axis=2)
        mask = (dist_from_white > mesh_cfg.white_threshold).astype(np.uint8) * 255
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))

        ys, xs = np.where(mask > 0)
        if len(xs) > 0 and len(ys) > 0:
            pad = mesh_cfg.crop_padding
            x0 = max(xs.min() - pad, 0)
            x1 = min(xs.max() + pad, img.width - 1)
            y0 = max(ys.min() - pad, 0)
            y1 = min(ys.max() + pad, img.height - 1)
            img = img.crop((x0, y0, x1 + 1, y1 + 1))

        img = ImageEnhance.Contrast(img).enhance(mesh_cfg.contrast)
        img = ImageEnhance.Sharpness(img).enhance(mesh_cfg.sharpness)
        img = self.pad_to_square(img, size=mesh_cfg.image_size, fill=(255, 255, 255))
        return img.filter(
            ImageFilter.UnsharpMask(
                radius=mesh_cfg.unsharp_radius,
                percent=mesh_cfg.unsharp_percent,
                threshold=mesh_cfg.unsharp_threshold,
            )
        )

    # ── 3D 모델 생성 ─────────────────────────────────────

    def generate_3d(
        self,
        image: Image.Image,
        filename: str = "output_model",
        sparse_steps: Optional[int] = None,
        slat_steps: Optional[int] = None,
        sparse_cfg: Optional[float] = None,
        slat_cfg: Optional[float] = None,
        seed: int = 42,
    ) -> str:
        """
        2D 이미지로부터 3D GLB 모델을 생성하고, 저장된 파일 경로를 반환합니다.
        """
        if self._trellis_pipeline is None:
            self.load_trellis()

        import o_voxel

        mesh_cfg = self.cfg.mesh

        output_dir = self.cfg.paths.output_dir
        os.makedirs(output_dir, exist_ok=True)

        image = self.prepare_image_for_3d(image)

        print("🔨 3D 변환 중...")
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.manual_seed_all(seed)
        torch.manual_seed(seed)

        with torch.no_grad():
            mesh = self._trellis_pipeline.run(image)[0]
        mesh.simplify(mesh_cfg.simplify_target)

        glb_path = os.path.join(output_dir, f"{filename}.glb")
        glb = o_voxel.postprocess.to_glb(
            vertices=mesh.vertices,
            faces=mesh.faces,
            attr_volume=mesh.attrs,
            coords=mesh.coords,
            attr_layout=mesh.layout,
            voxel_size=mesh.voxel_size,
            aabb=[[-0.5, -0.5, -0.5], [0.5, 0.5, 0.5]],
            decimation_target=mesh_cfg.decimation_target,
            texture_size=mesh_cfg.texture_size,
            remesh=mesh_cfg.remesh,
            remesh_band=mesh_cfg.remesh_band,
            remesh_project=mesh_cfg.remesh_project,
            verbose=True,
        )
        glb.export(glb_path)
        print(f"✅ GLB 저장: {glb_path}")

        if mesh_cfg.real_scale_enabled:
            root, ext = os.path.splitext(glb_path)
            scaled_glb_path = f"{root}{mesh_cfg.real_scale_suffix}{ext}"
            return self.scale_glb_to_real_size(
                input_path=glb_path,
                output_path=scaled_glb_path,
                target_width_mm=mesh_cfg.real_scale_target_width_mm,
            )

        return glb_path

    # ── 이미지 그리드 유틸 ────────────────────────────────

    @staticmethod
    def image_grid(imgs: List[Image.Image], rows: int, cols: int) -> Image.Image:
        """이미지를 rows x cols 그리드로 합칩니다."""
        assert len(imgs) == rows * cols
        w, h = imgs[0].size
        grid = Image.new("RGB", size=(cols * w, rows * h), color=(255, 255, 255))
        for i, img in enumerate(imgs):
            grid.paste(img.convert("RGB"), box=(i % cols * w, i // cols * h))
        return grid
